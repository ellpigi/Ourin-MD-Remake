'use strict'
const { execFileSync } = require('node:child_process')
const result = JSON.parse(execFileSync('npm', ['pack', '--dry-run', '--ignore-scripts', '--json'], { encoding: 'utf8', maxBuffer: 8 * 1024 * 1024 }))[0]
const paths = result.files.map(file => file.path)
const forbidden = paths.filter(name => /(^|\/)(node_modules|sessions|storage|backups)(\/|$)/.test(name) || /(^|\/)creds\.json$|(^|\/)\.env(?:\.|$)/.test(name))
if (forbidden.length) throw new Error(`Unexpected package files: ${forbidden.slice(0, 5).join(', ')}`)
for (const name of ['dist/index.cjs', 'dist/index.mjs', 'dist/alya.cjs', 'dist/zapo.cjs', 'types/index.d.ts', 'scripts/check-node.cjs']) {
    if (!paths.includes(name)) throw new Error(`Missing package file: ${name}`)
}
console.log(`Package checked: ${result.entryCount} files, ${(result.size / 1024 / 1024).toFixed(1)} MiB compressed, no session/dependency folders.`)
