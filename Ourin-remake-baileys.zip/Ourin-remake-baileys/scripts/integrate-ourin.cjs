'use strict'
const fs = require('node:fs')
const path = require('node:path')

const aliases = new Set([
    'baileys', '@whiskeysockets/baileys', '@adiwajshing/baileys',
    '@rexxhayanasi/elaina-baileys', 'ourin-baileys', 'baileys-joss',
    'ourin-remake-baileys'
])

function planMigration(pkg, spec) {
    if (!/^github:[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+(?:#[A-Za-z0-9_./-]+)?$/.test(spec)) {
        throw new Error('Gunakan github:USERNAME/Ourin-remake-baileys, opsional #tag atau #commit.')
    }
    const result = structuredClone(pkg)
    const changes = []
    for (const section of ['dependencies', 'devDependencies', 'optionalDependencies']) {
        for (const [name, previous] of Object.entries(result[section] || {})) {
            if (aliases.has(name) && previous !== spec) {
                result[section][name] = spec
                changes.push({ section, name, previous, next: spec })
            }
        }
    }
    if (!changes.length && ![...aliases].some(name =>
        ['dependencies', 'devDependencies', 'optionalDependencies'].some(s => result[s]?.[name] === spec)
    )) {
        throw new Error('Dependency Baileys tidak ditemukan. Baca docs/INSTALL-OURIN.md untuk pemasangan manual.')
    }
    return { result, changes }
}

function main(args) {
    const positional = args.filter(arg => arg !== '--write')
    if (positional.length !== 2) {
        throw new Error('Pemakaian: node scripts/integrate-ourin.cjs FOLDER_BOT github:USERNAME/Ourin-remake-baileys [--write]')
    }
    const filename = path.resolve(positional[0], 'package.json')
    const before = fs.readFileSync(filename, 'utf8')
    const { result, changes } = planMigration(JSON.parse(before), positional[1])
    console.log(JSON.stringify({ file: filename, changes }, null, 2))
    if (!args.includes('--write')) {
        console.log('Pratinjau saja. Tambahkan --write untuk menerapkan perubahan.')
        return
    }
    if (!changes.length) { console.log('Sudah menggunakan dependency yang diminta.'); return }
    const backup = `${filename}.before-ourin-${Date.now()}`
    fs.writeFileSync(backup, before, { flag: 'wx', mode: 0o600 })
    const temp = `${filename}.ourin-${process.pid}.tmp`
    fs.writeFileSync(temp, JSON.stringify(result, null, 2) + '\n', { flag: 'wx', mode: fs.statSync(filename).mode })
    fs.renameSync(temp, filename)
    console.log(`Tersimpan. Backup: ${path.basename(backup)}. Berikutnya jalankan npm install di folder bot.`)
}
module.exports = { planMigration }
if (require.main === module) {
    try { main(process.argv.slice(2)) }
    catch (error) { console.error(error.message); process.exitCode = 1 }
}
