'use strict'
const fs = require('node:fs/promises')
const os = require('node:os')
const path = require('node:path')
const assert = require('node:assert/strict')
const root = path.resolve(__dirname, '..')

async function main() {
    const folder = await fs.mkdtemp(path.join(os.tmpdir(), 'ourin-example-check-'))
    try {
        const { initDatabase } = require('../examples/ourin-md/src/lib/database')
        await initDatabase(folder)
        assert.ok((await fs.stat(path.join(folder, 'db.json'))).isFile())
        const { loadPlugins, pluginStore } = require('../examples/ourin-md/src/lib/plugins')
        assert.equal(loadPlugins(path.join(root, 'examples/ourin-md/plugins')), 18)
        const sent = []
        const message = {
            chat: 'fixture@s.whatsapp.net',
            reply: async text => { sent.push(text); return { key: { id: 'fixture' } } }
        }
        const socket = { sendMessage: async (_jid, content) => sent.push(content.text) }
        await pluginStore.commands.get('ping').handler(message, {
            sock: socket,
            config: require('../examples/ourin-md/config')
        })
        assert.ok(sent.some(text => String(text).includes('PONG')))
        console.log('Ourin example checked: database persistence, 18 plugins, offline ping handler.')
    } finally { await fs.rm(folder, { recursive: true, force: true }) }
}
main().catch(error => { console.error(error); process.exitCode = 1 })
