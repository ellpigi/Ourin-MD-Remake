'use strict'
const fs = require('node:fs')
const path = require('node:path')
const { execFileSync } = require('node:child_process')
const root = path.resolve(__dirname, '..')
process.chdir(root)
fs.rmSync('types', { recursive: true, force: true })
fs.mkdirSync('types', { recursive: true })
for (const name of ['baileys-joss', 'alya', 'zapo']) {
    const configPath = `.typebuild-${name}.json`
    const config = {
        extends: `./vendor/${name}/tsconfig.json`,
        compilerOptions: {
            noEmit: false,
            declaration: true,
            declarationMap: false,
            emitDeclarationOnly: true,
            rootDir: `./vendor/${name}/src`,
            outDir: `./types/${name}/src`
        },
        include: [`vendor/${name}/src/**/*.ts`],
        exclude: ['node_modules', '**/__tests__/**']
    }
    fs.writeFileSync(configPath, JSON.stringify(config, null, 2))
    try {
        execFileSync(process.execPath, ['node_modules/typescript/bin/tsc', '-p', configPath], { stdio: 'inherit' })
        execFileSync(process.execPath, ['node_modules/tsc-alias/dist/bin/index.js', '-p', configPath], { stdio: 'inherit' })
    } finally { fs.rmSync(configPath, { force: true }) }
    const spec = path.join('vendor', name, name === 'baileys-joss' ? 'WAProto' : 'spec')
    const out = path.join('types', name, name === 'baileys-joss' ? 'WAProto' : 'spec')
    for (const entry of fs.readdirSync(spec, { recursive: true })) {
        const source = path.join(spec, entry)
        if (entry.endsWith('.d.ts') || entry.endsWith('.json')) {
            const target = path.join(out, entry)
            fs.mkdirSync(path.dirname(target), { recursive: true })
            fs.copyFileSync(source, target)
        }
    }
}
fs.writeFileSync('types/index.d.ts', [
    "export * from './baileys-joss/src/index.js'",
    "export { default } from './baileys-joss/src/index.js'",
    "export { findFirstLink, getMessageText, WA_LINK_KINDS } from './alya/src/client/link-filter.js'",
    ''
].join('\n'))
fs.writeFileSync('types/index.d.mts', [
    "export * from './baileys-joss/src/index.js'",
    "export { makeWASocket as default } from './baileys-joss/src/index.js'",
    "export { findFirstLink, getMessageText, WA_LINK_KINDS } from './alya/src/client/link-filter.js'",
    ''
].join('\n'))
for (const name of ['alya', 'zapo']) {
    fs.writeFileSync(`types/${name}.d.ts`, `export * from './${name}/src/index.js'\n`)
    fs.writeFileSync(`types/${name}.d.mts`, `export * from './${name}/src/index.js'\n`)
}
console.log('Built TypeScript declarations.')
