'use strict'
const { build } = require('esbuild')
const fs = require('node:fs/promises')
const path = require('node:path')
const root = path.resolve(__dirname, '..')

async function main() {
    await fs.rm(path.join(root, 'dist'), { recursive: true, force: true })
    for (const [name, vendor] of [['index', 'alya'], ['alya', 'alya'], ['zapo', 'zapo']]) {
        for (const [format, ext] of [['cjs', 'cjs'], ['esm', 'mjs']]) {
            await build({
                absWorkingDir: root,
                entryPoints: [`src/${name}.ts`],
                outfile: `dist/${name}.${ext}`,
                platform: 'node',
                target: 'node22',
                format,
                bundle: true,
                packages: 'external',
                banner: format === 'esm' ? {
                    js: "import { createRequire as __ourinCreateRequire } from 'node:module'; const require = __ourinCreateRequire(import.meta.url);"
                } : undefined,
                // This upstream package exposes only an ESM import condition.
                // Bundle its unchanged WASM loader for CommonJS consumers.
                plugins: [{
                    name: 'vendored-source-entry-points',
                    setup(builder) {
                        const entries = {
                            '#joss': 'vendor/baileys-joss/src/index.ts',
                            '#alya': 'vendor/alya/src/index.ts',
                            '#zapo': 'vendor/zapo/src/index.ts',
                            '#alya-links': 'vendor/alya/src/client/link-filter.ts'
                        }
                        builder.onResolve({ filter: /^#(?:joss|alya|zapo|alya-links)$/ }, args => ({
                            path: path.join(root, entries[args.path])
                        }))
                    }
                }, {
                    name: 'libsignal-esm-paths',
                    setup(builder) {
                        builder.onResolve({ filter: /^libsignal\/src\// }, args => ({
                            path: args.path.endsWith('.js') ? args.path : `${args.path}.js`,
                            external: true
                        }))
                    }
                }, ...(format === 'cjs' && name === 'index' ? [{
                    name: 'rust-bridge-commonjs',
                    setup(builder) {
                        builder.onResolve({ filter: /^whatsapp-rust-bridge$/ }, () => ({
                            path: path.join(root, 'node_modules/whatsapp-rust-bridge/dist/index.js')
                        }))
                    }
                }] : [])],
                tsconfig: `vendor/${vendor}/tsconfig.json`,
                legalComments: 'eof',
                sourcemap: false,
                minify: false
            })
        }
    }
    console.log('Built CJS + ESM: Baileys API, Alya and Zapo.')
}
main().catch(error => { console.error(error); process.exitCode = 1 })
