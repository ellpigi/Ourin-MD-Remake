'use strict'
const [major, minor] = process.versions.node.split('.').map(Number)
if (major < 22 || (major === 22 && minor < 12)) {
    console.error('Ourin-remake-baileys memerlukan Node.js >=22.12.0. Gunakan Node.js 24 LTS.')
    process.exit(1)
}
