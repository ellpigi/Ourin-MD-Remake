# Sumber, lisensi, dan perubahan

Disusun dengan bantuan Codex. Paket ini bukan rilis resmi dari para maintainer
upstream. Nama dan atribusi asli dipertahankan pada source yang disertakan.

| Komponen | Repository yang diberikan | Metadata lisensi lampiran |
| --- | --- | --- |
| Baileys-Joss 2.0.1 | https://github.com/firdausmntp/Baileys-Joss | MIT; teks asli di `vendor/baileys-joss/LICENSE` |
| alya-js 1.10.0 | https://github.com/irfanModz73/alya-js | MIT; teks asli di `vendor/alya/LICENSE` |
| zapo-js 1.10.0 | https://github.com/rexxzyid/zapo | MIT; teks asli di `vendor/zapo/LICENSE` |
| Ourin-MD 1.2.0 | https://github.com/LuckyArch/Ourin-MD | `package.json` menyatakan ISC; lampiran tidak memiliki file LICENSE tersendiri |

Metadata package Alya dan Zapo juga mencantumkan vinikjkkj serta repository
`vinikjkkj/zapo`. Atribusi tersebut dipertahankan, bukan diganti sebagai karya
baru. `SOURCE-MANIFEST.json` merekam SHA-256 ZIP sumber; tidak ada commit SHA
yang ditebak untuk lampiran tanpa metadata Git.

Root LICENSE mempertahankan teks MIT dari Baileys-Joss. Lisensi tiap komponen
tetap berlaku pada bagiannya, termasuk metadata ISC untuk contoh Ourin.
Header penulis Ourin-AI Team dipertahankan. Teks lisensi dependency runtime
tersedia dalam distribusi npm masing-masing. Loader `whatsapp-rust-bridge`
0.5.4 ikut dibundel tanpa perubahan dalam build CJS; teks lisensinya disertakan
di `docs/whatsapp-rust-bridge-LICENSE`.

## Perubahan integrasi

- Root package baru, build CJS/ESM, ekspor subpath, dan deklarasi TypeScript.
- API utama membungkus `makeWASocket` untuk menangani QR terminal pada bot lama.
- Helper link/text Alya diekspor pada root tanpa menyalin implementasinya.
- Specifier `libsignal/src/*` diberi ekstensi `.js` saat build. Loader Rust/WASM
  ESM-only dibundel untuk CJS. Source kriptografi, protobuf generated, dan
  wire protocol Baileys-Joss tidak diedit.
- Contoh Ourin mengganti import dan dependency Elaina dengan paket baru,
  menghilangkan database/backup pengguna bawaan serta ID saluran bawaan, dan
  meminta pairing setelah QR handshake serta listener credential terpasang.
- Alya: callback unduh status meneruskan `source.message`, sesuai signature
  `downloadBytes`; fanout memakai variabel `sendOptions` lokal yang tersedia;
  newsletter query meneruskan timeout default yang sudah ada di sumber;
  overload status membedakan core dari permukaan lengkap; parser byte menolak
  content non-biner; pengambilan caption mempersempit tipe media.
- Tipe extension `contextInfo` helper newsletter-status Alya diberi tipe lokal
  untuk mempertahankan perilaku source. Tidak ada properti protobuf baru yang
  dibuat. Properti root tersebut tidak diserialisasi schema upstream; fitur
  atribusi itu tetap menjadi keterbatasan dan belum dinyatakan siap produksi.
- Runtime core Zapo tetap sesuai lampiran. Addon workspace kedua proyek tidak
  ikut dibundel; package.json vendor adalah metadata sumber, bukan entry
  instalasi terpisah. Gunakan package.json pada root untuk build/install.

Dokumentasi upstream di folder vendor dipertahankan sebagai referensi.
Perintah instalasi, permukaan ekspor, dan batas pengujian paket gabungan ini
mengikuti README dan VALIDATION pada root.
