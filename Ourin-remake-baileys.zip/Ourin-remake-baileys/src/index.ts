export * from '#joss'
import makeBaseSocket from '#joss'
import { findFirstLink, getMessageText, WA_LINK_KINDS } from '#alya-links'
import qr from 'qrcode-terminal'

// Older Ourin bots still use this option; Joss now emits QR events only.
export function makeWASocket(config: Parameters<typeof makeBaseSocket>[0]) {
    const { printQRInTerminal, ...options } = config
    const socket = makeBaseSocket(options)
    if (printQRInTerminal) {
        socket.ev.on('connection.update', update => {
            if (update.qr) qr.generate(update.qr, { small: true })
        })
    }
    return socket
}

export { findFirstLink, getMessageText, WA_LINK_KINDS }
export default makeWASocket
