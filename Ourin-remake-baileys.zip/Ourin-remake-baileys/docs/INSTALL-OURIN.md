# Pemasangan pada Ourin-MD / Ourin-MD-Remake

## Cara paling sederhana

Periksa string import Baileys di bot, lalu ganti **nilai** dependency dengan
`github:ellpigi/Ourin-remake-baileys`. Pertahankan key yang sudah digunakan
kode. Jalankan `npm install` untuk memperbarui lockfile; `npm ci` tidak
memperbarui lockfile setelah package.json diubah.

Contoh bila bot menggunakan `@whiskeysockets/baileys`:

```json
"@whiskeysockets/baileys": "github:ellpigi/Ourin-remake-baileys"
```

Jangan menambahkan key `ourin-remake-baileys` sambil membiarkan kode mengimpor
dependency lama, karena bot akan tetap memuat paket lama.

## Skrip integrasi

Dari folder library hasil ekstrak, lihat pratinjau:

```bash
node scripts/integrate-ourin.cjs /lokasi/folder-bot github:ellpigi/Ourin-remake-baileys
```

Terapkan:

```bash
node scripts/integrate-ourin.cjs /lokasi/folder-bot github:ellpigi/Ourin-remake-baileys --write
```

Skrip mengganti dependency yang dikenali, mempertahankan nama import, membuat
backup package.json, dan tidak mengubah sesi maupun kode bot. Alias yang
dikenali: `baileys`, `@whiskeysockets/baileys`, `@adiwajshing/baileys`,
`@rexxhayanasi/elaina-baileys`, `ourin-baileys`, `baileys-joss`, dan
`ourin-remake-baileys`. Ini adalah migrasi manifest, bukan konverter API.
Jika bot memakai API khusus fork lama, kode fitur itu perlu disesuaikan.

Sesudahnya jalankan `npm install` dan `npm start` **di folder bot**. Untuk
rollback, salin isi backup package.json ke package.json dan jalankan
`npm install` kembali.

## Pin versi repository

Setelah kamu membuat tag `v1.0.0` di GitHub:

```json
"baileys": "github:ellpigi/Ourin-remake-baileys#v1.0.0"
```

Tag belum dibuat oleh ZIP ini. Alternatifnya tambahkan `#COMMIT_SHA` yang
benar-benar ada pada repository. Tanpa suffix, npm menggunakan default branch.

## Masalah yang umum

- **GitHub 404 / authentication required:** repository belum dibuat, URL salah,
  atau private. Unggah terlebih dahulu; private repo memerlukan akses Git
  yang sudah dikonfigurasi di server kamu.
- **Cannot find module / exports:** periksa folder `dist` dan `types` ikut
  diunggah serta package.json berada di root repository.
- **Node.js terlalu lama:** gunakan >=22.12; jangan mengabaikan engine check.
- **Command lama gagal walaupun bot terhubung:** periksa apakah command memakai
  API fork khusus yang tidak ada di Baileys-Joss. Memasukkan semua sumber dalam
  satu package tidak menyamakan API masing-masing.
- **Native accelerator Alya/Zapo tidak tersedia:** akselerator merupakan
  addon optional upstream. Fallback bawaan tetap tersedia. Addon tersebut
  tidak disertakan atau dijanjikan kompatibel lintas platform oleh ZIP ini.
- **QR pada Ourin lama:** wrapper utama mempertahankan `printQRInTerminal`.
  Bot baru juga dapat menangani `connection.update.qr` sendiri.
- **Pairing gagal:** periksa jaringan, versi Node, dan perangkat tertaut.
  Paket tidak menjamin keberhasilan pairing atau status akun. Simpan cadangan
  sesi yang masih dipakai; jangan menghapusnya sebagai langkah awal.

Folder sesi, credential, database pengguna, dan file `.env` tidak perlu
diunggah ke repository. `.gitignore` tersedia untuk mencegahnya ikut commit.
