import makeWASocket, { useMultiFileAuthState, findFirstLink } from 'ourin-remake-baileys'
import { WaClient as Alya } from 'ourin-remake-baileys/alya'
import { WaClient as Zapo } from 'ourin-remake-baileys/zapo'

async function typedConsumer() {
    const { state } = await useMultiFileAuthState('never-executed')
    return makeWASocket({ auth: state })
}
void [typedConsumer, findFirstLink, Alya, Zapo]
