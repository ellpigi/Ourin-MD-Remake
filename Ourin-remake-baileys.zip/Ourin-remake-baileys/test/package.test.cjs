'use strict'
const test = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs/promises')
const os = require('node:os')
const path = require('node:path')
const { execFileSync } = require('node:child_process')
const api = require('ourin-remake-baileys')
const { planMigration } = require('../scripts/integrate-ourin.cjs')

test('CommonJS exposes every Baileys symbol imported by the supplied Ourin bot', () => {
    for (const name of [
        'default', 'makeWASocket', 'useMultiFileAuthState', 'makeCacheableSignalKeyStore',
        'fetchLatestBaileysVersion', 'downloadContentFromMessage', 'getContentType',
        'jidDecode', 'generateWAMessageFromContent', 'generateWAMessage',
        'areJidsSameUser', 'downloadMediaMessage'
    ]) assert.equal(typeof api[name], 'function', name)
    assert.equal(typeof api.proto.Message.encode, 'function')
    assert.equal(api.DisconnectReason.loggedOut, 401)
    assert.equal(api.default, api.makeWASocket)
})

test('ESM supports default and named Baileys imports', async () => {
    const esm = await import('ourin-remake-baileys')
    assert.equal(typeof esm.default, 'function')
    assert.equal(esm.default, esm.makeWASocket)
    assert.equal(esm.jidNormalizedUser('123:9@s.whatsapp.net'), '123@s.whatsapp.net')
})

for (const name of ['alya', 'zapo']) {
    test(`${name} has usable CommonJS and ESM WaClient exports`, async () => {
        const cjs = require(`ourin-remake-baileys/${name}`)
        const esm = await import(`ourin-remake-baileys/${name}`)
        assert.equal(typeof cjs.WaClient, 'function')
        assert.equal(typeof esm.WaClient, 'function')
        const text = `Ourin ${name}`
        const encoded = cjs.proto.Message.encode({ conversation: text }).finish()
        assert.equal(cjs.proto.Message.decode(encoded).conversation, text)
        assert.equal(esm.proto.Message.decode(encoded).conversation, text)
    })
}

test('Baileys protobuf encoding retains text and quoted context', () => {
    const message = { extendedTextMessage: { text: 'test', contextInfo: { stanzaId: 'quoted-id', participant: '123@s.whatsapp.net' } } }
    const result = api.proto.Message.decode(api.proto.Message.encode(message).finish())
    assert.equal(result.extendedTextMessage.text, 'test')
    assert.equal(result.extendedTextMessage.contextInfo.stanzaId, 'quoted-id')
})

test('binary node encoder and decoder preserve a message stanza', async () => {
    const node = { tag: 'message', attrs: { id: 'TEST1', to: '123@s.whatsapp.net' }, content: [{ tag: 'body', attrs: {}, content: Buffer.from('hello') }] }
    const result = await api.decodeBinaryNode(await api.encodeBinaryNode(node))
    assert.equal(result.tag, 'message')
    assert.equal(result.attrs.to, node.attrs.to)
    assert.equal(Buffer.from(result.content[0].content).toString(), 'hello')
})

test('multi-file auth state saves and reloads credentials and Signal key buffers', async () => {
    const folder = await fs.mkdtemp(path.join(os.tmpdir(), 'ourin-auth-test-'))
    try {
        const { state, saveCreds } = await api.useMultiFileAuthState(folder)
        state.creds.registered = true
        await state.keys.set({ session: { fixture: Buffer.from([1, 2, 3, 4]) } })
        await saveCreds()
        const reloaded = await api.useMultiFileAuthState(folder)
        assert.equal(reloaded.state.creds.registered, true)
        assert.deepEqual(reloaded.state.creds.noiseKey.private, state.creds.noiseKey.private)
        assert.deepEqual((await reloaded.state.keys.get('session', ['fixture'])).fixture, Buffer.from([1, 2, 3, 4]))
    } finally { await fs.rm(folder, { recursive: true, force: true }) }
})

test('AES-GCM round trip and tamper rejection still work after bundling', () => {
    const key = Buffer.alloc(32, 7), iv = Buffer.alloc(12, 1), aad = Buffer.from('test')
    const original = Buffer.from('ourin payload')
    const encrypted = api.aesEncryptGCM(original, key, iv, aad)
    assert.deepEqual(api.aesDecryptGCM(encrypted, key, iv, aad), original)
    encrypted[0] ^= 1
    assert.throws(() => api.aesDecryptGCM(encrypted, key, iv, aad))
})

test('Alya link helpers are available through the Baileys entry point', () => {
    assert.equal(api.findFirstLink('https://chat.whatsapp.com/ABC123').kind, 'whatsapp_group_invite')
    assert.equal(api.getMessageText({ extendedTextMessage: { text: '.ping' } }), '.ping')
    assert.equal(api.findFirstLink('tidak ada tautan'), null)
})

test('migration preserves dependency aliases, unrelated dependencies, and input data', () => {
    const pkg = { dependencies: { baileys: '^6', axios: '^1' }, scripts: { start: 'node index.js' } }
    const before = structuredClone(pkg)
    const { result, changes } = planMigration(pkg, 'github:ellpigi/Ourin-remake-baileys#v1.0.0')
    assert.deepEqual(pkg, before)
    assert.equal(result.dependencies.baileys, 'github:ellpigi/Ourin-remake-baileys#v1.0.0')
    assert.equal(result.dependencies.axios, '^1')
    assert.deepEqual(result.scripts, before.scripts)
    assert.equal(changes.length, 1)
})

test('migration rejects unknown bot dependency names and invalid install specs', () => {
    assert.throws(() => planMigration({ dependencies: { 'different-client': '1' } }, 'github:user/repo'), /tidak ditemukan/)
    assert.throws(() => planMigration({ dependencies: { baileys: '1' } }, 'bad;command'), /Gunakan github/)
})

test('migration CLI previews, backs up, applies, and can run again safely', async () => {
    const folder = await fs.mkdtemp(path.join(os.tmpdir(), 'ourin-migration-test-'))
    const filename = path.join(folder, 'package.json')
    const before = '{"dependencies":{"ourin-baileys":"1"}}\n'
    const script = path.resolve('scripts/integrate-ourin.cjs')
    const args = [script, folder, 'github:ellpigi/Ourin-remake-baileys']
    try {
        await fs.writeFile(filename, before)
        execFileSync(process.execPath, args)
        assert.equal(await fs.readFile(filename, 'utf8'), before)
        execFileSync(process.execPath, [...args, '--write'])
        const files = await fs.readdir(folder)
        const backup = files.find(name => name.startsWith('package.json.before-ourin-'))
        assert.ok(backup)
        assert.equal(await fs.readFile(path.join(folder, backup), 'utf8'), before)
        assert.equal(JSON.parse(await fs.readFile(filename)).dependencies['ourin-baileys'], args[2])
        execFileSync(process.execPath, [...args, '--write'])
        assert.deepEqual(await fs.readdir(folder), files)
    } finally { await fs.rm(folder, { recursive: true, force: true }) }
})

test('basic bot validates phone numbers without starting a network connection', () => {
    const { normalizePhone } = require('../examples/basic-bot.cjs')
    assert.equal(normalizePhone('081234567890'), '6281234567890')
    assert.equal(normalizePhone('+62 812-3456-7890'), '6281234567890')
    assert.throws(() => normalizePhone('abc'), /Nomor/)
})
