import baileys = require('ourin-remake-baileys')
import alya = require('ourin-remake-baileys/alya')
import zapo = require('ourin-remake-baileys/zapo')

async function typedConsumer() {
    const { state } = await baileys.useMultiFileAuthState('never-executed')
    return baileys.default({ auth: state })
}
void [typedConsumer, alya.WaClient, zapo.WaClient]
