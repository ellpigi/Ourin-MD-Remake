# Ourin-remake-baileys

Paket gabungan untuk bot WhatsApp dengan API Baileys-Joss, modul Alya dan Zapo,
serta contoh bot dari ZIP Ourin-MD. Nama repository boleh `Ourin-remake-baileys`;
nama package/import menggunakan huruf kecil: `ourin-remake-baileys`.

## Isi gabungan

| Sumber dari lampiran | Peran dalam paket |
| --- | --- |
| Baileys-Joss 2.0.1 | Inti socket, autentikasi, Signal, media, grup, newsletter, interactive message, dan ekspor API Baileys. |
| alya-js 1.10.0 | API asli `WaClient` di `/alya`; helper `findFirstLink`, `getMessageText`, `WA_LINK_KINDS` juga tersedia dari pintu masuk utama. |
| zapo-js 1.10.0 | API asli `WaClient` di `/zapo`, terpisah dari state dan protobuf Baileys-Joss. |
| Ourin-MD 1.2.0 | Contoh bot modular di `examples/ourin-md`, sudah memakai package gabungan ini. Data user dan backup bawaan tidak disertakan. |

Ourin-MD adalah aplikasi bot, bukan implementasi Baileys keempat. Alya/Zapo
memakai API `WaClient`, bukan `makeWASocket`. Karena itu, gabungan ini memakai
satu API Baileys utama dan dua subpath API asli. Fitur `WaClient` tidak otomatis
menjadi method pada socket Baileys, dan ketiganya tidak berbagi sesi autentikasi.
Paket tambahan upstream seperti `@zapo-js/store-sqlite`, VoIP, dan native
accelerator tidak dibundel. Core dan protokol dari setiap sumber tetap tersedia
di `vendor/` untuk dikembangkan.

## Persyaratan

- Node.js **22.12.0 atau lebih baru**; disarankan Node.js 24 LTS.
- npm dan Git jika memasang dependency melalui GitHub.
- Akses internet ke registry npm dan WhatsApp saat dipakai.

Build CJS, ESM, dan deklarasi TypeScript sudah disertakan di `dist/` dan `types/`.
Instalasi dari GitHub tidak memerlukan TypeScript atau proses build otomatis.
Jangan menghapus kedua folder tersebut sebelum mengunggah ke GitHub.

## Unggah ke GitHub

1. Ekstrak ZIP ini.
2. Buat repository `Ourin-remake-baileys` di akun GitHub kamu.
3. Unggah **isi di dalam folder** `Ourin-remake-baileys/` ke root repository.
   Pastikan `package.json`, `dist/`, `types/`, `scripts/`, dan `vendor/`
   berada di root, bukan tertumpuk di dalam folder dengan nama yang sama.
4. Simpan semua file. `node_modules`, sesi, dan data hasil menjalankan bot tidak
   perlu diunggah.

Contoh di bawah memakai akun `ellpigi`, sesuai URL target yang diberikan.
Ganti pemilik repository bila akunmu berbeda. Repository ini harus sudah kamu
unggah sebelum perintah GitHub berikut bisa digunakan.

## Pasang di bot yang sudah ada

Jika kode bot memakai `require('baileys')` atau `import ... from 'baileys'`,
pertahankan nama dependency `baileys` di `package.json` dan ganti nilainya:

```json
{
  "dependencies": {
    "baileys": "github:ellpigi/Ourin-remake-baileys"
  }
}
```

Ini adalah **potongan** `package.json`; pertahankan dependency bot yang lain.
Nama dependency harus sama dengan string import botmu. Misalnya kode
`require('ourin-baileys')` harus memakai key `ourin-baileys`, atau kode
`require('@rexxhayanasi/elaina-baileys')` harus memakai key tersebut.

Kemudian jalankan di folder bot:

```bash
npm install
npm start
```

Nama baru juga bisa dipakai langsung:

```bash
npm install github:ellpigi/Ourin-remake-baileys --save
```

```js
const { default: makeWASocket, useMultiFileAuthState } = require('ourin-remake-baileys')
```

```js
import makeWASocket, { useMultiFileAuthState } from 'ourin-remake-baileys'
```

Lihat [panduan integrasi Ourin](docs/INSTALL-OURIN.md) untuk skrip penggantian
dependency, pin commit, dan pemecahan masalah.

## Jalankan contoh bot sederhana

Di folder hasil ekstrak, jalankan:

```bash
npm ci
npm start
```

Pada terminal interaktif, masukkan nomor seperti `6281234567890` untuk pairing
atau tekan Enter untuk QR. Pada panel server yang tidak menyediakan input
interaktif, atur environment variable `WA_NUMBER=6281234567890` sebelum start.
Di PowerShell gunakan `$env:WA_NUMBER='6281234567890'`; di Linux/macOS gunakan
`WA_NUMBER=6281234567890 npm start`.

Masukkan kode melalui WhatsApp > Perangkat tertaut > Tautkan perangkat >
Tautkan dengan nomor telepon. Setelah terhubung, kirim `.ping` atau `.menu`
dari nomor lain. Bot sederhana menyimpan sesi di `sessions/basic` dan mencoba
reconnect paling banyak 10 kali. Tekan Ctrl+C untuk berhenti.

## Jalankan contoh Ourin-MD modular

```bash
npm ci
cd examples/ourin-md
npm ci
npm start
```

Isi nomor owner di `examples/ourin-md/config.js` sebelum menjalankan bot.
Opsi `session.usePairingCode: true` meminta nomor lewat terminal. Untuk panel
tanpa terminal interaktif, tambahkan `pairingNumber: '628...'` di objek
`session` dalam config. Sesi contoh ini disimpan di `storage/session` relatif
terhadap folder bot. Jalankan dari `examples/ourin-md` agar jalur aset dan
database sesuai. Contoh ini berasal dari lampiran Ourin-MD, **bukan salinan
Ourin-MD-Remake**.

## Gunakan modul Alya atau Zapo

```js
const alya = require('ourin-remake-baileys/alya')
const zapo = require('ourin-remake-baileys/zapo')
// API asli: alya.WaClient, zapo.WaClient; membutuhkan store/config upstream.
```

```js
import { WaClient } from 'ourin-remake-baileys/alya'
```

API, event, dan store kedua modul mengikuti dokumentasi upstream masing-masing
di `vendor/alya/README.md` dan `vendor/zapo/README.md`. Jangan mengganti
`makeWASocket` dengan `WaClient` tanpa mengubah bot. Paket native optional tidak
terpasang secara default; modul bisa memakai fallback JavaScript/WebCrypto.
Fitur newsletter-status Alya masih eksperimental: helper atribusi bawaan
upstream memakai properti yang tidak diserialisasi oleh schema protobufnya.
Jalur tersebut tidak dinyatakan terverifikasi oleh paket ini.

## Verifikasi dan pengembangan

```bash
npm ci
npm run check
```

Perubahan source memerlukan `npm run build` dan `npm run build:types` sebelum
diunggah ulang. `scripts/build.cjs` menangani ekstensi import libsignal untuk
ESM serta membundel loader Rust/WASM upstream untuk ekspor CommonJS. Kode
protokol dan kriptografi Baileys-Joss tidak diubah.

Lihat [VALIDATION.md](VALIDATION.md) untuk hasil dan batas pengujian,
[catatan sumber](THIRD_PARTY_NOTICES.md) untuk lisensi dan patch, serta
`SOURCE-MANIFEST.json` untuk checksum lampiran.

Repository target `https://github.com/ellpigi/Ourin-MD-Remake` mengembalikan
404 saat persiapan. Karena source target tidak tersedia, kompatibilitas
khusus Remake belum dapat dipastikan. Integrasi disiapkan berdasarkan ZIP
Ourin-MD yang dilampirkan. Pairing, pengiriman pesan sungguhan, dan seluruh
plugin perlu diuji di perangkat/nomor pengguna.
