# Hasil verifikasi

Lingkungan: Linux x86_64, Node.js v24.19.0, npm 11.9.0.
Sumber: empat ZIP lampiran; checksum tersedia di SOURCE-MANIFEST.json.

## Pemeriksaan yang dijalankan

| Pemeriksaan | Hasil |
| --- | --- |
| Build bundle CJS dan ESM untuk API utama, Alya, Zapo | Lulus |
| Kompilasi deklarasi TypeScript ketiga source vendor | Lulus setelah patch integrasi yang dicatat |
| Pemeriksaan tipe source wrapper | Lulus |
| Consumer TypeScript dengan NodeNext, format ESM dan CommonJS | Lulus |
| Tes paket `npm test` | 13/13 lulus |
| Tes upstream Alya yang terkait link, fanout, status, newsletter | 65/65 lulus |
| Pemeriksaan syntax script dan contoh JavaScript | 42 file lulus |
| Impor modul Ourin `connection`, `handler`, dan seluruh library helper | Lulus tanpa membuka koneksi WhatsApp |
| Inisialisasi database LowDB Ourin | Lulus; file database fixture dibuat dalam direktori sementara lalu dihapus |
| Pemuatan plugin Ourin | 18 plugin berhasil dimuat |
| Handler `.ping` Ourin dengan socket fixture | Lulus tanpa pengiriman pesan sungguhan |
| `npm pack` dan instalasi arsip sebagai alias `baileys` dalam project terpisah | Lulus |
| `require('baileys')` dan `import ... from 'baileys'` pada instalasi terpisah | Lulus |
| Audit isi paket | Build dan tipe disertakan; node_modules, sesi, credential, dan data pengguna tidak disertakan |

Tes paket mencakup kontrak ekspor yang digunakan ZIP Ourin, encode/decode
protobuf, binary node round trip, persistensi credential dan key berbentuk
buffer pada fixture, AES-GCM round trip serta penolakan data yang diubah,
helper link, validasi nomor, dan pratinjau/backup/idempotensi skrip migrasi.
Fixture tidak berasal dari akun WhatsApp pengguna.

Instalasi terpisah memakai `npm install --omit=dev` agar pengujian tidak
bergantung pada development dependency paket. Percobaan pertama dengan
mode offline npm terhenti karena cache transitive dependency belum lengkap;
instalasi biasa dengan registry berhasil. Package ini tetap memerlukan
internet ketika dependency belum tersedia di server pengguna.

## Menjalankan ulang

```bash
npm ci
npm run check
npm run check:pack
```

Untuk pemeriksaan contoh Ourin:

```bash
npm ci --prefix examples/ourin-md
npm run check:ourin
```

Tes upstream Alya pilihan pada Linux/macOS:

```bash
npm run test:upstream:alya
```

## Batas verifikasi

- Repository `https://github.com/ellpigi/Ourin-MD-Remake` memberi respons
  GitHub API 404 saat diperiksa. Tidak ada source Remake yang diasumsikan
  identik dengan ZIP Ourin. Migrasi dependency tidak membuktikan kompatibilitas
  seluruh fitur fork lama atau seluruh plugin Remake.
- Tidak dilakukan pairing akun, pengiriman media sungguhan, atau pengujian
  event live di server WhatsApp. Ketersediaan API/modul dan tes offline tidak
  menjamin akun berhasil terhubung atau pesan tertentu diterima WhatsApp.
- Tidak dijalankan seluruh suite upstream maupun e2e upstream. Angka 65 hanya
  mencakup enam file tes Alya yang disebut dalam script npm.
- Namespace Alya/Zapo memakai API, store, event, dan format sesi asli mereka.
  Fitur itu tidak dipindahkan seluruhnya ke `makeWASocket` dan tidak bisa
  berbagi credential dengan inti Baileys-Joss.
- Helper atribusi newsletter-status Alya mempertahankan perilaku upstream;
  properti root `contextInfo` tidak diserialisasi schema Message lampiran.
  Jalur tersebut masih eksperimental, bukan fitur live yang telah dibuktikan.
- Node 22.12, Windows, macOS, dan Termux belum diuji runtime secara lokal.
  Workflow GitHub Actions disediakan untuk Node 22 dan 24 tetapi belum
  dijalankan di repository pengguna. Platform lain dapat memerlukan dependency
  media/native yang sesuai.

Paket ini belum diunggah atau dipublikasikan ke GitHub maupun registry npm.
URL instalasi GitHub baru berlaku sesudah pengguna mengunggahnya ke akun dan
repository yang disebut dalam perintah.
