import type { ExtendedPoint } from './types.js';
export declare function scalarMultBase(scalar: bigint): ExtendedPoint;
export declare function encodeExtendedPoint(point: ExtendedPoint): Uint8Array;
