import { type Fe } from './fe.js';
import type { ExtendedPoint } from './types.js';
export declare const FIELD_P: bigint;
export declare const GROUP_L: bigint;
export declare const FE_TWO_D: Fe;
export declare const FE_ONE: Fe;
export declare const BASE_POINT: ExtendedPoint;
export declare const IDENTITY_POINT: ExtendedPoint;
