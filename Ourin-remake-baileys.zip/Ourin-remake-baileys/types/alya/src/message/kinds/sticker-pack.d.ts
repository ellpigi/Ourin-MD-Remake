import { type StickerPackZipEntry } from '../../media/sticker/sticker-pack.js';
import type { WaSendStickerPackMessage } from '../types.js';
import type { Proto } from '../../proto.js';
export declare function validateStickerPackInput(content: WaSendStickerPackMessage): void;
export declare function toStickerPackZipEntries(content: WaSendStickerPackMessage): StickerPackZipEntry[];
export declare function toStickerPackProtoStickers(content: WaSendStickerPackMessage): Proto.Message.StickerPackMessage.ISticker[];
