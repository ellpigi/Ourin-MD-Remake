import type { WaMediaConn } from '../types.js';
import type { BinaryNode } from '../../transport/types.js';
/**
 * Parses a `media_conn` IQ response into a {@link WaMediaConn} (auth token,
 * absolute expiry, and host list). Throws on missing auth/ttl/hosts.
 */
export declare function parseMediaConnResponse(node: BinaryNode, nowMs: number): WaMediaConn;
