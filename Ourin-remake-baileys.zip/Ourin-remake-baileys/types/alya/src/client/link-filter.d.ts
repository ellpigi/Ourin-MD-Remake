import type { WaIncomingMessageEvent } from './types.js';
import { isGroupJid } from '../protocol/jid.js';
export interface WaLinkMatch {
    readonly kind: WaLinkKind;
    readonly url: string;
}
export declare const WA_LINK_KINDS: Readonly<{
    readonly TIKTOK: "tiktok";
    readonly INSTAGRAM: "instagram";
    readonly FACEBOOK: "facebook";
    readonly WHATSAPP_CHANNEL: "whatsapp_channel";
    readonly WHATSAPP_GROUP_INVITE: "whatsapp_group_invite";
    readonly TELEGRAM: "telegram";
    readonly GENERIC: "generic";
}>;
export type WaLinkKind = (typeof WA_LINK_KINDS)[keyof typeof WA_LINK_KINDS];
/** Extracts the first link in `text` and classifies it. */
export declare function findFirstLink(text: string): WaLinkMatch | null;
/** Pulls the display text out of any message content shape. */
export declare function getMessageText(message: unknown): string;
export interface WaLinkFilterOptions {
    /** Decides whether a sender may post links. Defaults to admins and super-admins. */
    readonly isAllowedSender: (groupJid: string, senderJid: string) => Promise<boolean>;
    /** Removes the offending message. Defaults to a no-op returning `false`. */
    readonly deleteMessage?: (chatJid: string, id: string, participant?: string) => Promise<boolean>;
    readonly logger?: {
        readonly debug: (m: string, c?: unknown) => void;
    };
    /** Restrict the filter to these link kinds. Omit for every matched kind. */
    readonly kinds?: readonly WaLinkKind[];
}
export interface WaLinkFilterResult {
    readonly matched: boolean;
    readonly kind?: WaLinkKind;
    readonly url?: string;
    readonly action: 'ignored' | 'allowed' | 'deleted' | 'delete_failed';
}
/**
 * Decides what to do with an incoming group message that carries a link.
 *
 * Pure with respect to I/O: the only side effects are through the injected
 * `isAllowedSender` / `deleteMessage` ports, so the decision is testable
 * without a connection.
 */
export declare function evaluateGroupLink(event: WaIncomingMessageEvent, options: WaLinkFilterOptions): Promise<WaLinkFilterResult>;
/**
 * Builds an `isAllowedSender` from a group-metadata lookup: admins, super
 * admins, and the group owner pass.
 */
export declare function createAdminAllowList(loadMetadata: (groupJid: string) => Promise<{
    readonly owner?: string;
    readonly participants: readonly {
        readonly jid: string;
        readonly type: string;
    }[];
} | null>, allowOwners?: boolean): (groupJid: string, senderJid: string) => Promise<boolean>;
export { isGroupJid };
