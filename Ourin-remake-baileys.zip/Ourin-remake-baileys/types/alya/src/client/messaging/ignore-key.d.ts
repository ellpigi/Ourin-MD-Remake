import type { WaAuthCredentials } from '../../auth/types.js';
import type { WaIgnoreKey, WaIgnoreKeyContext, WaIgnoreKeyPredicate, WaIncomingStanzaFilter } from '../types.js';
import type { BinaryNode } from '../../transport/types.js';
export declare function validateIgnoreKey(d: WaIgnoreKey): void;
/**
 * Builds the parsed context handed to a {@link WaIgnoreKeyPredicate}. Returns
 * `null` when the node's tag is not one of the addressable kinds (`<iq>`, etc.).
 */
export declare function extractIgnoreKeyContext(node: BinaryNode, meJid: string | null | undefined): WaIgnoreKeyContext | null;
/** Pure matcher. Exported for direct testing without a coordinator. */
export declare function matchesIgnoreKey(node: BinaryNode, d: WaIgnoreKey, meJid: string | null | undefined): boolean;
export declare function createIgnoreKeyFilter(input: WaIgnoreKey | WaIgnoreKeyPredicate, getMe: () => Pick<WaAuthCredentials, 'meJid' | 'meLid'> | null | undefined): WaIncomingStanzaFilter;
