import type { WaAuthCredentials } from '../../auth/types.js';
import type { Logger } from '../../infra/log/types.js';
import type { SignalDeviceSyncApi } from '../../signal/api/SignalDeviceSyncApi.js';
export type DeviceFanoutResolver = {
    /**
     * Device JIDs an outgoing direct message is encrypted to. With
     * `noSelfSync`, none of this account's own devices are included, so the
     * message is delivered to the recipient without landing in the paired
     * phones' own chat.
     */
    resolveDirectFanoutDeviceJids(recipientJid: string, selfDeviceJid: string, noSelfSync?: boolean): Promise<readonly string[]>;
    /**
     * Device JIDs an outgoing group message is encrypted to. Always drops the
     * account's base JIDs; `noSelfSync` additionally drops its secondary
     * devices, which the participant scan would otherwise carry through.
     */
    resolveGroupParticipantDeviceJids(participantUserJids: readonly string[], noSelfSync?: boolean): Promise<readonly string[]>;
    resolveOwnPeerDeviceJids(): Promise<readonly string[]>;
    resolveSelfDeviceJidForRecipient(recipientJid: string, meJid: string, meLid: string | null | undefined): string;
};
export declare function createDeviceFanoutResolver(options: {
    readonly signalDeviceSync: SignalDeviceSyncApi;
    readonly getCurrentCredentials: () => WaAuthCredentials | null;
    readonly logger: Logger;
}): DeviceFanoutResolver;
