import { WaAppStateSyncClient } from '../appstate/sync/WaAppStateSyncClient.js';
import type { WaAppStateSyncOptions, WaAppStateSyncResult } from '../appstate/types.js';
import { WaAuthClient } from '../auth/WaAuthClient.js';
import { WaConnectionManager } from './connection/WaConnectionManager.js';
import { WaReceiptQueue } from './connection/WaReceiptQueue.js';
import { WaAbPropsCoordinator } from './coordinators/WaAbPropsCoordinator.js';
import { WaAppStateMutationCoordinator } from './coordinators/WaAppStateMutationCoordinator.js';
import { type WaBotCoordinator } from './coordinators/WaBotCoordinator.js';
import { type WaBroadcastListCoordinator } from './coordinators/WaBroadcastListCoordinator.js';
import { type WaBusinessCoordinator } from './coordinators/WaBusinessCoordinator.js';
import { type WaEmailCoordinator } from './coordinators/WaEmailCoordinator.js';
import { type WaGroupCoordinator } from './coordinators/WaGroupCoordinator.js';
import { WaIncomingNodeCoordinator } from './coordinators/WaIncomingNodeCoordinator.js';
import { type WaLowLevelCoordinator } from './coordinators/WaLowLevelCoordinator.js';
import { WaMessageCoordinator } from './coordinators/WaMessageCoordinator.js';
import { WaMessageDispatchCoordinator } from './coordinators/WaMessageDispatchCoordinator.js';
import { WaMobileCoordinator } from './coordinators/WaMobileCoordinator.js';
import { type WaNewsletterCoordinator } from './coordinators/WaNewsletterCoordinator.js';
import { WaPassiveTasksCoordinator } from './coordinators/WaPassiveTasksCoordinator.js';
import { type WaPresenceCoordinator } from './coordinators/WaPresenceCoordinator.js';
import { type WaPrivacyCoordinatorRuntime } from './coordinators/WaPrivacyCoordinator.js';
import { type WaProfileCoordinator } from './coordinators/WaProfileCoordinator.js';
import { WaRetryCoordinator } from './coordinators/WaRetryCoordinator.js';
import { type WaStatusCoordinator } from './coordinators/WaStatusCoordinator.js';
import { type WaStreamControlHandler } from './coordinators/WaStreamControlCoordinator.js';
import { WaTrustedContactTokenCoordinator } from './coordinators/WaTrustedContactTokenCoordinator.js';
import { type WaMediaMessageOptions } from './messaging/messages.js';
import type { WaClientEventMap, WaClientOptions, WaIncomingMessageEvent, WaIncomingProtocolMessageEvent } from './types.js';
import type { Logger } from '../infra/log/types.js';
import { WaMediaTransferClient } from '../media/transfer/WaMediaTransferClient.js';
import { type PeerDataOperationRequester } from '../message/primitives/peer-data-operation.js';
import { WaMessageClient } from '../message/WaMessageClient.js';
import { SignalDeviceSyncApi } from '../signal/api/SignalDeviceSyncApi.js';
import { SignalDigestSyncApi } from '../signal/api/SignalDigestSyncApi.js';
import { SignalIdentitySyncApi } from '../signal/api/SignalIdentitySyncApi.js';
import { SignalMissingPreKeysSyncApi } from '../signal/api/SignalMissingPreKeysSyncApi.js';
import { SignalRotateKeyApi } from '../signal/api/SignalRotateKeyApi.js';
import { SignalSessionSyncApi } from '../signal/api/SignalSessionSyncApi.js';
import { SenderKeyManager } from '../signal/group/SenderKeyManager.js';
import { type SignalSessionResolver } from '../signal/session/resolver.js';
import { SignalProtocol } from '../signal/session/SignalProtocol.js';
import type { WaStoredContactRecord } from '../store/contracts/contact.store.js';
import { WaKeepAlive } from '../transport/keepalive/WaKeepAlive.js';
import { WaNodeOrchestrator } from '../transport/node/WaNodeOrchestrator.js';
import { WaNodeTransport } from '../transport/node/WaNodeTransport.js';
import type { BinaryNode } from '../transport/types.js';
interface WaClientBase {
    readonly options: Readonly<WaClientOptions>;
    readonly logger: Logger;
    readonly sessionStore: ReturnType<WaClientOptions['store']['session']>;
}
interface WaClientBuildRuntime {
    readonly sendNode: (node: BinaryNode) => Promise<void>;
    readonly query: (node: BinaryNode, timeoutMs?: number, options?: {
        readonly useSystemId?: boolean;
    }) => Promise<BinaryNode>;
    readonly queryWithContext: (context: string, node: BinaryNode, timeoutMs?: number, contextData?: Readonly<Record<string, unknown>>, options?: {
        readonly useSystemId?: boolean;
    }) => Promise<BinaryNode>;
    readonly syncAppState: () => Promise<void>;
    readonly syncAppStateWithOptions: (options?: WaAppStateSyncOptions) => Promise<WaAppStateSyncResult>;
    readonly emitEvent: <K extends keyof WaClientEventMap>(event: K, ...args: Parameters<WaClientEventMap[K]>) => void;
    /** Whether anything is subscribed, for events whose payload costs something to build. */
    readonly hasEventListener: (event: keyof WaClientEventMap) => boolean;
    readonly handleIncomingMessageEvent: (event: WaIncomingMessageEvent) => Promise<void>;
    readonly handleError: (error: Error) => void;
    readonly handleIncomingFrame: (frame: Uint8Array) => Promise<void>;
    readonly clearStoredState: () => Promise<void>;
    readonly resumeIncomingEvents: () => void;
    readonly subscribeProtocolMessage: (handler: (event: WaIncomingProtocolMessageEvent) => void) => () => void;
    /**
     * Sink for address-book contact rows synced over app-state. Wired by
     * `WaClient` to {@link WriteBehindPersistence.persistContact} so Contact
     * mutations land in the contact store at pair-time (snapshot) and on
     * every incremental sync.
     */
    readonly persistContact: (record: WaStoredContactRecord) => void;
}
/**
 * Internal coordinator graph wired by {@link buildWaClientDependencies}. Exposed
 * to {@link WaClientPluginContext.deps} for plugin authors – advanced API; new
 * coordinators may appear in minor releases.
 */
export interface WaClientDependencies {
    readonly nodeTransport: WaNodeTransport;
    readonly nodeOrchestrator: WaNodeOrchestrator;
    readonly keepAlive: WaKeepAlive;
    readonly mediaTransfer: WaMediaTransferClient;
    readonly mediaMessageBuildOptions: WaMediaMessageOptions;
    readonly messageClient: WaMessageClient;
    readonly senderKeyManager: SenderKeyManager;
    readonly signalProtocol: SignalProtocol;
    readonly signalDigestSync: SignalDigestSyncApi;
    readonly signalDeviceSync: SignalDeviceSyncApi;
    readonly signalIdentitySync: SignalIdentitySyncApi;
    readonly signalMissingPreKeysSync: SignalMissingPreKeysSyncApi;
    readonly signalRotateKey: SignalRotateKeyApi;
    readonly signalSessionSync: SignalSessionSyncApi;
    readonly sessionResolver: SignalSessionResolver;
    readonly authClient: WaAuthClient;
    readonly messageDispatch: WaMessageDispatchCoordinator;
    readonly messageCoordinator: WaMessageCoordinator;
    readonly presenceCoordinator: WaPresenceCoordinator;
    readonly retryCoordinator: WaRetryCoordinator;
    readonly appStateSync: WaAppStateSyncClient;
    readonly chatCoordinator: WaAppStateMutationCoordinator;
    readonly streamControl: WaStreamControlHandler;
    readonly incomingNode: WaIncomingNodeCoordinator;
    readonly lowLevelCoordinator: WaLowLevelCoordinator;
    readonly passiveTasks: WaPassiveTasksCoordinator;
    readonly groupCoordinator: WaGroupCoordinator;
    readonly statusCoordinator: WaStatusCoordinator;
    readonly broadcastListCoordinator: WaBroadcastListCoordinator;
    readonly newsletterCoordinator: WaNewsletterCoordinator;
    readonly privacyCoordinator: WaPrivacyCoordinatorRuntime;
    readonly profileCoordinator: WaProfileCoordinator;
    readonly businessCoordinator: WaBusinessCoordinator;
    readonly botCoordinator: WaBotCoordinator;
    readonly emailCoordinator: WaEmailCoordinator;
    readonly receiptQueue: WaReceiptQueue;
    readonly connectionManager: WaConnectionManager;
    readonly trustedContactToken: WaTrustedContactTokenCoordinator;
    readonly abPropsCoordinator: WaAbPropsCoordinator;
    readonly peerDataOperation: PeerDataOperationRequester;
    readonly mobileCoordinator: WaMobileCoordinator;
    readonly isMobilePrimary: () => boolean;
}
export declare function resolveWaClientBase(options: WaClientOptions, logger: Logger): WaClientBase;
export declare function buildWaClientDependencies(input: {
    readonly base: WaClientBase;
    readonly runtime: WaClientBuildRuntime;
}): WaClientDependencies;
export {};
