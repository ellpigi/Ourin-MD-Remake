import { type Proto } from '../proto.js';
import type { WaMessageStore } from '../store/contracts/message.store.js';
/** Status media kinds a caller can ask for. Text is deliberately excluded. */
export declare const WA_STATUS_MEDIA_KINDS: Readonly<{
    readonly IMAGE: "image";
    readonly VIDEO: "video";
    readonly AUDIO: "audio";
    readonly DOCUMENT: "document";
    readonly STICKER: "sticker";
}>;
export type WaStatusMediaKind = (typeof WA_STATUS_MEDIA_KINDS)[keyof typeof WA_STATUS_MEDIA_KINDS];
export interface WaStatusEntry {
    readonly id: string;
    /** Author of the status: the owner for `status@broadcast`, the group for a group status. */
    readonly ownerJid: string;
    /** Chat the status lives in: `status@broadcast`, or the group JID. */
    readonly chatJid: string;
    readonly fromMe: boolean;
    readonly timestampMs?: number;
    readonly mediaKind: WaStatusMediaKind;
    readonly mimetype?: string;
    readonly caption?: string;
    readonly message: Proto.IMessage;
}
export interface WaStatusListOptions {
    /** Owner to filter by. Omit to list every author seen so far. */
    readonly owner?: string;
    /** Only entries newer than this timestamp (ms). */
    readonly since?: number;
    /** Restrict to these media kinds. Omit for every kind. */
    readonly kinds?: readonly WaStatusMediaKind[];
    /** Caps the scan. Defaults to the store page size. */
    readonly limit?: number;
}
/**
 * Classifies a stored message into a status media kind, or `null` when it
 * carries no media (text status, poll, protocol message, reaction).
 */
export declare function classifyStatusMedia(message: Proto.IMessage | null | undefined): WaStatusMediaKind | null;
/**
 * Lists statuses from the message store.
 *
 * Statuses are not stored in a dedicated table: contact statuses land in the
 * `status@broadcast` thread with the owner on `participantJid`, and group
 * statuses land in the group thread. Both are therefore a thread scan, so
 * `listByThread` is called once per target chat and filtered in memory.
 *
 * Only statuses this client actually observed are returned. Anything missed
 * while disconnected was never persisted and cannot be recovered here.
 */
export declare function listStatuses(messageStore: WaMessageStore, options: WaStatusListOptions & {
    readonly chats: readonly string[];
}): Promise<readonly WaStatusEntry[]>;
export declare function statusBroadcastJid(): string;
