import type { WriteBehindPersistence } from './WriteBehindPersistence.js';
import type { WaIncomingMessageEvent } from '../types.js';
import type { Logger } from '../../infra/log/types.js';
import type { WaMessageSecretStore } from '../../store/contracts/message-secret.store.js';
interface WaPersistIncomingMailboxOptions {
    readonly logger: Logger;
    readonly writeBehind: WriteBehindPersistence;
    readonly messageSecretStore: WaMessageSecretStore;
    /**
     * When `true`, persist the secret of every incoming message, not only the
     * poll / event / bot prompts that `needsSecretPersistence` flags. Wired
     * from the client-level `addons.persistAllSecrets` option.
     */
    readonly persistAllSecrets?: boolean;
    readonly event: WaIncomingMessageEvent;
}
export declare function persistIncomingMailboxEntities(options: WaPersistIncomingMailboxOptions): void;
export {};
