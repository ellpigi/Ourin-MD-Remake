import type { WaBusinessEvent, WaBusinessProfileResult, WaIncomingUnhandledStanzaEvent, WaVerifiedNameResult } from '../types.js';
import type { BinaryNode } from '../../transport/types.js';
interface WaParseBusinessNotificationResult {
    readonly events: readonly WaBusinessEvent[];
    readonly unhandled: readonly WaIncomingUnhandledStanzaEvent[];
}
export declare function parseVerifiedNameNode(node: BinaryNode): WaVerifiedNameResult | null;
export declare function parseBusinessProfileNode(node: BinaryNode): WaBusinessProfileResult | null;
export declare function parseBusinessNotificationEvents(notificationNode: BinaryNode): WaParseBusinessNotificationResult;
export {};
