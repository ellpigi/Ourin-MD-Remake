import type { WaGroupEvent, WaGroupEventParticipant, WaIncomingUnhandledStanzaEvent } from '../types.js';
import type { BinaryNode } from '../../transport/types.js';
interface WaParseGroupNotificationResult {
    readonly events: readonly WaGroupEvent[];
    readonly unhandled: readonly WaIncomingUnhandledStanzaEvent[];
}
export declare function parseParticipants(node: BinaryNode): readonly WaGroupEventParticipant[];
export declare function parseGroupNotificationEvents(notificationNode: BinaryNode): WaParseGroupNotificationResult;
export {};
