import type { WaAppStateMutation } from '../../appstate/types.js';
import type { WaAppStateMutationEvent } from '../types.js';
export declare function parseAppStateMutationEvent(mutation: WaAppStateMutation): WaAppStateMutationEvent | null;
