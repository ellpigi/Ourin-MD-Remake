import type { WaIncomingUnhandledStanzaEvent, WaPictureEvent } from '../types.js';
import type { BinaryNode } from '../../transport/types.js';
interface WaParsePictureNotificationResult {
    readonly events: readonly WaPictureEvent[];
    readonly unhandled: readonly WaIncomingUnhandledStanzaEvent[];
}
export declare function parsePictureNotificationEvents(node: BinaryNode): WaParsePictureNotificationResult;
export {};
