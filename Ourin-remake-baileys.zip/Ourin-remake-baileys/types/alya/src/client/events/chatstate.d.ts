import type { ChatstateMedia, ChatstateState } from '../../transport/node/builders/chatstate.js';
import type { BinaryNode } from '../../transport/types.js';
interface ParsedChatstate {
    readonly state: ChatstateState;
    readonly media?: ChatstateMedia;
    readonly participantJid?: string;
}
export declare function parseChatstateNode(node: BinaryNode): ParsedChatstate | null;
export {};
