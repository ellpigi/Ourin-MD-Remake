import { proto, type Proto } from '../../proto.js';
/** Mirrors `WAProto.CallLogRecord.CallResult`. */
export declare const WA_CALL_LOG_RESULTS: Readonly<{
    readonly CONNECTED: "CONNECTED";
    readonly REJECTED: "REJECTED";
    readonly CANCELLED: "CANCELLED";
    readonly ACCEPTED_ELSEWHERE: "ACCEPTEDELSEWHERE";
    readonly MISSED: "MISSED";
    readonly INVALID: "INVALID";
    readonly UNAVAILABLE: "UNAVAILABLE";
    readonly UPCOMING: "UPCOMING";
    readonly FAILED: "FAILED";
    readonly ABANDONED: "ABANDONED";
    readonly ONGOING: "ONGOING";
}>;
export type WaCallLogResult = (typeof WA_CALL_LOG_RESULTS)[keyof typeof WA_CALL_LOG_RESULTS];
/** Mirrors `WAProto.CallLogRecord.CallType`. */
export declare const WA_CALL_LOG_TYPES: Readonly<{
    readonly REGULAR: "REGULAR";
    readonly SCHEDULED_CALL: "SCHEDULED_CALL";
    readonly VOICE_CHAT: "VOICE_CHAT";
}>;
export type WaCallLogType = (typeof WA_CALL_LOG_TYPES)[keyof typeof WA_CALL_LOG_TYPES];
export interface WaCallLogParticipant {
    readonly jid: string;
    readonly callResult?: WaCallLogResult;
}
export interface WaCallLogRecord {
    readonly callId: string;
    readonly creatorJid?: string;
    readonly groupJid?: string;
    /** Unix seconds. */
    readonly startTime?: number;
    /** Seconds the call lasted. */
    readonly duration?: number;
    readonly result?: WaCallLogResult;
    readonly callType: WaCallLogType;
    readonly isIncoming: boolean;
    readonly isVideo: boolean;
    readonly isCallLink: boolean;
    readonly isDndMode: boolean;
    readonly scheduledCallId?: string;
    readonly participants: readonly WaCallLogParticipant[];
}
/**
 * Parses a single `CallLogRecord` out of an app-state `callLogAction` patch
 * (schema `CallLog`, value field `callLogAction`).
 *
 * Parse-only. The record fields are fixed by the vendored proto; which
 * notification delivers the patch still needs a real-flow test.
 */
export declare function parseCallLogRecord(record: Proto.ICallLogRecord | null | undefined): WaCallLogRecord | null;
export { proto };
