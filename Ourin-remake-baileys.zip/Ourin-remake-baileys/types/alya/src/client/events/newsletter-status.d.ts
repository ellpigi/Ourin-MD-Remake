import { type Proto } from '../../proto.js';
import { getNodeTextContent } from '../../transport/node/helpers.js';
import type { BinaryNode } from '../../transport/types.js';
/** Acknowledgement of a newsletter status publication. */
export interface WaNewsletterStatusAck {
    readonly class?: string;
    readonly from?: string;
    readonly id?: string;
    readonly t?: number;
    readonly serverId?: number;
    readonly edit?: string;
    readonly error?: string;
    readonly applicationError?: number;
    readonly backoff?: number;
    readonly node: BinaryNode;
}
export interface WaNewsletterStatusAdminProfile {
    readonly id?: string;
    readonly name?: string;
    readonly pictureId?: string;
    readonly pictureDirectPath?: string;
}
export interface WaNewsletterStatusReactionCount {
    readonly code?: string;
    readonly count?: number;
}
export interface WaNewsletterStatus {
    readonly id?: string;
    readonly serverId?: number;
    readonly t?: number;
    readonly isSender: boolean;
    readonly type?: string;
    readonly edit?: string;
    readonly mediaType?: string;
    readonly interactionType?: string;
    readonly reaction?: string;
    readonly adminProfile?: WaNewsletterStatusAdminProfile;
    readonly paidPartnership: boolean;
    readonly aiContent: boolean;
    readonly editTimestamp?: number;
    readonly originalTimestamp?: number;
    readonly reactionCounts?: readonly WaNewsletterStatusReactionCount[];
    readonly viewsCount?: number;
    readonly responsesCount?: number;
    readonly message?: Proto.IMessage;
    readonly node: BinaryNode;
}
export interface WaNewsletterStatusesPage {
    readonly jid?: string;
    readonly t?: number;
    readonly statuses: readonly WaNewsletterStatus[];
}
/**
 * Parses an `<ack>` for a newsletter status publish. Throws on a class, id or
 * `from` mismatch so a mismatched ack is never mistaken for success.
 */
export declare function parseNewsletterStatusAck(node: BinaryNode, expected?: {
    readonly jid?: string;
    readonly messageId?: string;
}): WaNewsletterStatusAck;
/** Parses one `<status>` node out of a statuses list or update. */
export declare function parseNewsletterStatusNode(status: BinaryNode): WaNewsletterStatus;
/**
 * Parses a `<statuses>` list.
 *
 * Throws when the wrapper is absent rather than returning an empty list, so a
 * shape change surfaces as an error instead of looking like an empty channel.
 */
export declare function parseNewsletterStatusesResponse(node: BinaryNode): WaNewsletterStatusesPage;
/** Parses a `<status_updates>` response. */
export declare function parseNewsletterStatusUpdatesResponse(node: BinaryNode): WaNewsletterStatusesPage;
/**
 * Reads a server id out of a `<status>` echo. The publish ack carries only
 * `class`, `id`, and `t`; the server id arrives in a separate stanza, and a
 * reaction or revoke cannot be built without it.
 */
export declare function readNewsletterStatusServerId(node: BinaryNode): number | undefined;
export { getNodeTextContent };
