import type { WaAppStateMutationCoordinator, WaSetStatusPrivacyInput } from './WaAppStateMutationCoordinator.js';
import type { WaStatusInteractions } from './status-interactions.js';
import type { WaMessageStore } from '../../store/contracts/message.store.js';
import type { WaSendMessageOptions } from '../types.js';
import type { WaMessageBuildResult, WaMessagePublishResult, WaSendMessageContent } from '../../message/types.js';
import { type Proto } from '../../proto.js';
import type { WaStatusDistributionSetting } from '../../protocol/status.js';
export interface WaStatusCoordinatorOptions {
    readonly appStateMutations: WaAppStateMutationCoordinator;
    readonly buildMessageContent: (content: WaSendMessageContent) => Promise<WaMessageBuildResult>;
    readonly publishStatusMessage: (input: {
        readonly message: Proto.IMessage;
        readonly recipients: readonly string[];
        readonly statusSetting?: WaStatusDistributionSetting;
        readonly options?: WaSendMessageOptions;
    }) => Promise<WaMessagePublishResult>;
    /** Required for the reaction / apply / download half of the surface. */
    readonly messageStore?: WaMessageStore;
    readonly sendMessage?: (to: string, content: WaSendMessageContent, options?: WaSendMessageOptions) => Promise<WaMessagePublishResult>;
    readonly downloadBytes?: (source: {
        readonly message: Proto.IMessage;
    }, options?: {
        readonly maxBytes?: number;
    }) => Promise<Uint8Array>;
}
export interface WaSendStatusInput {
    readonly content: WaSendMessageContent;
    readonly recipients: readonly string[];
    readonly statusSetting?: WaStatusDistributionSetting;
    readonly options?: WaSendMessageOptions;
}
/**
 * Coordinates the status-broadcast surface: distribution privacy, per-contact
 * mute, send, and revoke. Accessed via {@link WaClient.status}.
 */
export interface WaStatusCore {
    /** Updates the account-wide status privacy setting (see {@link WaSetStatusPrivacyInput}). */
    readonly setPrivacy: (input: WaSetStatusPrivacyInput) => Promise<void>;
    /** Mutes or unmutes a specific contact's status broadcasts. */
    readonly setUserMuted: (jid: string, muted: boolean) => Promise<void>;
    /** Publishes a status broadcast to the given recipients. */
    readonly send: (input: WaSendStatusInput) => Promise<WaMessagePublishResult>;
    /** Revokes a previously-published status broadcast. */
    readonly revokeStatus: (input: {
        readonly messageId: string;
        readonly recipients: readonly string[];
        readonly statusSetting?: WaStatusDistributionSetting;
        readonly options?: WaSendMessageOptions;
    }) => Promise<WaMessagePublishResult>;
}
/**
 * The full `client.status` surface: the send/revoke core plus the reaction,
 * bulk-apply, and download operations from `status-interactions`.
 */
export type WaStatusCoordinator = WaStatusCore & WaStatusInteractions;
/** Builds a {@link WaStatusCoordinator} from its dependencies. */
export declare function createStatusCoordinator(options: WaStatusCoordinatorOptions & {
    readonly messageStore: WaMessageStore;
    readonly sendMessage: NonNullable<WaStatusCoordinatorOptions['sendMessage']>;
    readonly downloadBytes: NonNullable<WaStatusCoordinatorOptions['downloadBytes']>;
}): WaStatusCoordinator;
export declare function createStatusCoordinator(options: WaStatusCoordinatorOptions): WaStatusCore;
