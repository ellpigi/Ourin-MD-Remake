import type { WaAppStateSyncKey } from '../../appstate/types.js';
import type { WaAuthCredentials } from '../../auth/types.js';
import type { DeviceFanoutResolver } from '../messaging/fanout.js';
import type { GroupMetadataCache } from '../messaging/group-metadata.js';
import type { AppStateSyncKeyProtocol } from '../messaging/key-protocol.js';
import type { WaGroupEvent, WaOutgoingMessageEvent, WaSendMessageOptions, WaSignalMessagePublishInput } from '../types.js';
import type { Logger } from '../../infra/log/types.js';
import { type WaSendContextInfo } from '../../message/context-info.js';
import { type IcdcMeta } from '../../message/crypto/icdc.js';
import { type WaOutboundMessageAttrs } from '../../message/encode/content.js';
import type { WaEncryptedMessageInput, WaMessageBuildResult, WaMessagePublishOptions, WaMessagePublishResult, WaSendMessageContent, WaSendReceiptInput } from '../../message/types.js';
import type { WaMessageClient } from '../../message/WaMessageClient.js';
import { type Proto } from '../../proto.js';
import { type WaStatusDistributionSetting } from '../../protocol/constants.js';
import type { OutboundRetryTracker } from '../../retry/tracker.js';
import type { SignalDeviceSyncApi } from '../../signal/api/SignalDeviceSyncApi.js';
import type { SenderKeyManager } from '../../signal/group/SenderKeyManager.js';
import type { SignalSessionResolver } from '../../signal/session/resolver.js';
import type { SignalProtocol } from '../../signal/session/SignalProtocol.js';
import type { SignalAddress } from '../../signal/types.js';
import type { WaChatMetadataStore } from '../../store/contracts/chat-metadata.store.js';
import type { WaDeviceListStore } from '../../store/contracts/device-list.store.js';
import type { WaIdentityStore } from '../../store/contracts/identity.store.js';
import type { WaMessageSecretStore } from '../../store/contracts/message-secret.store.js';
import type { WaSessionStore } from '../../store/contracts/session.store.js';
import type { WaSignalStore } from '../../store/contracts/signal.store.js';
import type { WaThreadStore } from '../../store/contracts/thread.store.js';
import type { BinaryNode } from '../../transport/types.js';
import type { ServerClock } from '../../util/clock.js';
interface WaMessageDispatchCoordinatorOptions {
    readonly logger: Logger;
    /** Emits the outbound decrypted message (`message_send` event); best-effort. */
    readonly emitMessageSend?: (event: WaOutgoingMessageEvent) => void;
    readonly messageClient: WaMessageClient;
    readonly retryTracker: OutboundRetryTracker;
    readonly sessionResolver: SignalSessionResolver;
    readonly fanoutResolver: DeviceFanoutResolver;
    readonly groupMetadataCache: GroupMetadataCache;
    readonly appStateSyncKeyProtocol: AppStateSyncKeyProtocol;
    readonly buildMessageContent: (content: WaSendMessageContent, ctx?: {
        readonly to: string;
        readonly outgoingStanzaId?: string;
        readonly meJid?: string;
    }) => Promise<WaMessageBuildResult>;
    readonly senderKeyManager: SenderKeyManager;
    readonly signalProtocol: SignalProtocol;
    readonly signalStore: WaSignalStore;
    readonly sessionStore: WaSessionStore;
    readonly identityStore: WaIdentityStore;
    readonly deviceListStore: WaDeviceListStore;
    readonly threadStore: WaThreadStore;
    readonly chatMetadataStore: WaChatMetadataStore;
    readonly signalDeviceSync: SignalDeviceSyncApi;
    readonly messageSecretStore: WaMessageSecretStore;
    /**
     * When `true`, persist the message secret for every outgoing message, not
     * only the poll / event / bot prompts that `needsSecretPersistence` flags.
     * Wired from the client-level `addons.persistAllSecrets` option.
     */
    readonly persistAllMessageSecrets?: boolean;
    readonly getCurrentCredentials: () => WaAuthCredentials | null;
    readonly resolvePrivacyTokenNode: (recipientJid: string) => Promise<BinaryNode | null>;
    readonly onDirectMessageSent: (recipientJid: string) => void;
    readonly sendNewsletterMessage?: (newsletterJid: string, content: WaSendMessageContent, options: WaSendMessageOptions, contextInfo: WaSendContextInfo | null) => Promise<WaMessagePublishResult>;
    readonly getIcdcHashLength?: () => number;
    /**
     * Resolved per outgoing message (post-connect, after credentials load) so a
     * registered mobile session reconnecting without an explicit
     * `mobileTransport` option still emits the mobile message-id format.
     */
    readonly mobileMessageIdFormat?: () => boolean;
    readonly serverClock: ServerClock;
}
/** Membership split behind a group-history share, in the group's addressing mode. */
export interface WaGroupHistoryAudience {
    /** Members the bundle is addressed to. */
    readonly historyReceivers: readonly string[];
    /** Members in the group who are not receiving it. */
    readonly nonHistoryReceivers: readonly string[];
    /** Requested JIDs that are not current members of the group. */
    readonly unknownJids: readonly string[];
    /** Whether the caller asked to share with this account itself. */
    readonly requestedSelf: boolean;
    readonly addressingMode: 'pn' | 'lid';
}
/**
 * Narrows a group's participant list to the members a group-history bundle is
 * addressed to, plus the sender so its own devices keep a copy. Receivers are
 * intersected with the live participant list, so a stale receiver entry cannot
 * pull a non-member into the fanout. Any other message keeps the full list.
 *
 * Receivers must be written in the group's addressing mode - a PN entry for a
 * LID-addressed group does not match and is reported through `onDropped`.
 *
 * @throws when no receiver matches a current member. Sending to the sender's
 * own devices alone counts as no match: it would look like a delivered share
 * while nobody received anything.
 */
export declare function restrictGroupHistoryTargets(message: Proto.IMessage, participantUserJids: readonly string[], senderJid: string, onDropped?: (droppedJids: readonly string[], totalExpected: number) => void): readonly string[];
/**
 * Resolves the stanza `type` and `enc.mediatype` of an outbound message. A
 * `<biz>` companion rides a type=text stanza with no mediatype, except on a
 * group list: there the server nacks with 479 (SMAX_INVALID) unless
 * type=media, mediatype=list and `<biz><list>` travel together.
 */
export declare function resolveOutboundStanzaShape(attrs: Pick<WaOutboundMessageAttrs, 'buttonAddonKind' | 'typeAttr' | 'mediatype'>, isGroup: boolean): {
    readonly type: string;
    readonly mediatype: string | undefined;
};
export declare class WaMessageDispatchCoordinator {
    private readonly deps;
    private readonly mobileMessageIdFormat;
    private readonly serverClock;
    private readonly icdcDedup;
    private readonly privacyTokenDedup;
    private readonly distributionDedup;
    constructor(options: WaMessageDispatchCoordinatorOptions);
    /**
     * Per-chat disappearing settings from the cache, falling back to the
     * durable thread record on a cold miss and warming the cache with it. A
     * chat with no disappearing mode is cached as expiration `0` rather than
     * left absent, so the archive is not re-read on every send to it; the
     * incoming writers overwrite that entry the moment the chat turns it on.
     * A failing archive degrades the send to "no ephemeral fields" instead of
     * rejecting it - the store is opt-in persistence, not a send dependency.
     */
    private resolveChatMetadata;
    /**
     * Disappearing-message fields for a send into a chat with the mode on, or
     * `{}` when nothing resolves. Both chat kinds report initiator
     * `CHANGED_IN_CHAT` when nothing more specific is stored; the trigger comes
     * from the group metadata for a group and defaults to `CHAT_SETTING` for
     * 1:1, and is omitted when a group reports none.
     */
    private resolveChatEphemeral;
    publishMessageNode(node: BinaryNode, options?: WaMessagePublishOptions): Promise<WaMessagePublishResult>;
    publishEncryptedMessage(input: WaEncryptedMessageInput, options?: WaMessagePublishOptions): Promise<WaMessagePublishResult>;
    publishSignalMessage(input: WaSignalMessagePublishInput, options?: WaMessagePublishOptions): Promise<WaMessagePublishResult>;
    sendMessage(to: string, content: WaSendMessageContent, options?: WaSendMessageOptions): Promise<WaMessagePublishResult>;
    /**
     * For a 1:1 recipient passed in PN form, returns the LID-addressed user JID
     * (via {@link SignalDeviceSyncApi.resolveUserJidPair}). Switching to LID
     * before fanout ensures the envelope, eligible-requester list, and
     * retry-receipt addressing all agree, which keeps the retry tracker from
     * rejecting receipts that arrive in LID form. Returns the original PN if
     * no LID is known/resolvable. Inputs already in LID form pass through.
     */
    private resolveDirectRecipientLid;
    /**
     * Resolves the `peer_recipient_pn` cross-reference for a 1:1 send, or
     * `undefined` to drop the attribute. Only set when the envelope is
     * LID-addressed (`directRecipientJid` is a LID): the PN is the caller's own
     * JID when they passed a PN (zapo switched it to LID for sending), else the
     * device-list snapshot counterpart for a recipient passed in LID form.
     * Mirrors wa-web, which sets `peer_recipient_pn = getPhoneNumber($)` for a
     * LID destination.
     */
    private resolvePeerRecipientPn;
    syncSignalSession(jid: string, reasonIdentity?: boolean): Promise<void>;
    sendReceipt(input: WaSendReceiptInput): Promise<void>;
    publishProtocolMessageToDevice(deviceJid: string, protocolMessage: Proto.Message.IProtocolMessage, options?: {
        readonly id?: string;
        readonly pushPriority?: 'high' | 'high_force';
    }): Promise<WaMessagePublishResult>;
    publishStatusMessage(input: {
        readonly message: Proto.IMessage;
        readonly recipients: readonly string[];
        readonly statusSetting?: WaStatusDistributionSetting;
        readonly options?: WaSendMessageOptions;
    }): Promise<WaMessagePublishResult>;
    publishBroadcastListMessage(input: {
        readonly listJid: string;
        readonly message: Proto.IMessage;
        readonly recipients: readonly string[];
        readonly options?: WaSendMessageOptions;
    }): Promise<WaMessagePublishResult>;
    private publishSenderKeyFanout;
    requestAppStateSyncKeys(keyIds: readonly Uint8Array[]): Promise<readonly string[]>;
    sendAppStateSyncKeyShare(toDeviceJid: string, keys: readonly WaAppStateSyncKey[], missingKeyIds?: readonly Uint8Array[]): Promise<void>;
    mutateGroupMetadataCacheFromGroupEvent(event: WaGroupEvent): Promise<void>;
    /**
     * Splits a group's members into the ones a history bundle is being shared
     * with and the rest, normalizing everything to the group's addressing mode
     * so the receiver list written into the proto matches what the fanout can
     * actually resolve. This account is excluded from both lists.
     *
     * Requested JIDs that are not current members come back in `unknownJids`
     * instead of being silently dropped - sharing history with a non-member is
     * a caller mistake worth surfacing.
     */
    resolveGroupHistoryAudience(groupJid: string, requestedJids: readonly string[]): Promise<WaGroupHistoryAudience>;
    /**
     * A group-history bundle goes to the members named in `historyReceivers`
     * rather than to the whole group, so it takes the per-device direct fanout
     * instead of the group sender key.
     */
    private shouldUseGroupDirectPath;
    private publishGroupDirectMessage;
    private buildBotSidecarParticipant;
    private publishGroupSenderKeyMessage;
    private resolveGroupAddressingMode;
    /**
     * Parent-author JID stored with the outgoing message secret. Peers address
     * us by LID in `pollCreationMessageKey` during the PN→LID migration, so a
     * valid `meLid` wins. A malformed LID must not abort the send: fall back to
     * a normalized `meJid`, then to the empty sender (same recoverable path as
     * {@link resolveSenderForAddressingMode}).
     */
    private resolveOutgoingSecretSenderJid;
    private resolveSenderForAddressingMode;
    private encryptGroupDistributionParticipants;
    private publishDirectSignalMessageWithFanout;
    private withResolvedMessageId;
    generateOutgoingMessageId(): Promise<string>;
    private tryBuildReportingTokenArtifacts;
    private getEncodedSignedDeviceIdentity;
    resolveUserIcdc(userJid: string, localIdentity?: {
        readonly address: SignalAddress;
        readonly pubKey: Uint8Array;
    }): Promise<IcdcMeta | null>;
    private requireCurrentMeJid;
}
export {};
