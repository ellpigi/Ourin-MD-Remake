import { type WaNewsletterAdminOps } from '../newsletter/admin.js';
import { type WaNewsletterDiscoveryOps } from '../newsletter/discovery.js';
import { type WaNewsletterMessagingDeps, type WaNewsletterMessagingOps } from '../newsletter/messaging.js';
import { type WaNewsletterStatusOps } from '../newsletter/status.js';
import type { WaSendMessageContent } from '../../message/types.js';
export { parseNewsletterMetadata } from '../newsletter/parse.js';
export type { WaNewsletterAdminInfo, WaNewsletterAdminInviteInput, WaNewsletterAdminInviteResult, WaNewsletterAdminProfile, WaNewsletterCapabilityExposure, WaNewsletterCreateInput, WaNewsletterDehydratedMetadata, WaNewsletterDirectoryCategoriesPreviewOptions, WaNewsletterDirectoryCategoryPreview, WaNewsletterDirectoryListOptions, WaNewsletterDirectoryResults, WaNewsletterDirectorySearchOptions, WaNewsletterDirectoryView, WaNewsletterFetchOptions, WaNewsletterFollower, WaNewsletterFollowersOptions, WaNewsletterFollowersPage, WaNewsletterInsightMetricRequest, WaNewsletterMetadata, WaNewsletterMuteInput, WaNewsletterPicture, WaNewsletterPollVoter, WaNewsletterReactInput, WaNewsletterReactionSenders, WaNewsletterRecommendedOptions, WaNewsletterRevokeInput, WaNewsletterSendOptions, WaNewsletterSendResult, WaNewsletterSimilarOptions, WaNewsletterUpdateInput, WaNewsletterViewReceiptInput, WaNewsletterVotePollInput, WaPageInfo } from '../newsletter/types.js';
/**
 * Newsletter coordinator surface – combines the discovery, admin, and
 * messaging operation sets. Accessed via {@link WaClient.newsletter}.
 */
export type WaNewsletterCoordinator = WaNewsletterDiscoveryOps & WaNewsletterAdminOps & WaNewsletterMessagingOps & WaNewsletterStatusOps;
export type WaNewsletterCoordinatorOptions = WaNewsletterMessagingDeps & {
    /**
     * Builds and encodes a status payload. Required for `sendStatus`: a
     * status stanza carries raw protobuf bytes, not a message object, so
     * there is no sensible fallback without this.
     */
    readonly buildStatusContent: (content: WaSendMessageContent) => Promise<{
        readonly plaintext: Uint8Array;
        readonly mediaHandle?: string;
    }>;
    readonly waitForServerId?: (input: {
        jid: string;
        messageId: string;
        timeoutMs?: number;
    }) => Promise<number | undefined>;
};
/** Builds a {@link WaNewsletterCoordinator} from its MEX/messaging dependencies. */
export declare function createNewsletterCoordinator(options: WaNewsletterCoordinatorOptions): WaNewsletterCoordinator;
