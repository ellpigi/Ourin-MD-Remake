import type { Logger } from '../../infra/log/types.js';
import type { WaConnectionCode, WaConnectionOpenReason, WaDisconnectReason } from '../../protocol/stream.js';
import type { WaStreamControlNodeResult } from '../../transport/stream/parse.js';
import type { WaComms } from '../../transport/WaComms.js';
interface WaStreamControlCoordinatorOptions {
    readonly logger: Logger;
    readonly getComms: () => WaComms | null;
    readonly clearPendingQueries: (error: Error) => void;
    readonly clearMediaConnCache: () => void;
    readonly disconnect: (reason: WaDisconnectReason, isLogout: boolean, code: WaConnectionCode | null) => Promise<void>;
    readonly clearStoredCredentials: () => Promise<void>;
    readonly connect: (reason: WaConnectionOpenReason) => Promise<void>;
}
export interface WaStreamControlHandler {
    readonly handleStreamControlResult: (result: WaStreamControlNodeResult) => Promise<void>;
}
export declare function createStreamControlHandler(options: WaStreamControlCoordinatorOptions): WaStreamControlHandler;
export {};
