import { listStatuses, type WaStatusEntry, type WaStatusListOptions, type WaStatusMediaKind } from '../status-query.js';
import type { WaSendMessageOptions } from '../types.js';
import type { WaMessagePublishResult, WaSendMessageContent } from '../../message/types.js';
import type { WaMessageStore } from '../../store/contracts/message.store.js';
/** Emoji the WhatsApp client uses for a status "like". */
export declare const WA_STATUS_LIKE_EMOJI = "\u2764\uFE0F";
export interface WaStatusInteractions {
    /**
     * Reacts to a status by message id. Works on both contact statuses
     * (`status@broadcast`) and group statuses, as long as `chatJid` matches
     * where the status lives. Pass an empty `emoji` to remove the reaction.
     */
    readonly react: (input: WaStatusReactInput) => Promise<WaMessagePublishResult>;
    /** Reacts with {@link WA_STATUS_LIKE_EMOJI}. */
    readonly like: (input: WaStatusReactInput) => Promise<WaMessagePublishResult>;
    /**
     * Applies one action across every status a set of owners published. The
     * engine lists statuses from the store and reacts to each, so only
     * statuses this client observed are touched.
     */
    readonly apply: (input: WaStatusApplyInput) => Promise<WaStatusApplyResult>;
    /**
     * Downloads the media of every status in a chat (a contact's statuses, or
     * a group's). Text statuses carry no media and are skipped.
     */
    readonly download: (input: WaStatusDownloadInput) => Promise<readonly WaStatusDownloaded[]>;
    /**
     * Downloads every media status posted in a group. Text is skipped.
     * Convenience wrapper over {@link download} that fixes the chat to the
     * group, so the common case needs one argument.
     */
    readonly downloadGroup: (groupJid: string, options?: Omit<WaStatusDownloadInput, 'chatJid'>) => Promise<readonly WaStatusDownloaded[]>;
}
export interface WaStatusReactInput {
    /** Message id of the status. */
    readonly statusId: string;
    /** Author of the status; required for `status@broadcast`, omit for a group status. */
    readonly owner?: string;
    /** Chat the status lives in. Defaults to `status@broadcast`. */
    readonly chatJid?: string;
    readonly emoji: string;
    readonly options?: WaSendMessageOptions;
}
export interface WaStatusApplyInput {
    /** Owners to act on. Omit for every author seen. */
    readonly targets?: readonly string[];
    readonly action: 'react' | 'like';
    /** Emoji for the `react` action. Ignored by `like`. */
    readonly emoji?: string;
    readonly chats?: readonly string[];
    readonly list?: WaStatusListOptions;
    readonly options?: WaSendMessageOptions;
    /** Milliseconds to wait between reactions. Defaults to zero. */
    readonly intervalMs?: number;
}
export interface WaStatusApplyResult {
    readonly attempted: number;
    readonly reacted: number;
    readonly failed: readonly {
        readonly statusId: string;
        readonly message: string;
    }[];
}
export interface WaStatusDownloadInput {
    readonly owner?: string;
    readonly chatJid: string;
    readonly kinds?: readonly WaStatusMediaKind[];
    readonly limit?: number;
    /** Cap per file. Defaults to the transfer client's own cap. */
    readonly maxBytes?: number;
}
export interface WaStatusDownloaded {
    readonly entry: WaStatusEntry;
    readonly bytes: Uint8Array;
}
export interface WaStatusDependencies {
    readonly messageStore: WaMessageStore;
    readonly sendMessage: (to: string, content: WaSendMessageContent, options?: WaSendMessageOptions) => Promise<WaMessagePublishResult>;
    readonly downloadBytes: (source: {
        readonly message: WaStatusEntry['message'];
    }, options?: {
        readonly maxBytes?: number;
    }) => Promise<Uint8Array>;
    readonly list?: typeof listStatuses;
    readonly delay?: (ms: number) => Promise<void>;
}
/** Builds the status interaction surface used by {@link WaClient.status}. */
export declare function createStatusInteractions(deps: WaStatusDependencies): WaStatusInteractions;
