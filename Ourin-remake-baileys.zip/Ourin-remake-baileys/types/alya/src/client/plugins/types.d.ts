import type { WaLowLevelCoordinator } from '../coordinators/WaLowLevelCoordinator.js';
import type { WaClientOptions } from '../types.js';
import type { WaClient } from '../WaClient.js';
import type { WaClientDependencies } from '../WaClientFactory.js';
import type { Logger } from '../../infra/log/types.js';
import type { WaStore } from '../../store/types.js';
import type { BinaryNode } from '../../transport/types.js';
/**
 * Host context passed to every {@link WaClientPluginDefinition.setup}. Carries
 * the full {@link WaClientDependencies} graph plus event/handler helpers.
 *
 * @sensitive deps may reach key material through nested coordinators – do not
 * log or persist deps wholesale.
 */
export interface WaClientPluginContext {
    readonly client: WaClient;
    readonly options: Readonly<WaClientOptions>;
    readonly logger: Logger;
    readonly stores: ReturnType<WaStore['session']>;
    /**
     * Full coordinator dependency graph. Advanced API for plugin authors –
     * new coordinators may appear in minor releases.
     */
    readonly deps: WaClientDependencies;
    /** Loose so a plugin can emit its own events; consumers see them typed on the client. */
    readonly emit: (event: string | symbol, ...args: unknown[]) => boolean;
    readonly on: WaClient['on'];
    readonly off: WaClient['off'];
    readonly once: WaClient['once'];
    readonly queryWithContext: (context: string, node: BinaryNode, timeoutMs?: number, contextData?: Readonly<Record<string, unknown>>, options?: {
        readonly useSystemId?: boolean;
    }) => Promise<BinaryNode>;
    readonly registerIncomingHandler: WaLowLevelCoordinator['registerIncomingHandler'];
    readonly registerIncomingStanzaFilter: WaLowLevelCoordinator['registerIncomingStanzaFilter'];
    /** Runs on {@link WaClient.disconnect} after incoming handlers drain. */
    readonly registerDispose: (fn: () => void | Promise<void>) => void;
}
/**
 * Runtime plugin registration. Use {@link defineWaClientPlugin} for inference.
 * When `exposeAs` is set, `setup` should return the value exposed at
 * `client[exposeAs]`; otherwise only side effects (handlers, listeners) run.
 */
export interface WaClientPluginDefinition {
    readonly id: string;
    readonly exposeAs?: string;
    readonly setup: (ctx: WaClientPluginContext) => unknown;
    readonly dispose?: (instance: unknown, ctx: WaClientPluginContext) => void | Promise<void>;
}
export declare function isWaClientExposePluginDefinition(plugin: WaClientPluginDefinition): plugin is WaClientPluginDefinition & {
    readonly exposeAs: string;
};
type UnionToIntersection<U> = (U extends unknown ? (k: U) => void : never) extends (k: infer I) => void ? I : never;
/** `{ [exposeAs]: setup-return }` for one plugin definition; `{}` (no-op) for behavior plugins. */
type ExposedOf<P> = P extends {
    readonly exposeAs: infer K extends string;
    readonly setup: (...args: never[]) => infer T;
} ? {
    readonly [Q in K]: T;
} : {};
/**
 * Getters contributed by a tuple of plugin definitions, derived from the values
 * passed to the client (no global augmentation). `[voipPlugin()]` yields
 * `{ readonly voip: WaVoipCoordinator }`.
 */
export type WaClientExposedFromPlugins<P extends readonly unknown[]> = UnionToIntersection<ExposedOf<P[number]>>;
/**
 * Event map a plugin contributes, carried as a phantom marker on its definition.
 *
 * The marker is optional (it never exists at runtime), so under
 * `exactOptionalPropertyTypes` the inferred `E` keeps the `| undefined` the
 * declaration emits. `Exclude` drops it before the union reaches
 * {@link UnionToIntersection}, which would otherwise collapse
 * `Events | undefined` to `never` and type every client listener as `never`.
 */
type EventsOf<P> = P extends {
    readonly __pluginEvents?: infer E;
} ? unknown extends E ? {} : Exclude<E, undefined> : {};
/**
 * Client events contributed by a tuple of plugin definitions, derived from the
 * plugin values (no global augmentation). Threaded into the client's
 * `on`/`once`/`off`/`emit` so a `voip_*` event exists only when voip is installed.
 */
export type WaClientPluginEventsFromPlugins<P extends readonly unknown[]> = UnionToIntersection<EventsOf<P[number]>>;
export {};
