import { type WaClientPluginContext, type WaClientPluginDefinition } from './types.js';
import type { WaClientOptions } from '../types.js';
import type { WaClient } from '../WaClient.js';
import type { WaClientDependencies } from '../WaClientFactory.js';
import type { Logger } from '../../infra/log/types.js';
import type { WaStore } from '../../store/types.js';
export interface WaClientPluginInstallInput {
    readonly options: Readonly<WaClientOptions>;
    readonly logger: Logger;
    readonly stores: ReturnType<WaStore['session']>;
    readonly deps: WaClientDependencies;
    readonly queryWithContext: WaClientPluginContext['queryWithContext'];
}
/**
 * Installs {@link WaClientOptions.plugins} on `client`. Returns a dispose
 * function invoked by {@link WaClient.disconnect}. Safe to call again after a
 * dispose to reinstall the same plugins on reconnect.
 */
export declare function installWaClientPlugins(client: WaClient, input: WaClientPluginInstallInput, plugins: readonly WaClientPluginDefinition[]): () => Promise<void>;
