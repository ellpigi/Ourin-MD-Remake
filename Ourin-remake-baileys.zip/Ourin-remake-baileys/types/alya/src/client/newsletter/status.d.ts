import { type WaNewsletterStatus, type WaNewsletterStatusAck, type WaNewsletterStatusesPage } from '../events/newsletter-status.js';
import type { WaSendMessageContent } from '../../message/types.js';
import { type WaNewsletterStatusInteraction, type WaNewsletterStatusMediaType } from '../../transport/node/builders/newsletter-status.js';
import type { BinaryNode } from '../../transport/types.js';
/**
 * Newsletter channel status surface - the `<status>` stanza family, distinct
 * from an ordinary newsletter post (`<message>`).
 */
export interface WaNewsletterStatusOps {
    /**
     * Publishes a status to a newsletter channel. Text, image, video, gif and
     * audio are supported; a document or sticker status is rejected because
     * the channel surface does not accept one.
     *
     * A reaction or revoke on that status needs the server id, which only
     * arrives on the `<status>` echo after the publish ack. Pass
     * `resolveServerId` to wait for it and get it back in the result.
     */
    readonly sendStatus: (input: WaNewsletterSendStatusInput) => Promise<WaNewsletterSendStatusResult>;
    /** Reacts to one of the account's own channel statuses. */
    readonly reactToStatus: (input: WaNewsletterStatusReactInput) => Promise<BinaryNode>;
    /** Admin-revokes one of the account's own channel statuses. */
    readonly revokeStatus: (input: {
        readonly jid: string;
        readonly statusId: string;
    }) => Promise<BinaryNode>;
    /** Lists the channel's statuses. */
    readonly fetchStatuses: (input: {
        readonly jid: string;
        readonly count?: number;
        readonly since?: number;
        readonly before?: number | string;
        readonly after?: number | string;
    }) => Promise<WaNewsletterStatusesPage>;
}
export interface WaNewsletterSendStatusInput {
    readonly jid: string;
    readonly content: WaSendMessageContent;
    /** Present for a media status; must match what the upload produced. */
    readonly mediaType?: WaNewsletterStatusMediaType;
    /** Handle returned by the newsletter upload. */
    readonly mediaHandle?: string | number;
    readonly interactionType?: WaNewsletterStatusInteraction;
    readonly parentServerId?: number | string;
    readonly responseServerId?: number | string;
    readonly aiContent?: boolean;
    readonly messageId?: string;
    /** Waits for the `<status>` echo that carries `serverId`. */
    readonly resolveServerId?: boolean;
    readonly serverIdTimeoutMs?: number;
    /** Skips the newsletter-status context attribution. */
    readonly statusAttribution?: boolean;
}
export interface WaNewsletterSendStatusResult {
    readonly id: string;
    readonly serverId?: number;
    readonly ack: WaNewsletterStatusAck;
    readonly payload: Uint8Array;
}
export interface WaNewsletterStatusReactInput {
    readonly jid: string;
    readonly messageId: string;
    readonly parentServerId: number | string;
    /** Emoji code; omit to clear the reaction. */
    readonly reaction?: string;
}
export interface WaNewsletterStatusDeps {
    readonly sendNode: (node: BinaryNode) => Promise<void>;
    readonly query: (node: BinaryNode) => Promise<BinaryNode>;
    /**
     * Builds and encodes the status payload. Returns the encoded
     * `Proto.Message` bytes plus, for media, the handle the newsletter upload
     * produced. The status stanza addresses media by that handle, not by URL,
     * so a media status without it cannot be published.
     */
    readonly buildMessageContent: (content: WaSendMessageContent) => Promise<{
        readonly plaintext: Uint8Array;
        readonly mediaHandle?: string;
    }>;
    readonly generateStanzaId: () => Promise<string>;
    /** Resolves the server id from a `<status>` echo; omit to skip the wait. */
    readonly waitForServerId?: (input: {
        jid: string;
        messageId: string;
        timeoutMs?: number;
    }) => Promise<number | undefined>;
    /** Wait strategy; defaults to a plain timer. */
    readonly delay?: (ms: number) => Promise<void>;
}
/** Builds the newsletter status operations. */
export declare function createNewsletterStatusOps(deps: WaNewsletterStatusDeps): WaNewsletterStatusOps;
export type { WaNewsletterStatus };
