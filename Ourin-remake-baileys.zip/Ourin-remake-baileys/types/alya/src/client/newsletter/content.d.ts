import { type WaUploadMediaSource } from '../media.js';
import type { ResolvedLinkPreviewResult } from '../messaging/link-preview.js';
import type { Logger } from '../../infra/log/types.js';
import { type NewsletterMediaKind } from '../../media/constants.js';
import type { WaMediaTransferClient } from '../../media/transfer/WaMediaTransferClient.js';
import type { WaMediaConn } from '../../media/types.js';
import { type WaSendContextInfo } from '../../message/context-info.js';
import type { WaSendMessageContent, WaSendTextMessage } from '../../message/types.js';
export type WaNewsletterUploadMedia = WaUploadMediaSource;
export interface WaNewsletterUploadInput {
    readonly mediaKind: NewsletterMediaKind;
    readonly media: WaNewsletterUploadMedia;
    readonly mimetype: string;
    readonly mediaConn: WaMediaConn;
}
export interface WaNewsletterUploadResult {
    readonly url: string;
    readonly directPath: string;
    readonly handle?: string;
    readonly metadataUrl?: string;
    readonly thumbnailDirectPath?: string;
    readonly thumbnailSha256?: Uint8Array;
    readonly fileSha256: Uint8Array;
    readonly fileLength: number;
    readonly mediaId: string;
}
export declare function uploadNewsletterMedia(options: {
    readonly mediaTransfer: WaMediaTransferClient;
    readonly logger: Logger;
}, input: WaNewsletterUploadInput): Promise<WaNewsletterUploadResult>;
export type WaNewsletterContentKind = 'text' | 'media' | 'poll-creation';
export interface WaNewsletterBuiltContent {
    readonly kind: WaNewsletterContentKind;
    readonly plaintext: Uint8Array;
    readonly mediaType: string | null;
    readonly upload: WaNewsletterUploadResult | null;
}
export interface BuildNewsletterContentOptions {
    readonly logger: Logger;
    readonly mediaTransfer?: WaMediaTransferClient;
    readonly getMediaConn?: () => Promise<WaMediaConn>;
    /** Must be bound to the `newsletter` surface (unencrypted thumbnail upload). */
    readonly linkPreviewResolver?: (content: WaSendTextMessage) => Promise<ResolvedLinkPreviewResult | null>;
}
export declare function buildNewsletterMessageContent(options: BuildNewsletterContentOptions, content: WaSendMessageContent, ctx?: WaSendContextInfo | null): Promise<WaNewsletterBuiltContent>;
