import type { WaGroupMetadataStore } from '../contracts/group-metadata.store.js';
export declare function withGroupMetadataLock(store: WaGroupMetadataStore): WaGroupMetadataStore;
