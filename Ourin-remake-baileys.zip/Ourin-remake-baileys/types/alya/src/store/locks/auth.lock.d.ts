import type { WaAuthStore } from '../contracts/auth.store.js';
import type { WithDestroyLifecycle } from '../types.js';
export declare function withAuthLock(store: WaAuthStore): WithDestroyLifecycle<WaAuthStore>;
