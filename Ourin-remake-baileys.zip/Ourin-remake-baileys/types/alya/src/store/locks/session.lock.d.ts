import type { WaSessionStore } from '../contracts/session.store.js';
import type { WithDestroyLifecycle } from '../types.js';
export declare function withSessionLock(store: WaSessionStore): WithDestroyLifecycle<WaSessionStore>;
