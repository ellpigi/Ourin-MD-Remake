import type { WaSignalStore } from '../contracts/signal.store.js';
import type { WithDestroyLifecycle } from '../types.js';
export declare function withSignalLock(store: WaSignalStore): WithDestroyLifecycle<WaSignalStore>;
