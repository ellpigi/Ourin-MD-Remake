import type { WaMessageStore } from '../contracts/message.store.js';
import type { WithDestroyLifecycle } from '../types.js';
export declare function withMessageLock(store: WaMessageStore): WithDestroyLifecycle<WaMessageStore>;
