import type { WaPreKeyStore } from '../contracts/pre-key.store.js';
import type { WithDestroyLifecycle } from '../types.js';
export declare function withPreKeyLock(store: WaPreKeyStore): WithDestroyLifecycle<WaPreKeyStore>;
