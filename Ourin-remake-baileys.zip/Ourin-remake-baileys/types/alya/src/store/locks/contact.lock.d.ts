import type { WaContactStore } from '../contracts/contact.store.js';
import type { WithDestroyLifecycle } from '../types.js';
export declare function withContactLock(store: WaContactStore): WithDestroyLifecycle<WaContactStore>;
