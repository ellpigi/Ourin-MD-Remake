import type { WaIdentityStore } from '../contracts/identity.store.js';
import type { WithDestroyLifecycle } from '../types.js';
export declare function withIdentityLock(store: WaIdentityStore): WithDestroyLifecycle<WaIdentityStore>;
