import type { WaRetryStore } from '../contracts/retry.store.js';
export declare function withRetryLock(store: WaRetryStore): WaRetryStore;
