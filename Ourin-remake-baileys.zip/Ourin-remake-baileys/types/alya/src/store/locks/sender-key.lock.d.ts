import type { WaSenderKeyStore } from '../contracts/sender-key.store.js';
import type { WithDestroyLifecycle } from '../types.js';
export declare function withSenderKeyLock(store: WaSenderKeyStore): WithDestroyLifecycle<WaSenderKeyStore>;
