import type { WaAppStateStore } from '../contracts/appstate.store.js';
import type { WithDestroyLifecycle } from '../types.js';
export declare function withAppStateLock(store: WaAppStateStore): WithDestroyLifecycle<WaAppStateStore>;
