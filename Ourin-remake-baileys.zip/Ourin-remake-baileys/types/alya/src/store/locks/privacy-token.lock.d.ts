import type { WaPrivacyTokenStore } from '../contracts/privacy-token.store.js';
export declare function withPrivacyTokenLock(store: WaPrivacyTokenStore): WaPrivacyTokenStore;
