import type { WaDeviceListStore } from '../contracts/device-list.store.js';
export declare function withDeviceListLock(store: WaDeviceListStore): WaDeviceListStore;
