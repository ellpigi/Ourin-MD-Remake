import type { WaThreadStore } from '../contracts/thread.store.js';
import type { WithDestroyLifecycle } from '../types.js';
export declare function withThreadLock(store: WaThreadStore): WithDestroyLifecycle<WaThreadStore>;
