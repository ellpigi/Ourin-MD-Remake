import type { WaMessageSecretStore } from '../contracts/message-secret.store.js';
import type { WithDestroyLifecycle } from '../types.js';
export declare function withMessageSecretLock(store: WaMessageSecretStore): WithDestroyLifecycle<WaMessageSecretStore>;
