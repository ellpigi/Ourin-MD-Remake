import type { WaSenderKeyStore } from '../contracts/sender-key.store.js';
import type { WithDestroyLifecycle } from '../types.js';
import { type IdleExpiry } from '../../util/collections.js';
/**
 * Read-through / write-through in-process cache for a persistent sender-key
 * backend. Reuses {@link SenderKeyMemoryStore} as the bounded L1 so the
 * per-(group, sender) lookups repeated across a group fan-out skip the
 * backend round-trip.
 *
 * Only the point reads are cached. `getGroupSenderKeyList` returns the
 * *complete* set for a group, which a partial point cache would under-report,
 * so it goes straight to the backend. Upserts replace the whole record (no
 * merge), so they are write-through; the sweep deletes
 * (`deleteDeviceSenderKey`/`markForgetSenderKey`) run on the backend for the
 * authoritative count and then invalidate the matching L1 entries via the
 * memory store's own sweep. See {@link withSessionCache} for the shared
 * coherence model, the single-writer-per-session assumption and the eviction
 * with and without `expiry`.
 */
export declare function withSenderKeyCache(backend: WaSenderKeyStore, maxEntries?: number, expiry?: IdleExpiry): WithDestroyLifecycle<WaSenderKeyStore>;
