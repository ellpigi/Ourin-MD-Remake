import { proto } from '../../proto.js';
import type { WaLoginPayloadConfig, WaRegistrationPayloadConfig } from './types.js';
export declare function resolveDevicePropsPlatformType(deviceBrowser?: string): proto.DeviceProps.PlatformType;
export declare function buildLoginPayload(config: WaLoginPayloadConfig): Uint8Array;
export declare function buildRegistrationPayload(config: WaRegistrationPayloadConfig): Uint8Array;
