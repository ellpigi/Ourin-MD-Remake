import type { BinaryNode } from '../types.js';
export declare function formatBinaryNodeAsXml(node: BinaryNode): string;
