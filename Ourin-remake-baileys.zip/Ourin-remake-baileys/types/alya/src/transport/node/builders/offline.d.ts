import type { BinaryNode } from '../../types.js';
export declare function buildOfflineBatchNode(count: number): BinaryNode;
