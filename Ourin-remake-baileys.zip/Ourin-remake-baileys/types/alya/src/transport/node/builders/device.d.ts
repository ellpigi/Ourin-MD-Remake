import type { BinaryNode } from '../../types.js';
export declare function buildRemoveCompanionDeviceIq(deviceJid: string, reason: string): BinaryNode;
