import { type Proto } from '../../../proto.js';
import type { BinaryNode } from '../../types.js';
/** Interaction kinds a newsletter status can carry. */
export declare const WA_NEWSLETTER_STATUS_INTERACTIONS: Readonly<{
    readonly QUESTION: "question";
    readonly QUESTION_RESPONSE: "question_response";
    readonly QUESTION_RESHARE: "question_reshare";
}>;
export type WaNewsletterStatusInteraction = (typeof WA_NEWSLETTER_STATUS_INTERACTIONS)[keyof typeof WA_NEWSLETTER_STATUS_INTERACTIONS];
/** Media kinds a newsletter status can carry. */
export declare const WA_NEWSLETTER_STATUS_MEDIA_TYPES: Readonly<{
    readonly IMAGE: "image";
    readonly VIDEO: "video";
    readonly AUDIO: "audio";
    readonly GIF: "gif";
}>;
export type WaNewsletterStatusMediaType = (typeof WA_NEWSLETTER_STATUS_MEDIA_TYPES)[keyof typeof WA_NEWSLETTER_STATUS_MEDIA_TYPES];
/**
 * `edit` attribute values on a newsletter status stanza.
 *
 * `7` marks an edit that clears a reaction, `8` an admin revoke. Both are
 * literal values from the wire format, not ordinals we choose.
 */
export declare const WA_NEWSLETTER_STATUS_EDITS: Readonly<{
    readonly REACTION_REVOKE: "7";
    readonly ADMIN_REVOKE: "8";
}>;
/**
 * The server assigns ids in this range and rejects anything outside it, so a
 * status id has to be validated before it goes back on the wire.
 */
export declare const WA_NEWSLETTER_SERVER_ID_MIN = 99;
export declare const WA_NEWSLETTER_SERVER_ID_MAX = 2147476647;
/** Validates and normalizes a newsletter server id. */
export declare function toNewsletterServerId(value: number | string, label: string): string;
export interface WaNewsletterStatusMetaInput {
    readonly interactionType?: WaNewsletterStatusInteraction;
    readonly parentServerId?: number | string;
    readonly responseServerId?: number | string;
    readonly aiContent?: boolean;
}
/**
 * Adds the newsletter-status attribution to a message's context so a reply
 * carries the channel provenance.
 */
type NewsletterAttributedMessage = Proto.IMessage & {
    readonly contextInfo?: Proto.IContextInfo | null;
};
export declare function withNewsletterStatusAttribution(message: NewsletterAttributedMessage): NewsletterAttributedMessage;
export interface BuildNewsletterStatusInput extends WaNewsletterStatusMetaInput {
    readonly jid: string;
    readonly messageId: string;
    /** Encoded `Proto.Message` payload. */
    readonly plaintext: Uint8Array;
    readonly mediaType?: WaNewsletterStatusMediaType;
    /** Media handle returned by the newsletter upload, or its id. */
    readonly mediaHandle?: string | number;
}
/**
 * Builds the `<status>` stanza that publishes a newsletter status.
 */
export declare function buildNewsletterStatusNode(input: BuildNewsletterStatusInput): BinaryNode;
export interface BuildNewsletterStatusReactionInput {
    readonly jid: string;
    readonly messageId: string;
    readonly parentServerId: number | string;
    /** Emoji code, or empty to clear the reaction. */
    readonly reaction?: string;
}
export declare function buildNewsletterStatusReactionNode(input: BuildNewsletterStatusReactionInput): BinaryNode;
export declare function buildNewsletterStatusRevokeNode(input: {
    readonly jid: string;
    readonly statusId: string;
}): BinaryNode;
/** Wraps a newsletter admin profile status message for publication. */
export declare function buildNewsletterAdminProfileStatusMessage(message: Proto.IMessage): Proto.IMessage;
export interface BuildNewsletterStatusFetchInput {
    readonly jid: string;
    readonly count?: number;
    readonly since?: number;
    readonly before?: number | string;
    readonly after?: number | string;
}
/** `<status_updates>` paging query. */
export declare function buildNewsletterStatusUpdatesIq(input: BuildNewsletterStatusFetchInput): BinaryNode;
export {};
