import type { BinaryNode } from '../../types.js';
export type WaPassiveMode = 'active' | 'passive';
export declare function buildPassiveModeIqNode(mode: WaPassiveMode): BinaryNode;
