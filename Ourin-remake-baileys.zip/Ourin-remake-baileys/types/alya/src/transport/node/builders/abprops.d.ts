import type { BinaryNode } from '../../types.js';
export declare function buildGetAbPropsIq(options?: {
    readonly hash?: string | null;
    readonly refreshId?: number | null;
}): BinaryNode;
