import type { SignalMissingPreKeysTarget } from '../../../signal/api/SignalMissingPreKeysSyncApi.js';
import type { PreKeyRecord, RegistrationInfo, SignedPreKeyRecord } from '../../../signal/types.js';
import type { BinaryNode } from '../../types.js';
export declare function buildPreKeyUploadIq(registrationInfo: RegistrationInfo, signedPreKey: SignedPreKeyRecord, preKeys: readonly PreKeyRecord[]): BinaryNode;
export declare function buildSignedPreKeyRotateIq(signedPreKey: SignedPreKeyRecord): BinaryNode;
export declare function buildMissingPreKeysFetchIq(users: readonly SignalMissingPreKeysTarget[]): BinaryNode;
