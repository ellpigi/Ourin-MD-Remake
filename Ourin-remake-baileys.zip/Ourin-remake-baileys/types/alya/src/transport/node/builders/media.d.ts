import type { BinaryNode } from '../../types.js';
export declare function buildMediaConnIq(): BinaryNode;
