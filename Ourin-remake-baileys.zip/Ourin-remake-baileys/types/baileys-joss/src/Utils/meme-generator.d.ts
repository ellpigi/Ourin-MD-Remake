/**
 * Baileys-Joss: Meme Generator
 *
 * Generate meme sederhana dengan text overlay
 */
export interface MemeTemplate {
    id: string;
    name: string;
    description: string;
    textPositions: Array<{
        id: string;
        label: string;
        defaultText: string;
        position: 'top' | 'bottom' | 'center' | 'custom';
        customPosition?: {
            x: number;
            y: number;
        };
    }>;
    imageUrl?: string;
    width?: number;
    height?: number;
}
export interface MemeConfig {
    template: string | MemeTemplate;
    texts: Record<string, string>;
    fontSize?: number;
    fontColor?: string;
    strokeColor?: string;
    strokeWidth?: number;
}
export interface GeneratedMeme {
    templateId: string;
    texts: Record<string, string>;
    svgContent: string;
    htmlContent: string;
}
export declare const MEME_TEMPLATES: MemeTemplate[];
export declare class MemeGenerator {
    private templates;
    constructor();
    /**
     * Get all available templates
     */
    getTemplates(): MemeTemplate[];
    /**
     * Get template by ID
     */
    getTemplate(id: string): MemeTemplate | undefined;
    /**
     * Add custom template
     */
    addTemplate(template: MemeTemplate): void;
    /**
     * Generate meme as text (ASCII art style)
     */
    generateTextMeme(templateId: string, texts: Record<string, string>): string;
    /**
     * Generate meme as SVG
     */
    generateSvgMeme(config: MemeConfig): GeneratedMeme;
    /**
     * Generate meme description (for text-only display)
     */
    describeMeme(templateId: string, texts: Record<string, string>): string;
    /**
     * List templates as formatted message
     */
    listTemplates(): string;
    /**
     * Quick meme from popular formats
     */
    quickMeme(format: 'drake' | 'expanding' | 'buttons' | 'fine' | 'change', ...texts: string[]): string;
    /**
     * Wrap text to fit width
     */
    private wrapText;
    /**
     * Escape XML special characters
     */
    private escapeXml;
}
export declare const createMemeGenerator: () => MemeGenerator;
/**
 * Quick Drake meme
 */
export declare const drakeMeme: (bad: string, good: string) => string;
/**
 * Quick expanding brain meme
 */
export declare const expandingBrainMeme: (...levels: string[]) => string;
/**
 * Quick "this is fine" meme
 */
export declare const thisIsFineMeme: (text?: string) => string;
