/**
 * Baileys-Joss: Pomodoro Timer
 *
 * Timer produktivitas dengan teknik Pomodoro
 */
export interface PomodoroConfig {
    workDuration: number;
    shortBreakDuration: number;
    longBreakDuration: number;
    sessionsBeforeLongBreak: number;
    autoStartBreaks: boolean;
    autoStartWork: boolean;
}
export interface PomodoroSession {
    id: string;
    jid: string;
    status: 'idle' | 'work' | 'short_break' | 'long_break' | 'paused';
    currentSession: number;
    totalSessions: number;
    startTime?: number;
    pauseTime?: number;
    remainingTime?: number;
    config: PomodoroConfig;
}
export interface PomodoroStats {
    jid: string;
    totalWorkSessions: number;
    totalWorkMinutes: number;
    totalBreakMinutes: number;
    currentStreak: number;
    longestStreak: number;
    lastSessionDate?: string;
}
export type PomodoroEventType = 'work_start' | 'work_end' | 'break_start' | 'break_end' | 'session_complete' | 'paused' | 'resumed';
export interface PomodoroEvent {
    type: PomodoroEventType;
    session: PomodoroSession;
    timestamp: number;
}
export type PomodoroEventHandler = (event: PomodoroEvent) => void;
export declare const DEFAULT_POMODORO_CONFIG: PomodoroConfig;
export declare class PomodoroManager {
    private sessions;
    private stats;
    private timers;
    private eventHandlers;
    /**
     * Register event handler
     */
    onEvent(handler: PomodoroEventHandler): void;
    /**
     * Emit event to all handlers
     */
    private emit;
    /**
     * Create new pomodoro session
     */
    createSession(jid: string, config?: Partial<PomodoroConfig>): PomodoroSession;
    /**
     * Get session for user
     */
    getSession(jid: string): PomodoroSession | undefined;
    /**
     * Start work session
     */
    startWork(jid: string): PomodoroSession;
    /**
     * Start break (short or long)
     */
    startBreak(jid: string): PomodoroSession | null;
    /**
     * Pause current session
     */
    pause(jid: string): PomodoroSession | null;
    /**
     * Resume paused session
     */
    resume(jid: string): PomodoroSession | null;
    /**
     * Stop/reset session
     */
    stop(jid: string): void;
    /**
     * Get remaining time formatted
     */
    getRemainingTime(jid: string): string;
    /**
     * Get session status formatted
     */
    getStatusMessage(jid: string): string;
    /**
     * Get user stats
     */
    getStats(jid: string): PomodoroStats;
    /**
     * Get formatted stats
     */
    getStatsMessage(jid: string): string;
    /**
     * Start internal timer
     */
    private startTimer;
    /**
     * Clear timer
     */
    private clearTimer;
    /**
     * Handle timer completion
     */
    private onTimerComplete;
    /**
     * Format help message
     */
    getHelpMessage(): string;
    /**
     * Parse command
     */
    parseCommand(jid: string, command: string): string;
    /**
     * Handle set commands
     */
    private handleSet;
    /**
     * Cleanup all timers
     */
    cleanup(): void;
}
export declare const createPomodoroManager: () => PomodoroManager;
export declare const pomodoro: {
    start: (jid: string) => PomodoroSession;
    break: (jid: string) => PomodoroSession | null;
    pause: (jid: string) => PomodoroSession | null;
    resume: (jid: string) => PomodoroSession | null;
    stop: (jid: string) => void;
    status: (jid: string) => string;
    stats: (jid: string) => string;
    command: (jid: string, cmd: string) => string;
};
