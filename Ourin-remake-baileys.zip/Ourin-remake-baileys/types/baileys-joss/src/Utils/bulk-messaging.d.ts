/**
 * Baileys-Joss: Bulk Messaging System
 *
 * Fitur untuk mengirim pesan massal dengan rate limiting
 */
import type { AnyMessageContent, WAMessage } from '../Types';
export interface BulkMessageResult {
    jid: string;
    success: boolean;
    messageId?: string;
    error?: string;
    sentAt?: Date;
}
export interface BulkMessageProgress {
    total: number;
    sent: number;
    failed: number;
    remaining: number;
    currentJid?: string;
    percentage: number;
}
export interface BulkMessagingOptions {
    /** Delay between each message in milliseconds (default: 1000ms) */
    delayBetweenMessages?: number;
    /** Random delay variation in milliseconds (default: 500ms) */
    randomDelay?: number;
    /** Maximum retries per message (default: 2) */
    maxRetries?: number;
    /** Continue on error (default: true) */
    continueOnError?: boolean;
    /** Callback on progress update */
    onProgress?: (progress: BulkMessageProgress) => void;
    /** Callback on each message sent */
    onMessageSent?: (result: BulkMessageResult) => void;
    /** Callback on error */
    onError?: (jid: string, error: Error) => void;
    /** Callback when all messages are sent */
    onComplete?: (results: BulkMessageResult[]) => void;
}
type BulkSendMessageFunction = (jid: string, content: AnyMessageContent) => Promise<WAMessage | undefined>;
/**
 * Bulk Message Sender - Kirim pesan ke banyak kontak dengan rate limiting
 */
export declare class BulkMessageSender {
    private sendMessage;
    private options;
    private isRunning;
    private shouldStop;
    constructor(sendMessage: BulkSendMessageFunction, options?: BulkMessagingOptions);
    /**
     * Send same message to multiple recipients
     */
    sendToMany(jids: string[], content: AnyMessageContent): Promise<BulkMessageResult[]>;
    /**
     * Send different messages to different recipients
     */
    send(messages: Array<{
        jid: string;
        content: AnyMessageContent;
    }>): Promise<BulkMessageResult[]>;
    /**
     * Stop the current bulk messaging operation
     */
    stop(): void;
    /**
     * Check if bulk messaging is in progress
     */
    get running(): boolean;
}
/**
 * Create a bulk message sender instance
 */
export declare const createBulkSender: (sendMessage: BulkSendMessageFunction, options?: BulkMessagingOptions) => BulkMessageSender;
/**
 * Simple helper to send message to multiple JIDs
 */
export declare const sendBulkMessages: (sendMessage: BulkSendMessageFunction, jids: string[], content: AnyMessageContent, options?: BulkMessagingOptions) => Promise<BulkMessageResult[]>;
export {};
