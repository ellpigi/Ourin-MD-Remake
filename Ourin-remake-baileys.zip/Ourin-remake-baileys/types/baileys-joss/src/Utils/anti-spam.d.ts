/**
 * Baileys-Joss: Anti-Spam System
 *
 * Sistem untuk mendeteksi dan mencegah spam:
 * - Rate limiting
 * - Duplicate message detection
 * - Flood protection
 * - Pattern-based spam detection
 */
import type { WAMessage } from '../Types';
export interface SpamRule {
    id: string;
    name: string;
    type: 'rate_limit' | 'duplicate' | 'pattern' | 'flood' | 'custom';
    enabled: boolean;
    config: Record<string, unknown>;
    action: 'warn' | 'mute' | 'kick' | 'ban' | 'delete' | 'ignore';
    duration?: number;
}
export interface SpamDetectionResult {
    isSpam: boolean;
    rules: string[];
    score: number;
    action: SpamRule['action'];
    reason: string;
}
export interface UserActivity {
    jid: string;
    messageCount: number;
    lastMessageTime: number;
    recentMessages: string[];
    warnings: number;
    muted: boolean;
    mutedUntil?: number;
    banned: boolean;
}
export interface AntiSpamOptions {
    /** Maximum messages per minute per user */
    maxMessagesPerMinute?: number;
    /** Maximum duplicate messages allowed */
    maxDuplicates?: number;
    /** Time window for duplicate detection (ms) */
    duplicateWindow?: number;
    /** Maximum characters per message */
    maxMessageLength?: number;
    /** Minimum delay between messages (ms) */
    minMessageDelay?: number;
    /** Patterns to detect as spam */
    spamPatterns?: RegExp[];
    /** Whitelist JIDs (never spam) */
    whitelist?: string[];
    /** Callback when spam detected */
    onSpamDetected?: (jid: string, message: WAMessage, result: SpamDetectionResult) => void;
}
export declare class AntiSpamManager {
    private rules;
    private userActivity;
    private options;
    private messageHashes;
    constructor(options?: AntiSpamOptions);
    /**
     * Initialize default spam rules
     */
    private initDefaultRules;
    /**
     * Add a spam rule
     */
    addRule(rule: SpamRule): void;
    /**
     * Remove a spam rule
     */
    removeRule(ruleId: string): boolean;
    /**
     * Enable/disable a rule
     */
    toggleRule(ruleId: string, enabled: boolean): void;
    /**
     * Check if a message is spam
     */
    check(message: WAMessage): SpamDetectionResult;
    /**
     * Check individual rule
     */
    private checkRule;
    /**
     * Get action severity (higher = more severe)
     */
    private getActionSeverity;
    /**
     * Extract text from message
     */
    private extractText;
    /**
     * Create a simple hash of message
     */
    private hashMessage;
    /**
     * Mute a user
     */
    muteUser(jid: string, durationMs: number): void;
    /**
     * Unmute a user
     */
    unmuteUser(jid: string): void;
    /**
     * Ban a user
     */
    banUser(jid: string): void;
    /**
     * Unban a user
     */
    unbanUser(jid: string): void;
    /**
     * Add to whitelist
     */
    addToWhitelist(jid: string): void;
    /**
     * Remove from whitelist
     */
    removeFromWhitelist(jid: string): void;
    /**
     * Get user activity
     */
    getUserActivity(jid: string): UserActivity | undefined;
    /**
     * Reset user activity
     */
    resetUserActivity(jid: string): void;
    /**
     * Get spam statistics
     */
    getStats(): {
        totalUsers: number;
        mutedUsers: number;
        bannedUsers: number;
        totalWarnings: number;
    };
    /**
     * Clear all data
     */
    clear(): void;
}
export declare const createAntiSpam: (options?: AntiSpamOptions) => AntiSpamManager;
export declare const COMMON_SPAM_PATTERNS: RegExp[];
