/**
 * Baileys-Joss: QR Code Generator
 *
 * Generate QR code custom untuk pairing
 */
export interface QRCodeOptions {
    /** QR code size in pixels */
    size?: number;
    /** Error correction level */
    errorCorrectionLevel?: 'L' | 'M' | 'Q' | 'H';
    /** Foreground color (hex) */
    foregroundColor?: string;
    /** Background color (hex) */
    backgroundColor?: string;
    /** Margin (number of modules) */
    margin?: number;
    /** Output format */
    format?: 'svg' | 'terminal' | 'base64' | 'dataUrl';
    /** Logo URL or base64 (for center logo) */
    logo?: string;
    /** Logo size ratio (0.1 - 0.3 recommended) */
    logoSizeRatio?: number;
}
/**
 * Simple QR code generator (uses qrcode library if available)
 */
export declare class QRCodeGenerator {
    private options;
    constructor(options?: QRCodeOptions);
    /**
     * Generate QR code as terminal string (fallback without library)
     */
    generateTerminal(data: string): Promise<string>;
    /**
     * Generate QR code as SVG
     */
    generateSvg(data: string): Promise<string>;
    /**
     * Generate QR code as base64 PNG
     */
    generateBase64(data: string): Promise<string>;
    /**
     * Generate QR code as Buffer (PNG)
     */
    generateBuffer(data: string): Promise<Buffer>;
    /**
     * Generate QR code based on format option
     */
    generate(data: string): Promise<string | Buffer>;
    /**
     * Update options
     */
    setOptions(options: Partial<QRCodeOptions>): void;
}
/**
 * Create a styled QR code for WhatsApp pairing
 */
export declare const createWhatsAppQR: (pairingCode: string, options?: QRCodeOptions) => Promise<string>;
/**
 * Create QR code generator instance
 */
export declare const createQRGenerator: (options?: QRCodeOptions) => QRCodeGenerator;
/**
 * Quick QR code generation helpers
 */
export declare const QRHelper: {
    /**
     * Generate terminal QR
     */
    terminal: (data: string) => Promise<string>;
    /**
     * Generate SVG QR
     */
    svg: (data: string, options?: Partial<QRCodeOptions>) => Promise<string>;
    /**
     * Generate base64 QR
     */
    base64: (data: string, options?: Partial<QRCodeOptions>) => Promise<string>;
    /**
     * Generate buffer QR
     */
    buffer: (data: string, options?: Partial<QRCodeOptions>) => Promise<Buffer>;
};
/**
 * Custom QR code event handler for baileys
 */
export type QRCodeHandler = (qr: string, attempt: number) => void | Promise<void>;
/**
 * Create a QR code handler with custom rendering
 */
export declare const createQRHandler: (options?: QRCodeOptions & {
    onQR?: (rendered: string, raw: string, attempt: number) => void;
    maxAttempts?: number;
}) => QRCodeHandler;
