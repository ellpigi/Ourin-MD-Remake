/**
 * Baileys-Joss: Broadcast List Manager
 *
 * Fitur untuk mengelola dan mengirim ke broadcast list
 */
import type { AnyMessageContent, WAMessage } from '../Types';
export interface BroadcastList {
    id: string;
    name: string;
    description?: string;
    recipients: string[];
    createdAt: Date;
    updatedAt: Date;
    metadata?: Record<string, any>;
}
export interface BroadcastResult {
    listId: string;
    listName: string;
    totalRecipients: number;
    sent: number;
    failed: number;
    results: Array<{
        jid: string;
        success: boolean;
        messageId?: string;
        error?: string;
    }>;
    startedAt: Date;
    completedAt: Date;
}
export interface BroadcastOptions {
    /** Delay between messages in ms (default: 1000) */
    delay?: number;
    /** Random delay variation in ms (default: 500) */
    randomDelay?: number;
    /** Continue on error (default: true) */
    continueOnError?: boolean;
    /** Progress callback */
    onProgress?: (sent: number, total: number, currentJid: string) => void;
}
type BroadcastSendFunction = (jid: string, content: AnyMessageContent) => Promise<WAMessage | undefined>;
/**
 * Broadcast List Manager
 */
export declare class BroadcastManager {
    private lists;
    private sendMessage;
    constructor(sendMessage: BroadcastSendFunction);
    /**
     * Generate unique ID
     */
    private generateId;
    /**
     * Create a new broadcast list
     */
    create(options: {
        name: string;
        recipients: string[];
        description?: string;
        id?: string;
        metadata?: Record<string, any>;
    }): BroadcastList;
    /**
     * Get a broadcast list by ID
     */
    get(id: string): BroadcastList | undefined;
    /**
     * Get list by name
     */
    getByName(name: string): BroadcastList | undefined;
    /**
     * Get all broadcast lists
     */
    getAll(): BroadcastList[];
    /**
     * Update a broadcast list
     */
    update(id: string, updates: Partial<Omit<BroadcastList, 'id' | 'createdAt'>>): BroadcastList | undefined;
    /**
     * Add recipients to a list
     */
    addRecipients(id: string, jids: string[]): BroadcastList | undefined;
    /**
     * Remove recipients from a list
     */
    removeRecipients(id: string, jids: string[]): BroadcastList | undefined;
    /**
     * Delete a broadcast list
     */
    delete(id: string): boolean;
    /**
     * Send message to a broadcast list
     */
    broadcast(listId: string, content: AnyMessageContent, options?: BroadcastOptions): Promise<BroadcastResult>;
    /**
     * Send message to multiple lists
     */
    broadcastToLists(listIds: string[], content: AnyMessageContent, options?: BroadcastOptions): Promise<BroadcastResult[]>;
    /**
     * Export lists to JSON
     */
    export(): string;
    /**
     * Import lists from JSON
     */
    import(json: string, overwrite?: boolean): number;
    /**
     * Get statistics
     */
    getStats(): {
        totalLists: number;
        totalRecipients: number;
        averageRecipientsPerList: number;
    };
}
/**
 * Create a broadcast manager
 */
export declare const createBroadcastManager: (sendMessage: BroadcastSendFunction) => BroadcastManager;
export {};
