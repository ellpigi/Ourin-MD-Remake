/**
 * Sticker Maker Utilities untuk Baileys-Joss
 *
 * Fitur untuk membuat sticker dari image/video
 *
 * @module sticker-maker
 */
export interface StickerMetadata {
    /** Sticker pack name */
    packName?: string;
    /** Author/creator name */
    author?: string;
    /** Category (emoji) */
    categories?: string[];
    /** Sticker ID */
    id?: string;
    /** Quality (0-100) */
    quality?: number;
    /** Background for non-square images */
    background?: string;
    /** Tipe sticker */
    type?: 'default' | 'circle' | 'rounded';
}
export interface StickerOptions extends StickerMetadata {
    /** Crop to square */
    crop?: boolean;
    /** Target width (default 512) */
    width?: number;
    /** Target height (default 512) */
    height?: number;
}
/**
 * Build EXIF metadata untuk sticker
 * WhatsApp uses EXIF to store sticker pack info
 */
export declare const buildStickerExif: (metadata: StickerMetadata) => Buffer;
/**
 * Prepend EXIF ke WebP buffer
 */
export declare const addExifToWebp: (webpBuffer: Buffer, metadata: StickerMetadata) => Buffer;
/**
 * Generate sticker message content
 * Note: Actual image processing requires sharp/jimp
 * This provides the message structure
 */
export declare const generateStickerMessage: (stickerBuffer: Buffer, options?: StickerOptions) => {
    sticker: Buffer;
} & StickerOptions;
/**
 * Check apakah buffer adalah valid WebP
 */
export declare const isValidWebP: (buffer: Buffer) => boolean;
/**
 * Get WebP dimensions
 */
export declare const getWebPDimensions: (buffer: Buffer) => {
    width: number;
    height: number;
} | null;
/**
 * Check apakah WebP valid untuk sticker (512x512, < 500KB)
 */
export declare const isValidStickerWebP: (buffer: Buffer) => {
    valid: boolean;
    reason?: string;
};
/**
 * Check apakah WebP adalah animated
 */
export declare const isAnimatedWebP: (buffer: Buffer) => boolean;
/**
 * Instructions untuk convert image ke sticker
 * (Actual conversion requires sharp atau ffmpeg)
 */
export declare const getStickerConversionCommand: (inputPath: string, outputPath: string, options?: StickerOptions) => string;
/**
 * Get FFmpeg command untuk convert video ke animated sticker
 */
export declare const getAnimatedStickerCommand: (inputPath: string, outputPath: string, options?: {
    fps?: number;
    duration?: number;
}) => string;
declare const _default: {
    buildStickerExif: (metadata: StickerMetadata) => Buffer;
    addExifToWebp: (webpBuffer: Buffer, metadata: StickerMetadata) => Buffer;
    generateStickerMessage: (stickerBuffer: Buffer, options?: StickerOptions) => {
        sticker: Buffer;
    } & StickerOptions;
    isValidWebP: (buffer: Buffer) => boolean;
    getWebPDimensions: (buffer: Buffer) => {
        width: number;
        height: number;
    } | null;
    isValidStickerWebP: (buffer: Buffer) => {
        valid: boolean;
        reason?: string;
    };
    isAnimatedWebP: (buffer: Buffer) => boolean;
    getStickerConversionCommand: (inputPath: string, outputPath: string, options?: StickerOptions) => string;
    getAnimatedStickerCommand: (inputPath: string, outputPath: string, options?: {
        fps?: number;
        duration?: number;
    }) => string;
};
export default _default;
