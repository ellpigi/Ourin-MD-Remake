/**
 * Baileys-Joss: Status/Story Posting
 *
 * Fitur untuk posting status WhatsApp
 */
import type { AnyMessageContent } from '../Types';
export type StatusType = 'text' | 'image' | 'video' | 'audio';
export interface TextStatusOptions {
    /** Status text content */
    text: string;
    /** Background color (hex) */
    backgroundColor?: string;
    /** Font type (0-9) */
    font?: number;
    /** Text color (hex) */
    textColor?: string;
}
export interface MediaStatusOptions {
    /** Media buffer or URL */
    media: Buffer | string;
    /** Caption */
    caption?: string;
    /** View once */
    viewOnce?: boolean;
}
export interface StatusPostResult {
    messageId: string;
    timestamp: Date;
    type: StatusType;
}
/**
 * Pre-defined background colors for text status
 */
export declare const STATUS_BACKGROUNDS: {
    solid: {
        green: string;
        blue: string;
        purple: string;
        red: string;
        orange: string;
        yellow: string;
        pink: string;
        teal: string;
        gray: string;
        black: string;
        white: string;
    };
    gradient: {
        sunset: string[];
        ocean: string[];
        forest: string[];
        purple: string[];
        midnight: string[];
        aurora: string[];
    };
};
/**
 * Font types for text status (0-9)
 */
export declare const STATUS_FONTS: {
    SANS_SERIF: number;
    SERIF: number;
    NORICAN: number;
    BRYNDAN: number;
    BEBASNEUE: number;
    OSWALD: number;
    DAMION: number;
    DANCING: number;
    COMFORTAA: number;
    EXOTWO: number;
};
/**
 * Generate random message ID for status
 */
export declare const generateStatusMessageId: () => string;
/**
 * Create text status content
 */
export declare const createTextStatus: (options: TextStatusOptions) => AnyMessageContent;
/**
 * Create image status content
 */
export declare const createImageStatus: (media: Buffer | string, options?: {
    caption?: string;
    viewOnce?: boolean;
}) => AnyMessageContent;
/**
 * Create video status content
 */
export declare const createVideoStatus: (media: Buffer | string, options?: {
    caption?: string;
    viewOnce?: boolean;
    gifPlayback?: boolean;
}) => AnyMessageContent;
/**
 * Create audio status content
 */
export declare const createAudioStatus: (media: Buffer | string, options?: {
    ptt?: boolean;
}) => AnyMessageContent;
/**
 * Status JID constant
 */
export declare const STATUS_BROADCAST_JID = "status@broadcast";
/**
 * Create status privacy options
 */
export interface StatusPrivacyOptions {
    /** 'contacts' | 'blacklist' | 'whitelist' */
    type: 'contacts' | 'blacklist' | 'whitelist';
    /** List of JIDs for blacklist/whitelist */
    list?: string[];
}
/**
 * Helper to get status broadcast JID
 */
export declare const getStatusJid: () => string;
/**
 * Quick status helpers
 */
export declare const StatusHelper: {
    /**
     * Create a simple text status
     */
    text: (text: string, backgroundColor?: string) => AnyMessageContent;
    /**
     * Create an image status from buffer
     */
    image: (buffer: Buffer, caption?: string) => AnyMessageContent;
    /**
     * Create an image status from URL
     */
    imageUrl: (url: string, caption?: string) => AnyMessageContent;
    /**
     * Create a video status from buffer
     */
    video: (buffer: Buffer, caption?: string) => AnyMessageContent;
    /**
     * Create a video status from URL
     */
    videoUrl: (url: string, caption?: string) => AnyMessageContent;
    /**
     * Create a GIF status
     */
    gif: (buffer: Buffer, caption?: string) => AnyMessageContent;
    /**
     * Create a voice note status
     */
    voiceNote: (buffer: Buffer) => AnyMessageContent;
};
