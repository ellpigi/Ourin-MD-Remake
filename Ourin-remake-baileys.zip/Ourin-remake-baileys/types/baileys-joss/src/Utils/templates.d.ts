/**
 * Baileys-Joss: Message Templates System
 *
 * Template pesan siap pakai untuk berbagai keperluan
 */
export interface TemplateVariable {
    name: string;
    defaultValue?: string;
    required?: boolean;
}
export interface MessageTemplate {
    id: string;
    name: string;
    description?: string;
    content: string;
    variables: TemplateVariable[];
    category?: string;
    createdAt: Date;
    updatedAt: Date;
}
export interface TemplateData {
    [key: string]: string | number | undefined;
}
/**
 * Message Template Manager
 */
export declare class TemplateManager {
    private templates;
    /**
     * Generate unique ID
     */
    private generateId;
    /**
     * Extract variables from template string
     * Variables are in format: {{variableName}}
     */
    private extractVariables;
    /**
     * Create a new template
     */
    create(options: {
        name: string;
        content: string;
        description?: string;
        category?: string;
        id?: string;
    }): MessageTemplate;
    /**
     * Get a template by ID
     */
    get(id: string): MessageTemplate | undefined;
    /**
     * Get template by name
     */
    getByName(name: string): MessageTemplate | undefined;
    /**
     * Get all templates
     */
    getAll(): MessageTemplate[];
    /**
     * Get templates by category
     */
    getByCategory(category: string): MessageTemplate[];
    /**
     * Update a template
     */
    update(id: string, updates: Partial<Omit<MessageTemplate, 'id' | 'createdAt'>>): MessageTemplate | undefined;
    /**
     * Delete a template
     */
    delete(id: string): boolean;
    /**
     * Render template with data
     */
    render(id: string, data?: TemplateData): string;
    /**
     * Render template content with data
     */
    renderContent(content: string, data?: TemplateData): string;
    /**
     * Validate data against template
     */
    validate(id: string, data: TemplateData): {
        valid: boolean;
        missing: string[];
    };
    /**
     * Export templates to JSON
     */
    export(): string;
    /**
     * Import templates from JSON
     */
    import(json: string, overwrite?: boolean): number;
}
/**
 * Pre-built templates
 */
export declare const PRESET_TEMPLATES: {
    ORDER_CONFIRMATION: {
        name: string;
        category: string;
        content: string;
    };
    ORDER_SHIPPED: {
        name: string;
        category: string;
        content: string;
    };
    INVOICE: {
        name: string;
        category: string;
        content: string;
    };
    WELCOME: {
        name: string;
        category: string;
        content: string;
    };
    BIRTHDAY: {
        name: string;
        category: string;
        content: string;
    };
    REMINDER: {
        name: string;
        category: string;
        content: string;
    };
    APPOINTMENT: {
        name: string;
        category: string;
        content: string;
    };
    SUPPORT_TICKET: {
        name: string;
        category: string;
        content: string;
    };
    SUPPORT_RESOLVED: {
        name: string;
        category: string;
        content: string;
    };
};
/**
 * Create a template manager with preset templates
 */
export declare const createTemplateManager: (includePresets?: boolean) => TemplateManager;
/**
 * Quick template rendering without manager
 */
export declare const renderTemplate: (content: string, data?: TemplateData) => string;
