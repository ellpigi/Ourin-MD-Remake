/**
 * Baileys-Joss: Weather Bot
 *
 * Informasi cuaca dengan integrasi OpenWeatherMap API
 */
export interface WeatherConfig {
    apiKey?: string;
    units: 'metric' | 'imperial';
    language: string;
    defaultCity?: string;
}
export interface WeatherData {
    city: string;
    country: string;
    temperature: number;
    feelsLike: number;
    humidity: number;
    pressure: number;
    windSpeed: number;
    windDirection: number;
    description: string;
    icon: string;
    visibility: number;
    clouds: number;
    sunrise: number;
    sunset: number;
    timestamp: number;
}
export interface ForecastData {
    city: string;
    country: string;
    forecasts: Array<{
        date: string;
        time: string;
        temperature: number;
        feelsLike: number;
        humidity: number;
        description: string;
        icon: string;
        windSpeed: number;
        pop: number;
    }>;
}
export interface WeatherAlert {
    event: string;
    description: string;
    start: number;
    end: number;
    severity: 'minor' | 'moderate' | 'severe' | 'extreme';
}
export declare class WeatherBot {
    private config;
    private cache;
    private cacheTimeout;
    constructor(config?: Partial<WeatherConfig>);
    /**
     * Set API key
     */
    setApiKey(apiKey: string): void;
    /**
     * Get weather for city
     */
    getWeather(city: string): Promise<WeatherData>;
    /**
     * Fetch weather from OpenWeatherMap API
     */
    private fetchWeatherFromAPI;
    /**
     * Get mock weather data
     */
    private getMockWeather;
    /**
     * Format weather data for display
     */
    formatWeather(data: WeatherData, style?: 'simple' | 'detailed' | 'compact'): string;
    /**
     * Get weather advice based on conditions
     */
    getAdvice(data: WeatherData): string;
    /**
     * Parse command and return weather
     */
    parseCommand(command: string): Promise<string>;
    /**
     * Get help message
     */
    getHelpMessage(): string;
    /**
     * Get wind direction from degrees
     */
    private getWindDirection;
    /**
     * Capitalize first letter
     */
    private capitalizeFirst;
    /**
     * Capitalize each word
     */
    private capitalizeWords;
    /**
     * Clear cache
     */
    clearCache(): void;
}
export declare const createWeatherBot: (config?: Partial<WeatherConfig>) => WeatherBot;
/**
 * Get weather for city
 */
export declare const getWeather: (city: string) => Promise<string>;
/**
 * Get simple weather
 */
export declare const getSimpleWeather: (city: string) => Promise<string>;
/**
 * Parse weather command
 */
export declare const weatherCommand: (cmd: string) => Promise<string>;
