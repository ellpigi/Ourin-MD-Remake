/**
 * Baileys-Joss: Quote Generator
 *
 * Random quotes, motivational quotes, dan quotes harian
 */
export interface Quote {
    id: string;
    text: string;
    author: string;
    category: QuoteCategory;
    language: 'en' | 'id' | string;
    tags?: string[];
}
export type QuoteCategory = 'motivational' | 'inspirational' | 'love' | 'life' | 'success' | 'friendship' | 'wisdom' | 'funny' | 'islamic' | 'philosophy';
export interface QuoteOfTheDay {
    quote: Quote;
    date: string;
}
export declare const QUOTES: Quote[];
export declare class QuoteManager {
    private quotes;
    private quotesOfTheDay;
    private customQuotes;
    constructor();
    /**
     * Get random quote
     */
    getRandomQuote(options?: {
        category?: QuoteCategory;
        language?: string;
        tag?: string;
    }): Quote;
    /**
     * Get quote of the day (same quote for entire day)
     */
    getQuoteOfTheDay(category?: QuoteCategory): QuoteOfTheDay;
    /**
     * Add custom quote
     */
    addQuote(quote: Omit<Quote, 'id'>): Quote;
    /**
     * Get all quotes by category
     */
    getByCategory(category: QuoteCategory): Quote[];
    /**
     * Get all quotes by author
     */
    getByAuthor(author: string): Quote[];
    /**
     * Search quotes by text
     */
    search(query: string): Quote[];
    /**
     * Format quote for display
     */
    formatQuote(quote: Quote, style?: 'simple' | 'fancy' | 'minimal'): string;
    /**
     * Get available categories
     */
    getCategories(): QuoteCategory[];
    /**
     * Get quote count
     */
    getQuoteCount(): {
        total: number;
        byCategory: Record<string, number>;
    };
    /**
     * Get help message
     */
    getHelpMessage(): string;
    /**
     * Parse command and return formatted quote
     */
    parseCommand(command: string): string;
    /**
     * Get category emoji
     */
    private getCategoryEmoji;
    /**
     * Capitalize first letter
     */
    private capitalizeFirst;
}
export declare const createQuoteManager: () => QuoteManager;
/**
 * Get random quote
 */
export declare const getRandomQuote: (category?: QuoteCategory) => string;
/**
 * Get quote of the day
 */
export declare const getQuoteOfTheDay: () => string;
/**
 * Get motivational quote
 */
export declare const getMotivationalQuote: () => string;
/**
 * Get Islamic quote
 */
export declare const getIslamicQuote: () => string;
/**
 * Get funny quote
 */
export declare const getFunnyQuote: () => string;
/**
 * Parse quote command
 */
export declare const quoteCommand: (cmd: string) => string;
