/**
 * Group Utilities untuk Baileys-Joss
 *
 * Fitur tambahan untuk group management
 *
 * @module group-utils
 */
import type { GroupMetadata } from '../Types';
export interface GroupInfo {
    /** Group JID */
    jid: string;
    /** Nama group */
    name: string;
    /** Subject (sama dengan name) */
    subject: string;
    /** Description */
    description?: string;
    /** Owner JID */
    owner?: string;
    /** Creation timestamp */
    createdAt?: number;
    /** Jumlah participants */
    participantCount: number;
    /** Is announcement (only admin can send) */
    isAnnouncement: boolean;
    /** Is restricted (only admin can edit info) */
    isRestricted: boolean;
    /** Is community */
    isCommunity: boolean;
    /** Is community announcement */
    isCommunityAnnouncement: boolean;
    /** Ephemeral duration */
    ephemeralDuration?: number;
    /** Invite link */
    inviteCode?: string;
}
export interface ParticipantInfo {
    /** JID */
    jid: string;
    /** Is admin */
    isAdmin: boolean;
    /** Is super admin (owner) */
    isSuperAdmin: boolean;
    /** LID if available */
    lid?: string;
}
export interface GroupStats {
    /** Total members */
    totalMembers: number;
    /** Total admins */
    totalAdmins: number;
    /** Total super admins */
    totalSuperAdmins: number;
    /** Admin percentage */
    adminPercentage: number;
}
/**
 * Get participant info dari GroupMetadata
 */
export declare const getParticipants: (metadata: GroupMetadata) => ParticipantInfo[];
/**
 * Get only admins
 */
export declare const getAdmins: (metadata: GroupMetadata) => ParticipantInfo[];
/**
 * Get only super admins (owners)
 */
export declare const getSuperAdmins: (metadata: GroupMetadata) => ParticipantInfo[];
/**
 * Get regular members (non-admin)
 */
export declare const getRegularMembers: (metadata: GroupMetadata) => ParticipantInfo[];
/**
 * Check apakah user adalah admin di group
 */
export declare const isGroupAdmin: (metadata: GroupMetadata, jid: string) => boolean;
/**
 * Check apakah user adalah super admin (owner) di group
 */
export declare const isGroupSuperAdmin: (metadata: GroupMetadata, jid: string) => boolean;
/**
 * Check apakah user ada di group
 */
export declare const isGroupMember: (metadata: GroupMetadata, jid: string) => boolean;
/**
 * Get formatted group info
 */
export declare const getGroupInfo: (metadata: GroupMetadata) => GroupInfo;
/**
 * Get group stats
 */
export declare const getGroupStats: (metadata: GroupMetadata) => GroupStats;
/**
 * Check if group is announcement only
 */
export declare const isAnnouncementGroup: (metadata: GroupMetadata) => boolean;
/**
 * Check if group is restricted (only admin can edit info)
 */
export declare const isRestrictedGroup: (metadata: GroupMetadata) => boolean;
/**
 * Generate mention text untuk semua member
 */
export declare const mentionAll: (metadata: GroupMetadata) => {
    text: string;
    mentions: string[];
};
/**
 * Generate mention text untuk admins saja
 */
export declare const mentionAdmins: (metadata: GroupMetadata) => {
    text: string;
    mentions: string[];
};
/**
 * Generate formatted participant list
 */
export declare const formatParticipantList: (metadata: GroupMetadata, options?: {
    showAdmin?: boolean;
    showNumber?: boolean;
    prefix?: string;
}) => string;
/**
 * Split participants into chunks untuk batch operations
 * (WhatsApp has limit on participants per action)
 */
export declare const chunkParticipants: (participants: string[], chunkSize?: number) => string[][];
/**
 * Generate batch add/remove/promote/demote operations
 */
export declare const batchParticipantAction: <T>(participants: string[], action: (jids: string[]) => Promise<T>, options?: {
    chunkSize?: number;
    delayMs?: number;
}) => Promise<{
    success: string[];
    failed: string[];
    results: T[];
}>;
/**
 * Validate group JID
 */
export declare const isValidGroupJid: (jid: string) => boolean;
/**
 * Validate community JID
 */
export declare const isValidCommunityJid: (jid: string) => boolean;
/**
 * Extract group ID dari JID
 */
export declare const extractGroupId: (jid: string) => string | null;
declare const _default: {
    getParticipants: (metadata: GroupMetadata) => ParticipantInfo[];
    getAdmins: (metadata: GroupMetadata) => ParticipantInfo[];
    getSuperAdmins: (metadata: GroupMetadata) => ParticipantInfo[];
    getRegularMembers: (metadata: GroupMetadata) => ParticipantInfo[];
    isGroupAdmin: (metadata: GroupMetadata, jid: string) => boolean;
    isGroupSuperAdmin: (metadata: GroupMetadata, jid: string) => boolean;
    isGroupMember: (metadata: GroupMetadata, jid: string) => boolean;
    getGroupInfo: (metadata: GroupMetadata) => GroupInfo;
    getGroupStats: (metadata: GroupMetadata) => GroupStats;
    isAnnouncementGroup: (metadata: GroupMetadata) => boolean;
    isRestrictedGroup: (metadata: GroupMetadata) => boolean;
    mentionAll: (metadata: GroupMetadata) => {
        text: string;
        mentions: string[];
    };
    mentionAdmins: (metadata: GroupMetadata) => {
        text: string;
        mentions: string[];
    };
    formatParticipantList: (metadata: GroupMetadata, options?: {
        showAdmin?: boolean;
        showNumber?: boolean;
        prefix?: string;
    }) => string;
    chunkParticipants: (participants: string[], chunkSize?: number) => string[][];
    batchParticipantAction: <T>(participants: string[], action: (jids: string[]) => Promise<T>, options?: {
        chunkSize?: number;
        delayMs?: number;
    }) => Promise<{
        success: string[];
        failed: string[];
        results: T[];
    }>;
    isValidGroupJid: (jid: string) => boolean;
    isValidCommunityJid: (jid: string) => boolean;
    extractGroupId: (jid: string) => string | null;
};
export default _default;
