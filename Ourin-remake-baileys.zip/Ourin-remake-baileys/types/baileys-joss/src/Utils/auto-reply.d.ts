/**
 * Baileys-Joss: Auto Reply System
 *
 * Sistem balasan otomatis berdasarkan keyword/pattern
 */
import type { AnyMessageContent, WAMessage } from '../Types';
export interface AutoReplyRule {
    id: string;
    /** Keywords to match (case-insensitive) */
    keywords?: string[];
    /** Regex pattern to match */
    pattern?: RegExp;
    /** Exact match (case-insensitive) */
    exactMatch?: string;
    /** Response content */
    response: AnyMessageContent | ((message: WAMessage, match: RegExpMatchArray | null) => AnyMessageContent | Promise<AnyMessageContent>);
    /** Only reply in specific chats */
    allowedJids?: string[];
    /** Ignore these JIDs */
    blockedJids?: string[];
    /** Only reply to groups */
    groupsOnly?: boolean;
    /** Only reply to private chats */
    privateOnly?: boolean;
    /** Cooldown in milliseconds per JID */
    cooldown?: number;
    /** Reply with quote */
    quoted?: boolean;
    /** Active status */
    active?: boolean;
    /** Priority (higher = checked first) */
    priority?: number;
}
export interface AutoReplyOptions {
    /** Global cooldown in milliseconds (default: 1000ms) */
    globalCooldown?: number;
    /** Enable typing indicator before reply */
    simulateTyping?: boolean;
    /** Typing duration in milliseconds (default: 1000ms) */
    typingDuration?: number;
    /** Process multiple matches (default: false) */
    multiMatch?: boolean;
    /** Callback when auto-reply is triggered */
    onReply?: (rule: AutoReplyRule, message: WAMessage, response: AnyMessageContent) => void;
    /** Callback on error */
    onError?: (error: Error, rule: AutoReplyRule, message: WAMessage) => void;
}
type AutoReplySendFunction = (jid: string, content: AnyMessageContent, options?: {
    quoted?: WAMessage;
}) => Promise<WAMessage | undefined>;
export type PresenceFunction = (jid: string, presence: 'composing' | 'paused') => Promise<void>;
/**
 * Auto Reply Handler - Sistem balasan otomatis
 */
export declare class AutoReplyHandler {
    private rules;
    private cooldowns;
    private globalCooldown;
    private sendMessage;
    private sendPresence?;
    private options;
    constructor(sendMessage: AutoReplySendFunction, sendPresence?: PresenceFunction, options?: AutoReplyOptions);
    /**
     * Generate unique ID for rule
     */
    private generateId;
    /**
     * Add a new auto-reply rule
     */
    addRule(rule: Omit<AutoReplyRule, 'id'> & {
        id?: string;
    }): AutoReplyRule;
    /**
     * Remove a rule by ID
     */
    removeRule(id: string): boolean;
    /**
     * Get all rules
     */
    getRules(): AutoReplyRule[];
    /**
     * Get a rule by ID
     */
    getRule(id: string): AutoReplyRule | undefined;
    /**
     * Enable/disable a rule
     */
    setRuleActive(id: string, active: boolean): boolean;
    /**
     * Clear all rules
     */
    clearRules(): void;
    /**
     * Check cooldown for a specific rule and JID
     */
    private checkCooldown;
    /**
     * Check global cooldown for JID
     */
    private checkGlobalCooldown;
    /**
     * Set cooldown
     */
    private setCooldown;
    /**
     * Check if message matches a rule
     */
    private matchRule;
    /**
     * Check if JID is allowed for this rule
     */
    private isJidAllowed;
    /**
     * Process incoming message and send auto-reply if matched
     */
    processMessage(message: WAMessage): Promise<boolean>;
}
/**
 * Create an auto-reply handler instance
 */
export declare const createAutoReply: (sendMessage: AutoReplySendFunction, sendPresence?: PresenceFunction, options?: AutoReplyOptions) => AutoReplyHandler;
export {};
