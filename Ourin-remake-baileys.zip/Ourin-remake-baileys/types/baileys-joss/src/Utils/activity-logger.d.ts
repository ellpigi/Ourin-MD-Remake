/**
 * Baileys-Joss: Activity Logger
 *
 * Logging aktivitas untuk audit trail:
 * - Message logs
 * - User activity
 * - Group changes
 * - Bot actions
 */
import type { WAMessage } from '../Types';
export type LogLevel = 'debug' | 'info' | 'warn' | 'error' | 'critical';
export type LogCategory = 'message' | 'user' | 'group' | 'bot' | 'system' | 'security' | 'error';
export interface LogEntry {
    id: string;
    timestamp: Date;
    level: LogLevel;
    category: LogCategory;
    action: string;
    actor: string;
    target?: string;
    details: Record<string, unknown>;
    metadata?: Record<string, unknown>;
}
export interface ActivityLoggerOptions {
    /** Enable file logging */
    fileLogging?: boolean;
    /** Log file path */
    logFilePath?: string;
    /** Maximum entries in memory */
    maxMemoryEntries?: number;
    /** Log rotation size (bytes) */
    maxFileSize?: number;
    /** Minimum log level to record */
    minLevel?: LogLevel;
    /** Categories to log */
    categories?: LogCategory[];
    /** Custom log formatter */
    formatter?: (entry: LogEntry) => string;
    /** Callback on new log entry */
    onLog?: (entry: LogEntry) => void;
}
export interface LogQuery {
    level?: LogLevel | LogLevel[];
    category?: LogCategory | LogCategory[];
    actor?: string;
    target?: string;
    action?: string;
    fromDate?: Date;
    toDate?: Date;
    limit?: number;
    offset?: number;
}
export interface LogStats {
    totalEntries: number;
    byLevel: Record<LogLevel, number>;
    byCategory: Record<LogCategory, number>;
    recentActivity: LogEntry[];
    topActors: Array<{
        actor: string;
        count: number;
    }>;
}
export declare class ActivityLogger {
    private logs;
    private options;
    private writeStream?;
    private currentFileSize;
    private readonly LOG_LEVELS;
    constructor(options?: ActivityLoggerOptions);
    /**
     * Initialize file logging
     */
    private initFileLogging;
    /**
     * Rotate log file
     */
    private rotateLogFile;
    /**
     * Generate unique log ID
     */
    private generateId;
    /**
     * Format log entry for file
     */
    private formatEntry;
    /**
     * Check if log should be recorded
     */
    private shouldLog;
    /**
     * Write log entry
     */
    private writeLog;
    /**
     * Log an entry
     */
    log(level: LogLevel, category: LogCategory, action: string, actor: string, details?: Record<string, unknown>, target?: string, metadata?: Record<string, unknown>): LogEntry | null;
    /**
     * Log debug message
     */
    debug(category: LogCategory, action: string, actor: string, details?: Record<string, unknown>): LogEntry | null;
    /**
     * Log info message
     */
    info(category: LogCategory, action: string, actor: string, details?: Record<string, unknown>): LogEntry | null;
    /**
     * Log warning
     */
    warn(category: LogCategory, action: string, actor: string, details?: Record<string, unknown>): LogEntry | null;
    /**
     * Log error
     */
    error(category: LogCategory, action: string, actor: string, details?: Record<string, unknown>): LogEntry | null;
    /**
     * Log critical error
     */
    critical(category: LogCategory, action: string, actor: string, details?: Record<string, unknown>): LogEntry | null;
    /**
     * Log incoming message
     */
    logMessage(message: WAMessage, type: 'incoming' | 'outgoing'): LogEntry | null;
    /**
     * Log user action
     */
    logUserAction(actor: string, action: string, target?: string, details?: Record<string, unknown>): LogEntry | null;
    /**
     * Log group event
     */
    logGroupEvent(groupJid: string, action: string, actor: string, details?: Record<string, unknown>): LogEntry | null;
    /**
     * Log bot action
     */
    logBotAction(action: string, details?: Record<string, unknown>, target?: string): LogEntry | null;
    /**
     * Log security event
     */
    logSecurityEvent(level: LogLevel, action: string, actor: string, details?: Record<string, unknown>): LogEntry | null;
    /**
     * Get message type helper
     */
    private getMessageType;
    /**
     * Query logs
     */
    query(query: LogQuery): LogEntry[];
    /**
     * Get logs for a specific actor
     */
    getActorLogs(actor: string, limit?: number): LogEntry[];
    /**
     * Get logs for a specific target (e.g., chat JID)
     */
    getTargetLogs(target: string, limit?: number): LogEntry[];
    /**
     * Get recent logs
     */
    getRecentLogs(limit?: number): LogEntry[];
    /**
     * Get logs by level
     */
    getLogsByLevel(level: LogLevel, limit?: number): LogEntry[];
    /**
     * Get error logs
     */
    getErrorLogs(limit?: number): LogEntry[];
    /**
     * Get log statistics
     */
    getStats(): LogStats;
    /**
     * Clear all logs from memory
     */
    clearMemory(): void;
    /**
     * Export logs to JSON
     */
    export(query?: LogQuery): string;
    /**
     * Export logs to file
     */
    exportToFile(filePath: string, query?: LogQuery): Promise<void>;
    /**
     * Close logger
     */
    close(): void;
}
export declare const createActivityLogger: (options?: ActivityLoggerOptions) => ActivityLogger;
export declare const consoleFormatter: (entry: LogEntry) => string;
