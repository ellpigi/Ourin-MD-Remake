/**
 * Baileys-Joss: Chat Analytics
 *
 * Statistik dan analitik chat
 */
import type { WAMessage } from '../Types';
export interface ChatStats {
    jid: string;
    totalMessages: number;
    messagesFromMe: number;
    messagesFromOthers: number;
    messagesByType: {
        text: number;
        image: number;
        video: number;
        audio: number;
        document: number;
        sticker: number;
        location: number;
        contact: number;
        poll: number;
        other: number;
    };
    participants?: Map<string, number>;
    firstMessageTime?: Date;
    lastMessageTime?: Date;
    averageMessagesPerDay: number;
    mostActiveHour: number;
    mostActiveDay: string;
    mediaCount: number;
    linkCount: number;
    emojiCount: number;
    averageMessageLength: number;
}
export interface GlobalStats {
    totalChats: number;
    totalMessages: number;
    totalContacts: number;
    totalGroups: number;
    messagesByType: ChatStats['messagesByType'];
    mostActiveChat: {
        jid: string;
        count: number;
    } | null;
    averageMessagesPerChat: number;
}
export interface TimeRange {
    start: Date;
    end: Date;
}
/**
 * Chat Analytics Manager
 */
export declare class ChatAnalytics {
    private messages;
    /**
     * Add messages for analysis
     */
    addMessages(messages: WAMessage[]): void;
    /**
     * Clear all messages
     */
    clear(): void;
    /**
     * Get stats for a specific chat
     */
    getChatStats(jid: string, timeRange?: TimeRange): ChatStats | null;
    /**
     * Get global stats across all chats
     */
    getGlobalStats(): GlobalStats;
    /**
     * Get activity by hour (0-23)
     */
    getActivityByHour(jid?: string): number[];
    /**
     * Get activity by day of week
     */
    getActivityByDay(jid?: string): Record<string, number>;
    /**
     * Get top participants in a chat
     */
    getTopParticipants(jid: string, limit?: number): Array<{
        participant: string;
        count: number;
    }>;
}
/**
 * Create chat analytics instance
 */
export declare const createChatAnalytics: () => ChatAnalytics;
