/**
 * Baileys-Joss: Voice Note Utilities
 *
 * Fitur untuk merekam dan mengirim voice note
 */
export interface VoiceNoteOptions {
    /** Duration in seconds */
    seconds?: number;
    /** Audio sample rate (default: 48000) */
    sampleRate?: number;
    /** Audio channels (default: 1 for mono) */
    channels?: number;
}
export interface AudioConversionOptions {
    /** Target format (default: 'ogg') */
    format?: 'ogg' | 'mp3' | 'wav';
    /** Audio bitrate (default: '64k') */
    bitrate?: string;
    /** Sample rate (default: 48000) */
    sampleRate?: number;
    /** Audio channels (default: 1) */
    channels?: number;
}
/**
 * Check if FFmpeg is available
 */
export declare const isFFmpegAvailable: () => Promise<boolean>;
/**
 * Get audio duration from buffer
 */
export declare const getAudioDurationFromBuffer: (buffer: Buffer) => Promise<number>;
/**
 * Convert audio to Opus OGG format (required for WhatsApp voice notes)
 */
export declare const convertToOpusOgg: (input: Buffer | string, options?: AudioConversionOptions) => Promise<Buffer>;
/**
 * Convert audio to MP3 format
 */
export declare const convertToMp3: (input: Buffer | string, options?: AudioConversionOptions) => Promise<Buffer>;
/**
 * Create voice note message content
 */
export declare const createVoiceNote: (audio: Buffer | string, options?: VoiceNoteOptions) => Promise<{
    audio: Buffer;
    ptt: true;
    seconds: number;
    mimetype: string;
}>;
/**
 * Create regular audio message (not voice note)
 */
export declare const createAudioMessage: (audio: Buffer | string, options?: VoiceNoteOptions) => Promise<{
    audio: Buffer;
    ptt: false;
    seconds: number;
    mimetype: string;
}>;
/**
 * Voice note helper for quick usage
 */
export declare const VoiceNoteHelper: {
    /**
     * Create PTT voice note from buffer
     */
    fromBuffer: (buffer: Buffer, seconds?: number) => Promise<{
        audio: Buffer;
        ptt: true;
        seconds: number;
        mimetype: string;
    }>;
    /**
     * Create PTT voice note from file
     */
    fromFile: (filePath: string) => Promise<{
        audio: Buffer;
        ptt: true;
        seconds: number;
        mimetype: string;
    }>;
    /**
     * Create regular audio from buffer
     */
    audioFromBuffer: (buffer: Buffer, seconds?: number) => Promise<{
        audio: Buffer;
        ptt: false;
        seconds: number;
        mimetype: string;
    }>;
    /**
     * Create regular audio from file
     */
    audioFromFile: (filePath: string) => Promise<{
        audio: Buffer;
        ptt: false;
        seconds: number;
        mimetype: string;
    }>;
    /**
     * Check FFmpeg availability
     */
    checkFFmpeg: () => Promise<boolean>;
    /**
     * Get audio duration
     */
    getDuration: (buffer: Buffer) => Promise<number>;
    /**
     * Convert to Opus OGG
     */
    toOpus: (input: Buffer | string, options?: AudioConversionOptions) => Promise<Buffer>;
    /**
     * Convert to MP3
     */
    toMp3: (input: Buffer | string, options?: AudioConversionOptions) => Promise<Buffer>;
};
