/**
 * Baileys-Joss: Message Search Utilities
 *
 * Fitur untuk mencari pesan dalam chat
 */
import type { WAMessage } from '../Types';
export interface SearchOptions {
    /** Case sensitive search */
    caseSensitive?: boolean;
    /** Search in specific chat only */
    jid?: string;
    /** Search from specific date */
    fromDate?: Date;
    /** Search until specific date */
    toDate?: Date;
    /** Maximum results */
    limit?: number;
    /** Message types to search */
    messageTypes?: ('text' | 'image' | 'video' | 'document' | 'audio' | 'sticker' | 'location' | 'contact')[];
    /** Search in captions */
    includeCaption?: boolean;
    /** Search sender */
    fromSender?: string;
    /** Only from me */
    fromMe?: boolean;
}
export interface SearchResult {
    message: WAMessage;
    matchedText: string;
    matchPosition: number;
    relevanceScore: number;
}
/**
 * Extract searchable text from message
 */
export declare const extractMessageText: (message: WAMessage) => string;
/**
 * Search messages
 */
export declare const searchMessages: (messages: WAMessage[], query: string, options?: SearchOptions) => SearchResult[];
/**
 * Search with regex
 */
export declare const searchMessagesRegex: (messages: WAMessage[], pattern: RegExp, options?: Omit<SearchOptions, "caseSensitive">) => SearchResult[];
/**
 * Message Search Manager
 */
export declare class MessageSearchManager {
    private messages;
    private messageIndex;
    /**
     * Add messages to the search index
     */
    addMessages(messages: WAMessage[]): void;
    /**
     * Remove messages from index
     */
    removeMessages(messageIds: string[]): void;
    /**
     * Clear all messages
     */
    clear(): void;
    /**
     * Get message count
     */
    get count(): number;
    /**
     * Search messages
     */
    search(query: string, options?: SearchOptions): SearchResult[];
    /**
     * Search with regex
     */
    searchRegex(pattern: RegExp, options?: Omit<SearchOptions, 'caseSensitive'>): SearchResult[];
    /**
     * Get messages by JID
     */
    getByJid(jid: string): WAMessage[];
    /**
     * Get messages by sender
     */
    getBySender(sender: string): WAMessage[];
    /**
     * Get messages by type
     */
    getByType(type: 'text' | 'image' | 'video' | 'document' | 'audio' | 'sticker' | 'location' | 'contact'): WAMessage[];
    /**
     * Get message by ID
     */
    getById(id: string): WAMessage | undefined;
}
/**
 * Create a message search manager
 */
export declare const createMessageSearch: () => MessageSearchManager;
