/**
 * Baileys-Joss: Message Scheduling System
 *
 * Fitur untuk menjadwalkan pesan dengan waktu tertentu
 */
import type { AnyMessageContent, WAMessage } from '../Types';
export interface ScheduledMessage {
    id: string;
    jid: string;
    content: AnyMessageContent;
    scheduledTime: Date;
    createdAt: Date;
    status: 'pending' | 'sent' | 'failed' | 'cancelled';
    error?: string;
    messageId?: string;
}
export interface SchedulerOptions {
    /** Maximum number of scheduled messages to keep in queue */
    maxQueue?: number;
    /** Check interval in milliseconds (default: 1000ms) */
    checkInterval?: number;
    /** Callback when message is sent */
    onSent?: (scheduled: ScheduledMessage, message: WAMessage) => void;
    /** Callback when message fails */
    onFailed?: (scheduled: ScheduledMessage, error: Error) => void;
}
export type SendMessageFunction = (jid: string, content: AnyMessageContent) => Promise<WAMessage | undefined>;
/**
 * Message Scheduler - Jadwalkan pesan untuk dikirim otomatis
 */
export declare class MessageScheduler {
    private queue;
    private timer;
    private sendMessage;
    private options;
    constructor(sendMessage: SendMessageFunction, options?: SchedulerOptions);
    /**
     * Generate unique ID for scheduled message
     */
    private generateId;
    /**
     * Schedule a message to be sent at a specific time
     */
    schedule(jid: string, content: AnyMessageContent, scheduledTime: Date): ScheduledMessage;
    /**
     * Schedule message with delay (in milliseconds)
     */
    scheduleDelay(jid: string, content: AnyMessageContent, delayMs: number): ScheduledMessage;
    /**
     * Cancel a scheduled message
     */
    cancel(id: string): boolean;
    /**
     * Cancel all scheduled messages for a specific JID
     */
    cancelForJid(jid: string): number;
    /**
     * Get all pending scheduled messages
     */
    getPending(): ScheduledMessage[];
    /**
     * Get scheduled message by ID
     */
    get(id: string): ScheduledMessage | undefined;
    /**
     * Clear all pending messages
     */
    clearAll(): number;
    /**
     * Process queue and send due messages
     */
    private processQueue;
    private ensureTimerRunning;
    private stopTimer;
    /**
     * Stop the scheduler
     */
    stop(): void;
    /**
     * Start the scheduler (auto-starts when messages are scheduled)
     */
    start(): void;
}
/**
 * Create a message scheduler instance
 */
export declare const createMessageScheduler: (sendMessage: SendMessageFunction, options?: SchedulerOptions) => MessageScheduler;
