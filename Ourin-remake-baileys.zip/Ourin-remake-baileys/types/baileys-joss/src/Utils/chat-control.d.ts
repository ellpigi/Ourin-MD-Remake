/**
 * Baileys-Joss: Chat Control Utilities
 *
 * Fitur untuk Read Receipt, Typing Indicator, Pinned Messages, Disappearing Messages
 */
export interface TypingOptions {
    /** Duration in milliseconds before auto-pause */
    duration?: number;
    /** Auto pause after duration */
    autoPause?: boolean;
}
export interface DisappearingOptions {
    /** Duration in seconds (0 = off, 86400 = 24h, 604800 = 7 days, 7776000 = 90 days) */
    duration: number;
}
/**
 * Disappearing message durations
 */
export declare const DISAPPEARING_DURATIONS: {
    readonly OFF: 0;
    readonly HOURS_24: 86400;
    readonly DAYS_7: 604800;
    readonly DAYS_90: 7776000;
};
/**
 * Typing indicator helper
 */
export declare class TypingIndicator {
    private intervals;
    private sendPresence;
    constructor(sendPresence: (jid: string, presence: 'composing' | 'paused' | 'recording') => Promise<void>);
    /**
     * Start typing indicator
     */
    startTyping(jid: string, options?: TypingOptions): Promise<void>;
    /**
     * Start recording indicator (for voice notes)
     */
    startRecording(jid: string, options?: TypingOptions): Promise<void>;
    /**
     * Stop typing/recording indicator
     */
    stopTyping(jid: string): Promise<void>;
    /**
     * Stop all typing indicators
     */
    stopAll(): Promise<void>;
    /**
     * Simulate typing for a duration then execute callback
     */
    simulateTyping<T>(jid: string, duration: number, callback: () => Promise<T>): Promise<T>;
}
/**
 * Read Receipt controller
 */
export interface ReadReceiptConfig {
    /** Enable read receipts (blue ticks) */
    enabled: boolean;
    /** Auto-read messages */
    autoRead?: boolean;
    /** Delay before marking as read (ms) */
    readDelay?: number;
    /** Excluded JIDs */
    excludeJids?: string[];
}
/**
 * Create read receipt controller
 */
export declare const createReadReceiptController: (sendReadReceipt: (jid: string, participant: string | undefined, messageIds: string[]) => Promise<void>, config?: ReadReceiptConfig) => {
    /**
     * Update config
     */
    setConfig(newConfig: Partial<ReadReceiptConfig>): void;
    /**
     * Get current config
     */
    getConfig(): {
        /** Enable read receipts (blue ticks) */
        enabled: boolean;
        /** Auto-read messages */
        autoRead?: boolean;
        /** Delay before marking as read (ms) */
        readDelay?: number;
        /** Excluded JIDs */
        excludeJids?: string[];
    };
    /**
     * Enable read receipts
     */
    enable(): void;
    /**
     * Disable read receipts
     */
    disable(): void;
    /**
     * Check if enabled
     */
    isEnabled(): boolean;
    /**
     * Mark messages as read (respects config)
     */
    markRead(jid: string, participant: string | undefined, messageIds: string[]): Promise<void>;
    /**
     * Force mark as read (ignores config)
     */
    forceMarkRead(jid: string, participant: string | undefined, messageIds: string[]): Promise<void>;
};
/**
 * Pinned message interface
 */
export interface PinnedMessage {
    messageId: string;
    jid: string;
    pinnedAt: Date;
    pinnedBy?: string;
    expiresAt?: Date;
}
/**
 * Pinned messages manager (client-side tracking)
 */
export declare class PinnedMessagesManager {
    private pinnedMessages;
    /**
     * Add pinned message
     */
    pin(jid: string, messageId: string, pinnedBy?: string, expiresAt?: Date): PinnedMessage;
    /**
     * Remove pinned message
     */
    unpin(jid: string, messageId: string): boolean;
    /**
     * Get pinned messages for a chat
     */
    getPinned(jid: string): PinnedMessage[];
    /**
     * Check if message is pinned
     */
    isPinned(jid: string, messageId: string): boolean;
    /**
     * Clear all pins for a chat
     */
    clearPins(jid: string): void;
    /**
     * Clear expired pins
     */
    clearExpired(): number;
}
/**
 * Create typing indicator helper
 */
export declare const createTypingIndicator: (sendPresence: (jid: string, presence: "composing" | "paused" | "recording") => Promise<void>) => TypingIndicator;
/**
 * Create pinned messages manager
 */
export declare const createPinnedMessagesManager: () => PinnedMessagesManager;
