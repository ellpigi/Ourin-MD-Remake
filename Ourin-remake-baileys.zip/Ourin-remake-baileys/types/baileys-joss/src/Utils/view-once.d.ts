/**
 * View Once & Media Utilities untuk Baileys-Joss
 *
 * Fitur untuk handling view once messages dan media utilities
 *
 * @module view-once
 */
import { proto } from '../../WAProto/index.js';
import type { WAMessage, WAMessageContent, DownloadableMessage } from '../Types';
import type { MediaType } from '../Defaults';
export interface ViewOnceInfo {
    /** Apakah ini view once message */
    isViewOnce: boolean;
    /** Type media (image/video/audio) */
    mediaType?: MediaType;
    /** Caption jika ada */
    caption?: string;
    /** Sudah dilihat atau belum */
    isViewed?: boolean;
    /** Message content untuk download */
    downloadable?: DownloadableMessage;
    /** Mimetype */
    mimetype?: string;
    /** File size */
    fileLength?: number;
}
export interface MediaInfo {
    /** Type media */
    type: MediaType | 'unknown';
    /** Caption */
    caption?: string;
    /** Mimetype */
    mimetype?: string;
    /** File size dalam bytes */
    fileSize?: number;
    /** Duration (untuk audio/video) */
    duration?: number;
    /** Width (untuk image/video) */
    width?: number;
    /** Height (untuk image/video) */
    height?: number;
    /** Is GIF */
    isGif?: boolean;
    /** Is animated sticker */
    isAnimated?: boolean;
    /** Filename (untuk document) */
    fileName?: string;
    /** Thumbnail */
    jpegThumbnail?: Uint8Array;
    /** View once */
    isViewOnce?: boolean;
    /** Downloadable message */
    downloadable?: DownloadableMessage;
}
export interface ExtractedMessage {
    /** Text content */
    text?: string;
    /** Media info jika ada */
    media?: MediaInfo;
    /** Quoted message jika ada */
    quoted?: {
        message?: WAMessageContent;
        key?: proto.IMessageKey;
        participant?: string;
        text?: string;
        media?: MediaInfo;
    };
    /** Mentions */
    mentions?: string[];
    /** Is forwarded */
    isForwarded?: boolean;
    /** Forward score */
    forwardScore?: number;
    /** Reaction */
    reaction?: {
        text: string;
        key: proto.IMessageKey;
    };
    /** Is ephemeral */
    isEphemeral?: boolean;
    /** Ephemeral expiration */
    ephemeralExpiration?: number;
}
/**
 * Check apakah message adalah view once
 */
export declare const isViewOnceMessage: (message: WAMessage) => boolean;
/**
 * Get view once message info
 */
export declare const getViewOnceInfo: (message: WAMessage) => ViewOnceInfo | null;
/**
 * Download view once media
 * Returns buffer dari media
 */
export declare const downloadViewOnceMedia: (message: WAMessage, options?: {
    timeout?: number;
}) => Promise<{
    buffer: Buffer;
    info: ViewOnceInfo;
} | null>;
/**
 * Get media info dari message content
 */
export declare const getMediaInfo: (content: WAMessageContent | null | undefined) => MediaInfo | null;
/**
 * Download media dari message
 */
export declare const downloadMedia: (message: WAMessage, options?: {
    timeout?: number;
}) => Promise<Buffer | null>;
/**
 * Get text dari message (support berbagai jenis message)
 */
export declare const getMessageText: (message: WAMessage) => string | undefined;
/**
 * Get quoted message info
 */
export declare const getQuotedMessage: (message: WAMessage) => ExtractedMessage["quoted"] | null;
/**
 * Get mentions dari message
 */
export declare const getMentions: (message: WAMessage) => string[];
/**
 * Check apakah message adalah forwarded
 */
export declare const isForwardedMessage: (message: WAMessage) => boolean;
/**
 * Get forward score (berapa kali di-forward)
 */
export declare const getForwardScore: (message: WAMessage) => number;
/**
 * Extract semua info dari message
 */
export declare const extractMessageInfo: (message: WAMessage) => ExtractedMessage;
/**
 * Get message type
 */
export declare const getMessageType: (message: WAMessage) => string | undefined;
/**
 * Check apakah message memiliki media
 */
export declare const hasMedia: (message: WAMessage) => boolean;
/**
 * Check apakah message adalah reply
 */
export declare const isReply: (message: WAMessage) => boolean;
declare const _default: {
    isViewOnceMessage: (message: WAMessage) => boolean;
    getViewOnceInfo: (message: WAMessage) => ViewOnceInfo | null;
    downloadViewOnceMedia: (message: WAMessage, options?: {
        timeout?: number;
    }) => Promise<{
        buffer: Buffer;
        info: ViewOnceInfo;
    } | null>;
    getMediaInfo: (content: WAMessageContent | null | undefined) => MediaInfo | null;
    downloadMedia: (message: WAMessage, options?: {
        timeout?: number;
    }) => Promise<Buffer | null>;
    getMessageText: (message: WAMessage) => string | undefined;
    getQuotedMessage: (message: WAMessage) => ExtractedMessage["quoted"] | null;
    getMentions: (message: WAMessage) => string[];
    isForwardedMessage: (message: WAMessage) => boolean;
    getForwardScore: (message: WAMessage) => number;
    extractMessageInfo: (message: WAMessage) => ExtractedMessage;
    getMessageType: (message: WAMessage) => string | undefined;
    hasMedia: (message: WAMessage) => boolean;
    isReply: (message: WAMessage) => boolean;
};
export default _default;
