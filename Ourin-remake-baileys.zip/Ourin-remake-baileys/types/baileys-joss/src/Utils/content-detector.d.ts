/**
 * Baileys-Joss: Content Detector
 *
 * Deteksi otomatis berbagai jenis konten dalam pesan:
 * - Links/URLs
 * - Phone numbers
 * - Emails
 * - Media (images, videos, audio, documents)
 * - Mentions
 * - Hashtags
 * - Sensitive content keywords
 */
import type { WAMessage } from '../Types';
export interface LinkInfo {
    url: string;
    domain: string;
    isHttps: boolean;
    type: 'website' | 'image' | 'video' | 'social' | 'file' | 'other';
}
export interface PhoneInfo {
    raw: string;
    formatted: string;
    countryCode?: string;
}
export interface MentionInfo {
    jid: string;
    position: {
        start: number;
        end: number;
    };
}
export interface DetectionResult {
    hasMedia: boolean;
    mediaType: 'image' | 'video' | 'audio' | 'document' | 'sticker' | 'location' | 'contact' | null;
    hasLinks: boolean;
    links: LinkInfo[];
    hasPhoneNumbers: boolean;
    phoneNumbers: PhoneInfo[];
    hasEmails: boolean;
    emails: string[];
    hasMentions: boolean;
    mentions: MentionInfo[];
    hasHashtags: boolean;
    hashtags: string[];
    hasEmojis: boolean;
    emojis: string[];
    hasSensitiveContent: boolean;
    sensitiveKeywords: string[];
    messageType: string;
    textLength: number;
    wordCount: number;
}
export interface ContentFilterOptions {
    /** Block links */
    blockLinks?: boolean;
    /** Block specific domains */
    blockedDomains?: string[];
    /** Block phone numbers */
    blockPhoneNumbers?: boolean;
    /** Block emails */
    blockEmails?: boolean;
    /** Sensitive keywords to detect */
    sensitiveKeywords?: string[];
    /** Maximum message length */
    maxMessageLength?: number;
    /** Custom regex patterns to detect */
    customPatterns?: RegExp[];
}
export interface FilterResult {
    allowed: boolean;
    blockedReason?: string;
    detectedViolations: string[];
}
export declare class ContentDetector {
    private sensitiveKeywords;
    private customPatterns;
    constructor(options?: {
        sensitiveKeywords?: string[];
        customPatterns?: RegExp[];
    });
    /**
     * Analyze a WhatsApp message
     */
    analyze(message: WAMessage): DetectionResult;
    /**
     * Extract text from message
     */
    private extractText;
    /**
     * Get media type from message
     */
    private getMediaType;
    /**
     * Get message type string
     */
    private getMessageType;
    /**
     * Detect links in text
     */
    detectLinks(text: string): LinkInfo[];
    /**
     * Detect phone numbers
     */
    detectPhoneNumbers(text: string): PhoneInfo[];
    /**
     * Detect email addresses
     */
    detectEmails(text: string): string[];
    /**
     * Detect mentions from message
     */
    detectMentions(message: WAMessage): MentionInfo[];
    /**
     * Detect hashtags
     */
    detectHashtags(text: string): string[];
    /**
     * Detect emojis
     */
    detectEmojis(text: string): string[];
    /**
     * Detect sensitive content
     */
    detectSensitiveContent(text: string): string[];
    /**
     * Check custom patterns
     */
    checkCustomPatterns(text: string): boolean[];
    /**
     * Add sensitive keywords
     */
    addSensitiveKeywords(keywords: string[]): void;
    /**
     * Set sensitive keywords
     */
    setSensitiveKeywords(keywords: string[]): void;
    /**
     * Add custom pattern
     */
    addCustomPattern(pattern: RegExp): void;
}
export declare class ContentFilter {
    private options;
    constructor(options?: ContentFilterOptions);
    /**
     * Filter a message
     */
    filter(message: WAMessage): FilterResult;
    /**
     * Extract text from message
     */
    private extractText;
    /**
     * Update filter options
     */
    updateOptions(options: Partial<ContentFilterOptions>): void;
}
/**
 * Quick check if message contains links
 */
export declare const hasLinks: (text: string) => boolean;
/**
 * Quick check if message contains phone numbers
 */
export declare const hasPhoneNumbers: (text: string) => boolean;
/**
 * Quick check if message contains emails
 */
export declare const hasEmails: (text: string) => boolean;
/**
 * Extract all links from text
 */
export declare const extractLinks: (text: string) => string[];
/**
 * Extract all phone numbers from text
 */
export declare const extractPhoneNumbers: (text: string) => string[];
/**
 * Extract all emails from text
 */
export declare const extractEmails: (text: string) => string[];
/**
 * Check if message has media content
 */
export declare const hasMediaContent: (message: WAMessage) => boolean;
/**
 * Check if message is forwarded
 */
export declare const isForwarded: (message: WAMessage) => boolean;
/**
 * Get forward count
 */
export declare const getForwardCount: (message: WAMessage) => number;
export declare const createContentDetector: (options?: {
    sensitiveKeywords?: string[];
    customPatterns?: RegExp[];
}) => ContentDetector;
export declare const createContentFilter: (options?: ContentFilterOptions) => ContentFilter;
