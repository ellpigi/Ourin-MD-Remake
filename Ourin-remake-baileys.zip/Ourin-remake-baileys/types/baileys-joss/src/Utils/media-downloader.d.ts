/**
 * Baileys-Joss: Media Downloader
 *
 * Download semua media dari chat
 */
import type { WAMessage } from '../Types';
export type DownloadMediaType = 'image' | 'video' | 'audio' | 'document' | 'sticker' | 'all';
export interface DownloadOptions {
    /** Output directory */
    outputDir: string;
    /** Media types to download */
    types?: DownloadMediaType[];
    /** Create subfolder for each type */
    createSubfolders?: boolean;
    /** Custom filename template */
    filenameTemplate?: string;
    /** Skip existing files */
    skipExisting?: boolean;
    /** Maximum file size in bytes (0 = no limit) */
    maxFileSize?: number;
    /** Progress callback */
    onProgress?: (current: number, total: number, filename: string) => void;
    /** Error callback */
    onError?: (message: WAMessage, error: Error) => void;
    /** Delay between downloads in ms */
    delay?: number;
}
export interface DownloadResult {
    messageId: string;
    type: DownloadMediaType;
    filename: string;
    filepath: string;
    size: number;
    success: boolean;
    error?: string;
}
export interface DownloadSummary {
    total: number;
    successful: number;
    failed: number;
    skipped: number;
    totalSize: number;
    results: DownloadResult[];
    startedAt: Date;
    completedAt: Date;
}
/**
 * Media Downloader
 */
export declare class MediaDownloader {
    private getMessage;
    constructor(getMessage: (key: {
        remoteJid: string;
        id: string;
    }) => Promise<WAMessage | undefined>);
    /**
     * Filter messages that have downloadable media
     */
    filterMediaMessages(messages: WAMessage[], types?: DownloadMediaType[]): WAMessage[];
    /**
     * Download media from a single message
     */
    downloadSingle(message: WAMessage, outputDir: string, options?: Omit<DownloadOptions, 'outputDir'>): Promise<DownloadResult>;
    /**
     * Download media from multiple messages
     */
    downloadMultiple(messages: WAMessage[], options: DownloadOptions): Promise<DownloadSummary>;
    /**
     * Download all media from a chat
     */
    downloadFromChat(jid: string, messages: WAMessage[], options: Omit<DownloadOptions, 'outputDir'> & {
        outputDir?: string;
    }): Promise<DownloadSummary>;
}
/**
 * Create media downloader
 */
export declare const createMediaDownloader: (getMessage: (key: {
    remoteJid: string;
    id: string;
}) => Promise<WAMessage | undefined>) => MediaDownloader;
/**
 * Quick download helper
 */
export declare const downloadAllMedia: (messages: WAMessage[], outputDir: string, options?: Omit<DownloadOptions, "outputDir">) => Promise<DownloadSummary>;
