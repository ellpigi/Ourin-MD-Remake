/**
 * Interactive Message Utilities for Baileys-Joss
 * Fitur yang tidak ada di Baileys Original
 *
 * @module interactive-message
 */
import { proto } from '../../WAProto/index.js';
import type { WAMediaUpload, WAMessageContent } from '../Types';
import type { MediaGenerationOptions } from '../Types/Message';
export interface InteractiveButton {
    /** Display text on button */
    name: string;
    /** Button ID for callback */
    buttonId: string;
    /** Button text */
    displayText: string;
}
export interface InteractiveButtonReply extends InteractiveButton {
    /** Index of button */
    index?: number;
}
export interface QuickReplyButton {
    id: string;
    displayText: string;
}
export interface UrlButton {
    displayText: string;
    url: string;
    /** Merchant URL for tracking */
    merchantUrl?: string;
}
export interface CallButton {
    displayText: string;
    phoneNumber: string;
}
export interface CopyButton {
    displayText: string;
    copyCode: string;
}
export interface ListSection {
    title: string;
    rows: ListRow[];
}
export interface ListRow {
    /** Unique row ID */
    rowId: string;
    title: string;
    description?: string;
}
export interface InteractiveListMessage {
    /** Title di header */
    title: string;
    /** Button text untuk expand list */
    buttonText: string;
    /** Sections dengan rows */
    sections: ListSection[];
    /** Footer text */
    footer?: string;
    /** Description/body text */
    description?: string;
}
export interface InteractiveButtonsMessage {
    /** Header text */
    title?: string;
    /** Body text */
    body: string;
    /** Footer text */
    footer?: string;
    /** List of buttons */
    buttons: InteractiveButton[];
    /** Optional header image */
    headerImage?: WAMediaUpload;
    /** Optional header video */
    headerVideo?: WAMediaUpload;
    /** Optional header document */
    headerDocument?: WAMediaUpload & {
        filename?: string;
    };
}
export interface TemplateButton {
    index: number;
    quickReplyButton?: QuickReplyButton;
    urlButton?: UrlButton;
    callButton?: CallButton;
}
export interface TemplateMessage {
    /** Namespace - usually 'default' */
    namespace?: string;
    /** Header text */
    title?: string;
    /** Body text */
    body: string;
    /** Footer text */
    footer?: string;
    /** Buttons */
    buttons: TemplateButton[];
    /** Optional header image */
    headerImage?: WAMediaUpload;
    /** Optional header video */
    headerVideo?: WAMediaUpload;
    /** Optional header location */
    headerLocation?: {
        latitude: number;
        longitude: number;
        name?: string;
        address?: string;
    };
}
export interface CarouselCard {
    header: {
        imageMessage?: proto.Message.IImageMessage;
        title?: string;
    };
    body: {
        text: string;
    };
    footer?: {
        text: string;
    };
    buttons: InteractiveButton[];
}
export interface CarouselMessage {
    cards: CarouselCard[];
    /** Message ID untuk correlation */
    messageParentId?: string;
}
/**
 * Membuat interactive buttons message (type baru yang work)
 * Ini menggunakan format yang lebih compatible dengan WA
 */
export declare const generateInteractiveButtonMessage: (content: InteractiveButtonsMessage, options?: MediaGenerationOptions) => Promise<WAMessageContent>;
/**
 * Membuat interactive list message
 * Format list selection dengan sections dan rows
 */
export declare const generateInteractiveListMessage: (content: InteractiveListMessage) => WAMessageContent;
/**
 * Membuat template message dengan berbagai button types
 * Supports: Quick Reply, URL, Call buttons
 */
export declare const generateTemplateMessage: (content: TemplateMessage, options?: MediaGenerationOptions) => Promise<WAMessageContent>;
/**
 * Membuat native flow message (Interactive Message V2)
 * Ini format terbaru untuk interactive messages
 */
export declare const generateNativeFlowMessage: (body: string, buttons: Array<{
    name: string;
    buttonParamsJson: string;
}>, options?: {
    footer?: string;
    header?: {
        title?: string;
        subtitle?: string;
        hasMediaAttachment?: boolean;
    };
}) => WAMessageContent;
/**
 * Membuat button dengan Copy Code (untuk OTP, codes, dll)
 */
export declare const generateCopyCodeButton: (body: string, copyCode: string, displayText?: string, options?: {
    footer?: string;
}) => WAMessageContent;
/**
 * Membuat button dengan URL
 */
export declare const generateUrlButtonMessage: (body: string, buttons: Array<{
    displayText: string;
    url: string;
    merchantUrl?: string;
}>, options?: {
    footer?: string;
    title?: string;
}) => WAMessageContent;
/**
 * Membuat quick reply buttons
 */
export declare const generateQuickReplyButtons: (body: string, buttons: Array<{
    id: string;
    displayText: string;
}>, options?: {
    footer?: string;
    title?: string;
}) => WAMessageContent;
/**
 * Membuat combined buttons (mix URL, Quick Reply, Copy)
 */
export declare const generateCombinedButtons: (body: string, buttons: Array<{
    type: "url";
    displayText: string;
    url: string;
} | {
    type: "reply";
    displayText: string;
    id: string;
} | {
    type: "copy";
    displayText: string;
    copyCode: string;
} | {
    type: "call";
    displayText: string;
    phoneNumber: string;
}>, options?: {
    footer?: string;
    title?: string;
}) => WAMessageContent;
declare const _default: {
    generateInteractiveButtonMessage: (content: InteractiveButtonsMessage, options?: MediaGenerationOptions) => Promise<WAMessageContent>;
    generateInteractiveListMessage: (content: InteractiveListMessage) => WAMessageContent;
    generateTemplateMessage: (content: TemplateMessage, options?: MediaGenerationOptions) => Promise<WAMessageContent>;
    generateNativeFlowMessage: (body: string, buttons: Array<{
        name: string;
        buttonParamsJson: string;
    }>, options?: {
        footer?: string;
        header?: {
            title?: string;
            subtitle?: string;
            hasMediaAttachment?: boolean;
        };
    }) => WAMessageContent;
    generateCopyCodeButton: (body: string, copyCode: string, displayText?: string, options?: {
        footer?: string;
    }) => WAMessageContent;
    generateUrlButtonMessage: (body: string, buttons: Array<{
        displayText: string;
        url: string;
        merchantUrl?: string;
    }>, options?: {
        footer?: string;
        title?: string;
    }) => WAMessageContent;
    generateQuickReplyButtons: (body: string, buttons: Array<{
        id: string;
        displayText: string;
    }>, options?: {
        footer?: string;
        title?: string;
    }) => WAMessageContent;
    generateCombinedButtons: (body: string, buttons: Array<{
        type: "url";
        displayText: string;
        url: string;
    } | {
        type: "reply";
        displayText: string;
        id: string;
    } | {
        type: "copy";
        displayText: string;
        copyCode: string;
    } | {
        type: "call";
        displayText: string;
        phoneNumber: string;
    }>, options?: {
        footer?: string;
        title?: string;
    }) => WAMessageContent;
};
export default _default;
