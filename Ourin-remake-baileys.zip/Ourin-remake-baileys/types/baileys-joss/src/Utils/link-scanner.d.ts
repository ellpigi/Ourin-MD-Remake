/**
 * Baileys-Joss: Link Scanner
 *
 * Scan dan validasi URL untuk keamanan:
 * - Check domain reputation
 * - Detect phishing patterns
 * - URL shortener expansion
 * - Safe browsing check
 */
export interface LinkScanResult {
    url: string;
    safe: boolean;
    riskLevel: 'safe' | 'low' | 'medium' | 'high' | 'critical';
    riskScore: number;
    threats: string[];
    details: {
        isShortener: boolean;
        finalUrl?: string;
        domain: string;
        isHttps: boolean;
        hasIPAddress: boolean;
        hasSuspiciousPath: boolean;
        isKnownMalicious: boolean;
        phishingScore: number;
    };
    scannedAt: Date;
}
export interface LinkScannerOptions {
    /** Follow redirects to get final URL */
    followRedirects?: boolean;
    /** Maximum redirects to follow */
    maxRedirects?: number;
    /** Timeout for URL check (ms) */
    timeout?: number;
    /** Custom malicious domains list */
    maliciousDomains?: string[];
    /** Custom safe domains (always allowed) */
    safeDomains?: string[];
    /** Enable phishing pattern detection */
    enablePhishingDetection?: boolean;
}
export declare class LinkScanner {
    private options;
    private maliciousDomains;
    private safeDomains;
    constructor(options?: LinkScannerOptions);
    /**
     * Scan a URL for security threats
     */
    scan(url: string): Promise<LinkScanResult>;
    /**
     * Batch scan multiple URLs
     */
    scanMultiple(urls: string[]): Promise<LinkScanResult[]>;
    /**
     * Quick check if URL is suspicious
     */
    quickCheck(url: string): {
        suspicious: boolean;
        reasons: string[];
    };
    /**
     * Add domain to malicious list
     */
    addMaliciousDomain(domain: string): void;
    /**
     * Add domain to safe list
     */
    addSafeDomain(domain: string): void;
    /**
     * Remove domain from malicious list
     */
    removeMaliciousDomain(domain: string): void;
    /**
     * Check if domain is safe
     */
    private isDomainSafe;
    /**
     * Check for suspicious TLD
     */
    private hasSuspiciousTLD;
    /**
     * Check for suspicious path patterns
     */
    private checkSuspiciousPath;
    /**
     * Calculate phishing score
     */
    private calculatePhishingScore;
    /**
     * Get risk level from score
     */
    private getRiskLevel;
    /**
     * Resolve URL redirects
     */
    private resolveRedirects;
}
export declare const createLinkScanner: (options?: LinkScannerOptions) => LinkScanner;
/**
 * Quick check if URL is a shortener
 */
export declare const isUrlShortener: (url: string) => boolean;
/**
 * Extract domain from URL
 */
export declare const extractDomain: (url: string) => string | null;
/**
 * Check if domain is trusted
 */
export declare const isTrustedDomain: (domain: string) => boolean;
