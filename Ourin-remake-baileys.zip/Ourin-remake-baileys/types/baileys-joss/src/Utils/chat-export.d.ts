/**
 * Baileys-Joss: Chat Export
 *
 * Export chat ke JSON, HTML, atau TXT
 */
import type { WAMessage } from '../Types';
export type ExportFormat = 'json' | 'html' | 'txt' | 'csv';
export interface ExportOptions {
    /** Export format */
    format: ExportFormat;
    /** Include media info (not actual media) */
    includeMediaInfo?: boolean;
    /** Include message metadata */
    includeMetadata?: boolean;
    /** Date format string */
    dateFormat?: string;
    /** Title for HTML export */
    title?: string;
    /** Custom CSS for HTML export */
    customCss?: string;
    /** Filter messages by date range */
    dateRange?: {
        start: Date;
        end: Date;
    };
    /** Filter by sender */
    fromSender?: string;
    /** Only messages from me */
    fromMe?: boolean;
}
export interface ExportResult {
    content: string;
    format: ExportFormat;
    messageCount: number;
    exportedAt: Date;
    filename: string;
}
/**
 * Export chat messages
 */
export declare const exportChat: (messages: WAMessage[], jid: string, options: ExportOptions) => ExportResult;
/**
 * Chat Export Manager
 */
export declare class ChatExporter {
    private messages;
    /**
     * Add messages for export
     */
    addMessages(jid: string, messages: WAMessage[]): void;
    /**
     * Export a specific chat
     */
    export(jid: string, options: ExportOptions): ExportResult | null;
    /**
     * Export all chats
     */
    exportAll(options: ExportOptions): ExportResult[];
    /**
     * Get available chats for export
     */
    getAvailableChats(): Array<{
        jid: string;
        messageCount: number;
    }>;
    /**
     * Clear messages
     */
    clear(jid?: string): void;
}
/**
 * Create chat exporter
 */
export declare const createChatExporter: () => ChatExporter;
