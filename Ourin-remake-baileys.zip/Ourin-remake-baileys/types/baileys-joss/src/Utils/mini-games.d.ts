/**
 * Baileys-Joss: Mini Games
 *
 * Game sederhana untuk chat: Tebak Angka, Quiz, Tictactoe
 */
export interface GameSession {
    id: string;
    jid: string;
    type: 'guess' | 'quiz' | 'tictactoe' | 'rps' | 'dice' | 'flip';
    state: 'active' | 'finished' | 'timeout';
    players: string[];
    data: Record<string, unknown>;
    createdAt: Date;
    expiresAt: Date;
}
export interface QuizQuestion {
    question: string;
    options: string[];
    correctIndex: number;
    explanation?: string;
    category?: string;
    difficulty?: 'easy' | 'medium' | 'hard';
}
export interface TictactoeBoard {
    cells: Array<'X' | 'O' | null>;
    currentPlayer: 'X' | 'O';
    playerX: string;
    playerO: string;
}
export interface GameResult {
    winner?: string;
    draw?: boolean;
    score?: number;
    message: string;
}
export declare class MiniGamesManager {
    private sessions;
    private sessionTimeout;
    /**
     * Generate unique session ID
     */
    private generateId;
    /**
     * Get session by JID
     */
    getSession(jid: string): GameSession | undefined;
    /**
     * End session
     */
    endSession(sessionId: string): void;
    /**
     * Clean expired sessions
     */
    cleanExpiredSessions(): void;
    /**
     * Start a number guessing game
     */
    startGuessNumber(jid: string, min?: number, max?: number): GameSession;
    /**
     * Process guess for number game
     */
    guessNumber(sessionId: string, guess: number): {
        correct: boolean;
        hint: 'higher' | 'lower' | 'correct';
        attempts: number;
        gameOver: boolean;
        message: string;
    };
    /**
     * Start a quiz game
     */
    startQuiz(jid: string, questions: QuizQuestion[]): GameSession;
    /**
     * Get current quiz question
     */
    getCurrentQuestion(sessionId: string): {
        question: QuizQuestion;
        index: number;
        total: number;
    } | null;
    /**
     * Answer quiz question
     */
    answerQuiz(sessionId: string, answerIndex: number): {
        correct: boolean;
        correctAnswer: string;
        explanation?: string;
        score: number;
        gameOver: boolean;
        nextQuestion?: QuizQuestion;
        message: string;
    };
    /**
     * Start Tic Tac Toe game
     */
    startTictactoe(jid: string, playerX: string, playerO: string): GameSession;
    /**
     * Make a move in Tic Tac Toe
     */
    tictactoeMove(sessionId: string, player: string, position: number): {
        valid: boolean;
        board: string;
        gameOver: boolean;
        winner?: string;
        draw?: boolean;
        message: string;
    };
    /**
     * Check for Tic Tac Toe winner
     */
    private checkTictactoeWinner;
    /**
     * Render Tic Tac Toe board
     */
    private renderTictactoeBoard;
    /**
     * Rock Paper Scissors
     */
    rockPaperScissors(userChoice: 'rock' | 'paper' | 'scissors'): {
        userChoice: string;
        botChoice: string;
        result: 'win' | 'lose' | 'draw';
        message: string;
    };
    /**
     * Roll a dice
     */
    rollDice(sides?: number, count?: number): {
        results: number[];
        total: number;
        message: string;
    };
    /**
     * Flip a coin
     */
    flipCoin(): {
        result: 'heads' | 'tails';
        message: string;
    };
    /**
     * Random pick from options
     */
    randomPick<T>(options: T[]): {
        selected: T;
        index: number;
        message: string;
    };
}
export declare const sampleQuizQuestions: QuizQuestion[];
export declare const createMiniGames: () => MiniGamesManager;
/**
 * Format quiz question as message
 */
export declare const formatQuizQuestion: (question: QuizQuestion, index: number, total: number) => string;
